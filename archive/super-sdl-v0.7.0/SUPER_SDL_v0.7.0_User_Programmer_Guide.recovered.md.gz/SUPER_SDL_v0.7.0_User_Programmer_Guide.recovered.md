                            SUPER SDL
                                                v0.7.0
                    USER & PROGRAMMER GUIDE
                         AI-Addressable Laboratory Fabric
One semantic laboratory • many node types • transport-independent SDL • Codex/MCP
                                                  friendly




Purpose of this guide
Take a clean v0.7.0 release from ZIP file to a working Codex-controlled laboratory, then show a programmer
exactly how to add nodes, transports, capabilities, and recovery tooling without breaking the semantic
contract.



                                      Release guide build: September 2026
      Software-validated architecture. New BLE hardware profiles still require explicit bench acceptance.
                                                               SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC




SUPER SDL v0.7.0: Codex sees one laboratory fabric even when hardware, runtimes, and transports differ.




                                                                                             SUPER SDL v0.7.0 | 2
                                                           SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC




How to use this guide
If the goal is simply to get the system running, read Part I through “First successful
Codex session.” If the goal is to add a new board, runtime, or experimental capability,
continue into Part II. The deployment is deliberately layered: first make one node work,
then add the second.

 The shortest success path
 Unzip → prepare one node → configure gateway/config.json → INSTALL_GATEWAY.bat → RUN_GATEWAY.bat
 → TEST_MCP.bat → INSTALL_CODEX_MCP.bat → ask Codex to discover the laboratory.




Contents
Section                                           What it gives you

Part I — User Guide                              Mental model; installation; Pico W, UNO/MFS/HM-10,
                                                 micro:bit/NUS bring-up; Codex; Traffic Cop; first
                                                 experiments.

Part II — Programmer Guide                       SDL protocol; node contract; BLE framing;
                                                 fixed/interpreted/dynamic nodes; Gateway/MCP;
                                                 deployment; LIGHTENING.

Appendices                                       Troubleshooting, bench acceptance, command cheat
                                                 sheet, glossary, release map and validation boundary.




                                                                                     SUPER SDL v0.7.0 | 3
                                                                    SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC



Version matrix
Component                                              Version / target

SUPER SDL complete release                             0.7.0

PC SDL Gateway                                         0.7.0

High-end Pico W runtime                                0.7.0

Traffic Cop                                            1.3.0

SDL ASCII Protocol                                     1.0.0

Capability API                                         1.0.0

MCP target                                             2026-07-28

UNO/MFS HM-10 reference                                0.1.0

micro:bit v2 NUS reference                             0.1.0

Pico W MicroPython/NUS reference                       0.1.0


Validation boundary
Desktop tests pass for version consistency, Python compilation, multi-node routing, BLE-style fragmentation,
default dynamic Pico tools, fixed UNO-style nodes, Traffic Cop capture, and fail-open monitoring. Physical
HM-10 clones, exact MFS pin maps, DS18B20 wiring, micro:bit robot bindings, Windows BLE, and real Pico
network behavior still require bench acceptance.




                                                                                             SUPER SDL v0.7.0 | 4
                                                                       SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC


PART I


User Guide
Start with one node, prove the path, then grow into a multi-
node laboratory.




1. The mental model
SUPER SDL v0.7.0 moves the center of gravity away from any one processor. Codex talks
MCP to the Windows Gateway. The Gateway discovers and routes to small SDL nodes.
The nodes may be an UNO/MultiFunction Shield over HM-10 BLE, a micro:bit v2 robot
over Nordic UART Service, or a high-end Pico W over Wi-Fi/TCP. Traffic Cop receives
copies only.




         The control path is Codex → MCP → Gateway → SDL ASCII → node. Traffic Cop is never inline by default.


The stable rule

 One rule to remember
 SDL standardizes laboratory meaning and a human-readable command stream. It does not standardize


                                                                                                     SUPER SDL v0.7.0 | 5
                                                              SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC



 processor, programming language, or transport.



A logical operation such as DEV.READ ID=temp1 should mean the same thing whether the bytes travel
through TCP, Nordic NUS, or an HM-10 transparent UART. The Gateway hides transport details from Codex
while preserving node identity, units, provenance, and extensibility.

Three node personalities




Fixed nodes are not “less compatible” with Codex. They simply have a deliberate compiled vocabulary.
Interpreted AVR eForth nodes can gain new words without a full firmware rebuild. Dynamic-package Pico
W nodes can install transactionally validated capability packages. Codex can use every class.

Timing belongs near the hardware
BLE and MCP are supervisory channels, not precision timing engines. Fast sampling, motor PWM, encoder
decoding, IMU acquisition, buffering, and control loops stay local. The PC/Codex layer plans, configures,
orchestrates, analyzes, graphs, fits, and documents.

 Practical timing rule
 Do not implement a 100–200 Hz experiment as 100–200 MCP/BLE round trips per second. Ask the node to
 capture locally and return a summary or buffered samples.




2. What you need
PC software
• Windows PC with Python 3 available as py.

• Node.js is needed only for Traffic Cop.

• Codex CLI/environment with the codex command if you want direct MCP registration.

• The complete SUPER_SDL_COMPLETE_v0.7.0 release.




                                                                                        SUPER SDL v0.7.0 | 6
                                                                  SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC



Choose at least one node
Node                        Runtime                   Transport                    Best first use

Pico W high-end             CircuitPython             Wi-Fi/TCP                    Dynamic capability
                                                                                   deployment and rich
                                                                                   experiments

UNO + MFS                   Arduino/C++ or px-fwlib   HM-10 BLE UART               Very inexpensive bench
                                                                                   time/temp/light/distance I/O

UNO + MFS                   AVR eForth                HM-10 BLE UART               Interactive interpreted
                                                                                   extension

micro:bit v2 / 2WD          Arduino + h2zero NimBLE   Nordic NUS BLE               Mobile lab / robotics

Pico W lightweight          MicroPython               Nordic NUS BLE               Optional common-BLE Pico
                                                                                   profile


Recommended bring-up discipline
Start with exactly one required node. Mark other configured nodes disabled or required:false. Add a second
node only after the first path passes TEST_MCP.




3. First successful run — one page




            Unzip Put the release at C:\SDL\SUPER_SDL_COMPLETE_v0.7.0\ or another short, writable
   1        path.

            Prepare one node Choose Pico W, UNO/MFS/HM-10, or micro:bit/NUS. Do not try to debug
   2        three transports at once.

            Configure Gateway Copy gateway\config_example.json to gateway\config.json. Enable only
   3        the node(s) actually on the bench.




                                                                                             SUPER SDL v0.7.0 | 7
                                                                  SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC



           Install and test Run INSTALL_GATEWAY.bat, optionally start Traffic Cop, then
   4       RUN_GATEWAY.bat and TEST_MCP.bat.

           Register Codex Run INSTALL_CODEX_MCP.bat and VERIFY_CODEX_MCP.bat, then launch
   5       Codex in the project directory and ask it to discover the laboratory.


 What success looks like
 Gateway prints at least one node as OK, shows MCP at http://127.0.0.1:8000/mcp, TEST_MCP succeeds, and
 Codex can list node(s), devices, and capabilities.




4. Install the PC side
Unzip the release
 C:\SDL\SUPER_SDL_COMPLETE_v0.7.0\
   gateway\
   traffic_cop\
   pico\
   nodes\
   service_plane\
   docs\



Install Gateway dependencies
In the gateway folder, double-click:

 INSTALL_GATEWAY.bat

The batch file creates config.json from config_example.json if necessary, then installs the current Gateway
requirements: zeroconf and bleak. Bleak provides Windows BLE access for NUS and HM-10 profiles.

Traffic Cop is optional
 traffic_cop\RUN_TRAFFIC_COP.bat

Traffic Cop is a passive multi-node communications observer. It receives exact TX/RX copies and semantic
activity from the Gateway. If it closes or crashes, control must continue.

 Failure-boundary test
 After everything works, close Traffic Cop and run TEST_MCP again. If laboratory control stops, the
 architecture has been wired incorrectly.




5. Configure gateway/config.json
The Gateway is the one place where transport-specific information belongs. Codex should not need to
know BLE UUIDs, IP addresses, or UART details.


                                                                                             SUPER SDL v0.7.0 | 8
                                                                                 SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC


Reference configuration; copy to config.json and edit.

 {
     "default_node": "super-bench-01",
     "nodes": [
       {"id":"super-bench-01","transport":"tcp","host":"auto","port":8765,
        "token":"super-demo","required":true,"extensibility":"dynamic-package","enabled":true},
       {"id":"uno-mfs-01","transport":"ble-hm10","name":"HMSoft",
        "required":false,"extensibility":"fixed","enabled":false},
       {"id":"microbit-robot-01","transport":"ble-nus","name":"SDL-MBIT-01",
        "required":false,"extensibility":"fixed","enabled":false}
     ],
     "mcp_host":"127.0.0.1",
     "mcp_port":8000,
     "traffic_cop_url":"http://127.0.0.1:8787"
 }



Rules that save time
 • Every enabled node needs a stable id.

 • Use required:true for the one node that must be present; optional nodes should normally be
   required:false.

 • For TCP host:auto, the Gateway performs discovery before constructing the transport.

 • For BLE, match the advertised name or specify an address. HM-10 service/characteristic UUIDs can be
   overridden for clone firmware.

 • default_node controls backward-compatible sdl_ping/sdl_info and named dynamic tools from the
   default high-end node.


6. Track A — High-end Pico W / CircuitPython / Wi-Fi
Use this path when dynamic package deployment, Web Workflow administration, larger transfers, or the
richest local experiment runtime matter more than common BLE symmetry.

               Copy Pico files Copy the contents of the top-level pico folder to the root of the Pico W
      1        CIRCUITPY drive.

               Create settings.toml Copy settings_example.toml to settings.toml, enter Wi-Fi credentials,
      2        node name, token, and Web Workflow settings.

 CIRCUITPY_WIFI_SSID="YOUR_WIFI_NAME"
 CIRCUITPY_WIFI_PASSWORD="YOUR_WIFI_PASSWORD"
 CIRCUITPY_WEB_API_PASSWORD="change-me"
 CIRCUITPY_WEB_INSTANCE_NAME="SUPER Bench 01"
 SUPER_NODE_NAME="super-bench-01"
 SUPER_SDL_PORT="8765"
 SUPER_SDL_TOKEN="super-demo"

               Power-cycle Let boot.py and code.py start the v0.7 runtime. Normal machine control is Wi-Fi
      3        TCP on port 8765; USB remains console/filesystem rescue.




                                                                                                          SUPER SDL v0.7.0 | 9
                                                                       SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC



           Configure the Gateway Enable only the super-bench-01 TCP entry at first. Leave host:auto
   4       unless manual addressing is necessary.


 Current Pico temp1
 The high-end v0.7 Pico runtime still binds temp1 to a truthful local simulation (SIM-DS18B20). RP2040
 cpu_temp may be hardware-backed. Do not describe temp1 as a physical water sensor until a physical
 backend is actually bound.




Dynamic package example
The bundled Newton Cooling capability advertises cooling_start, cooling_sample, cooling_status, and
cooling_stop. Its manifest requires the logical sensor role temp1. That role may be simulated or later
rebound to physical hardware without changing the experiment vocabulary.


7. Track B — UNO/MFS + HM-10 + waterproof
DS18B20
This is the low-cost bench-computer path: time, temperature, light, potentiometer position, ultrasonic
distance, LED control, and a snapshot capability over a transparent BLE UART.




 Reference defaults from UNO_MFS_SDL_HM10.ino. Verify your actual MultiFunction Shield and HM-10 carrier before wiring.


Firmware bring-up

         1      Open the supplied sketch nodes\uno_mfs_hm10\arduino\UNO_MFS_SDL_HM10.ino



                                                                                                   SUPER SDL v0.7.0 | 10
                                                                  SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC




                Install libraries Install OneWire and DallasTemperature in the Arduino
            2   environment.

                Verify the pin map Reference defaults are DS18B20 D9, ultrasonic TRIG D5 / ECHO
            3   D6, light A4, potentiometer A0, LED D13.

                Flash the UNO The reference uses hardware Serial at 9600 baud for the HM-10
            4   transparent UART.

                Enable the BLE node In config.json set uno-mfs-01 enabled:true and configure
            5   name/address/UUIDs as needed.


What the reference node exposes
Logical id                          Meaning                               Direction

time1                               millis() elapsed time, ms             read

temp1                               waterproof DS18B20 temperature, °C    read

light1                              analog light raw value                read

pot1                                MFS potentiometer raw value           read

distance1                           HC-SR04-class distance, mm            read

led1                                logical LED output                    write

The fixed capability snapshot returns time, temperature, light, potentiometer, and distance in one
transaction.

 Electrical caution
 D0/D1 are shared with USB serial on a classic UNO. Do not drive the UART simultaneously from two external
 sources. Many HM-10 carrier boards accept 5 V power while the module UART remains 3.3 V logic; verify the
 carrier and level-shift UNO TX if required.




 Standard DS18B20 bench practice
 For a normal three-wire DS18B20 installation, use VCC, GND, and DATA with a 4.7 kΩ pull-up from DATA to
 VCC. Avoid parasite-power mode for this teaching/bench node. Wire colors on waterproof probes are not
 guaranteed; verify your probe.




                                                                                          SUPER SDL v0.7.0 | 11
                                                                   SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC




8. Track C — micro:bit v2 / Arduino + NimBLE / NUS
This profile deliberately follows the project’s already-successful micro:bit v2 path: Arduino IDE, h2zero
NimBLE-Arduino, and Nordic UART Service. MicroPython is not the preferred runtime for this nRF52833
robot role.

What the supplied sketch already does
• Advertises as SDL-MBIT-01.

• Implements Nordic UART Service with the standard 6E400001/2/3 UUID set.

• Accumulates BLE fragments until newline before parsing SDL.

• Exposes time1 plus placeholder distance1 and battery1 devices.

• Exposes drive_set and drive_stop capabilities.

• Keeps fast motor/encoder/IMU work local.

What you must bind for your exact 2WD robot
Replace the profile hooks with your already-proven robot hardware bindings.

 static int appDistanceMm() { return -1; }
 static int appBatteryMv() { return -1; }
 static void appDrive(int leftPct, int rightPct) { ... }
 static void appStop() { appDrive(0,0); }


 Important
 Until these hooks are bound and locally tested, distance/battery may report unbound and drive_set cannot be
 treated as a physically accepted motion command.




Recommended future robot vocabulary
Keep hardware-specific loops below SDL. Above them, stable roles can include distance1, imu1,
encoder_left, encoder_right, battery1 and capabilities such as drive_set, drive_stop, turn, capture_imu, and
drive_distance.


9. Start Gateway, test MCP, register Codex
Start the Gateway
 gateway\RUN_GATEWAY.bat

A healthy start prints the configured nodes as OK or OFFLINE, then:

 MCP : http://127.0.0.1:8000/mcp
 Health : http://127.0.0.1:8000/health




                                                                                           SUPER SDL v0.7.0 | 12
                                                                      SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC



Run the smoke test
 gateway\TEST_MCP.bat

The smoke test exercises the local MCP server. If this fails, fix the Gateway/node path before involving
Codex.

Register the local MCP server with Codex once
 gateway\INSTALL_CODEX_MCP.bat
 gateway\VERIFY_CODEX_MCP.bat

The installer registers the MCP server name super-sdl at http://127.0.0.1:8000/mcp. The verifier checks the
Codex registration, Gateway health, and configured MCP servers.

 Launch location matters
 Open Codex in the SUPER SDL project directory so AGENTS.md is in scope. That file teaches Codex the
 laboratory model, discovery order, timing rules, extensibility classes, Traffic Cop boundary, and safety rules.




10. First successful Codex session
Start with discovery. Do not ask Codex to assume what is on the bench.

 Discover the available SUPER SDL nodes, devices, and capabilities.
 Do not assume hardware that is not reported.



What Codex should do
                  node_list(refresh=true) Find configured nodes, transports, online state, runtime
          1       information, and extensibility class.


          2       node_info(node=...) Read one node’s identity and protocol metadata.


                  device_list(node=...) Discover stable logical devices such as temp1, distance1, or
          3       led1.

                  capability_list(node=...) Discover fixed, interpreted, or dynamically installed
          4       higher-level operations.


Useful first prompts
• “Read temp1 from uno-mfs-01 and report the value, units, and backend.”

• “List the capabilities on super-bench-01 and explain which are dynamically packaged.”

• “Show me every node and classify it as fixed, interpreted, or dynamic-package.”

• “Read all safe, read-only devices you can find. Do not actuate anything.”



                                                                                              SUPER SDL v0.7.0 | 13
                                                                         SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC




            One MCP tool call becomes an SDL transaction; Traffic Cop receives byte copies but is not the path.



11. Tutorial — a real low-rate temperature
experiment on UNO/MFS
This tutorial is intentionally simple because it proves the AI-to-physical-sensor loop without requiring a
new firmware capability. It is appropriate for Newton-style cooling where 5–10 second timing is sufficient.

          Prepare the probe Place the waterproof DS18B20 in the liquid. Keep electronics dry and
   1      strain-relieve the probe lead.

          Confirm provenance Ask Codex to read uno-mfs-01:temp1 once. The result should report
   2      backend=DS18B20, not simulation.

          Acquire slowly Ask Codex to record temp1 every 10 seconds for 10 minutes. At this low rate,
   3      PC-supervised timing is reasonable.

          Analyze Ask Codex to plot temperature versus elapsed time, fit an exponential cooling model,
   4      retain raw readings, and report residuals.

          Improve the node later If you want precise or high-rate local timing, add a fixed capture
   5      capability to the UNO rather than increasing MCP/BLE round trips.


 Scientific provenance
 The Pico W default temp1 is simulated. The UNO/MFS reference temp1 is a physical DS18B20 when correctly
 wired. Codex should preserve that distinction in any analysis.




                                                                                                       SUPER SDL v0.7.0 | 14
                                                                    SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC




12. Traffic Cop — what it is for
Traffic Cop 1.3.0 is the observability layer. It receives exact byte copies and semantic activity records from
the Gateway, grouped by node/transport. It is useful for teaching, protocol debugging, and proving what
Codex actually asked the laboratory to do.

Use it to answer four questions
• What did Codex request?

• What exact SDL bytes did the Gateway transmit?

• What exact response came back from which node?

• Did the control path continue when the monitor was absent?

 Normal mode vs diagnostic proxy
 Normal mode is passive and fail-open. The diagnostic inline proxy exists for forensic testing only; it is not the
 normal control architecture.




                                                                                               SUPER SDL v0.7.0 | 15
                                                              SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC


PART II


Programmer Guide
Implement the small contract correctly and let the
Gateway/MCP layer make heterogeneous hardware look
coherent.




13. The layer model




The most important programming discipline is to keep semantics, SDL framing, transport, runtime, and
hardware concerns separate. A new transport should not change DEV.READ. A new processor should not
change the Codex tool name. A new capability should not invent a new wire grammar.


14. SDL ASCII Protocol 1.0.0
SDL is a line-oriented request/response protocol. The current contract uses CRLF and human-readable
UTF-8 records. Ordinary identifiers and numbers remain visible; percent escaping is used when a scalar
contains spaces or reserved/non-ASCII bytes.

Request
 CMD 104 DEV.READ ID=temp1




                                                                                      SUPER SDL v0.7.0 | 16
                                                                        SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC



Successful response
 RSP 104 OK COUNT=1
 DAT 104 DEVICE id=temp1 temperatureC=22.84 status=ok backend=DS18B20
 END 104



Error response
 RSP 105 ERR CODE=COMMAND_ERROR DETAIL=unknown%20readable%20device%3A%20foo
 END 105



Core verbs
Verb                                                       Purpose

AUTH TOKEN=...                                             Connection authentication when configured

PING                                                       Reachability / node proof

INFO / VERSION                                             Node identity and runtime metadata

DEV.LIST                                                   Inventory stable logical devices

DEV.READ ID=...                                            Read one logical device

DEV.WRITE ID=... VALUE=...                                 Write one logical output

CAP.LIST                                                   List higher-level command vocabulary

PKG.LIST                                                   List installed packages; optional on fixed nodes

CAP.CALL NAME=...                                          Invoke a capability with key=value arguments

SYS.RELOAD                                                 Administrative runtime reload where supported


 Extension rule
 Experiment packages should normally register capability names and use CAP.CALL. Do not invent new
 transport grammar for each experiment.




15. The node contract
Every useful node should prove identity, expose stable device roles, and state enough metadata for the
Gateway and Codex to reason correctly.

Minimum recommended operations
• PING

• INFO / VERSION

• DEV.LIST


                                                                                                   SUPER SDL v0.7.0 | 17
                                                                                    SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC


• DEV.READ

• DEV.WRITE when outputs exist

• CAP.LIST

• CAP.CALL when higher-level capabilities exist

PKG.LIST is optional on fixed/interpreted nodes and expected on dynamic-package nodes.

Recommended INFO fields
Field                                         Meaning                                       Example

node                                          stable node id                                uno-mfs-01

runtime                                       software version                              UNO-MFS-SDL-0.1.0

protocol                                      SDL wire version                              1.0.0

platform                                      processor/platform                            ATmega328P

runtimeKind                                   programming/runtime model                     Arduino / AVR-eForth / CircuitPython

transport                                     active transport                              ble-hm10 / ble-nus / tcp

profile                                       human-meaningful node type                    uno-mfs

extensibility                                 fixed / interpreted / dynamic-package         fixed


 Name roles, not wiring
 Prefer temp1 over DS18B20-on-pin-9. Stable roles let experiments survive a backend or hardware change.




16. BLE field transport
v0.7 treats BLE as the probable common transport for lightweight nodes. The Gateway uses Bleak and
supplies two byte-stream profiles.

Profile                           Service                             Write                              Notify

Nordic NUS                        6E400001-B5A3-F393-E0A9-            6E400002...                      6E400003...
                                  E50E24DCCA9E

HM-10 default                     FFE0                                FFE1                             FFE1



Fragmentation rule
A BLE notification is not an SDL message. It is only a byte fragment. The receiver must accumulate bytes
until newline, then pass a complete line to the SDL parser. The Gateway’s fragmentation test deliberately
proves this behavior.

 incoming bytes -> buffer -> find \n -> complete SDL line -> parser




                                                                                                                  SUPER SDL v0.7.0 | 18
                                                                        SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC



 Never bind protocol to BLE packet boundaries
 A response may be split across several 20-byte notifications. Correct code behaves identically whether one
 line arrives in 1 fragment or 10.




17. Implementing a fixed node: Arduino or px-fwlib
A fixed node is often the best engineering answer. It can still be fully discoverable and useful to Codex.
The PC can compose higher-level procedures from its stable vocabulary.

Recommended parser shape
 loop:
  receive bytes
  append until newline
  parse: CMD <txid> <verb> [KEY=value ...]
  dispatch verb
  emit RSP / DAT / END using the same txid



UNO/MFS reference
The supplied Arduino sketch implements PING, INFO, DEV.LIST, DEV.READ, DEV.WRITE for led1, CAP.LIST,
PKG.LIST with zero packages, and CAP.CALL snapshot. The px-fwlib directory intentionally freezes the
same integration seam without inventing px-fwlib APIs that may differ from the established project tree.

px-fwlib identity example
 runtimeKind=px-fwlib platform=ATmega328P transport=ble-hm10 extensibility=fixed




18. Interpreted node: AVR eForth
AVR eForth creates the middle extensibility tier: a tiny resident SDL parser can map stable device roles to
Forth words, while new procedures are deposited without reflashing the whole AVR.

 : TEMP@ ( -- milli-C ) ... ;
 : LIGHT@ ( -- raw )      ... ;
 : DIST@ ( -- mm )       ... ;
 : LED! ( flag -- ) ... ;

 : COOLING-SAMPLE TEMP@ TICKS ... ;


 v0.7 boundary
 Forth deposition is an administrative/development operation in v0.7, not an automatically exposed MCP
 action. Codex may propose words; the operator approves installation. A later release can add transactional
 Forth deposition.




                                                                                                SUPER SDL v0.7.0 | 19
                                                                                   SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC




19. micro:bit v2 NUS programmer profile
The reference sketch is primarily a transport seam plus a deliberately small robot vocabulary. It uses
NimBLE notifications in 20-byte chunks and a newline accumulator on receive.

NUS receive pattern
 for each BLE write fragment:
  for each byte:
   if byte == '\n': handleLine(buffer); clear buffer
   else if byte != '\r': append byte



Robot hooks
Keep appDrive, appStop, appDistanceMm, appBatteryMv, IMU sampling, encoders, and closed-loop control
local. Expose their stable meanings through DEV.* and CAP.* operations. Do not push motor timing into
BLE.

Safety

 Movement is a physical action
 Codex should not infer that a reference drive function is safe simply because a capability is present. Bind and
 test the robot locally first; use explicit operator awareness around people, drop-offs, fragile equipment, or
 higher-energy mechanisms.




20. High-end Pico W dynamic packages
The Pico W/CircuitPython profile remains the primary dynamic-retasking node. The permanent runtime
stays small; experiment packages live under /capabilities and are validated before becoming visible.

Manifest example
 {
     "apiVersion": "1.0.0",
     "id": "newton_cooling",
     "version": "0.3.0",
     "provides": ["cooling_start","cooling_sample","cooling_status","cooling_stop"],
     "requires": {"sensors": ["temp1"]},
     "tools": [ ... MCP descriptions and schemas ... ]
 }



Transactional deployment sequence
                     Local preflight Validate manifest, required files, unique provides list, and Python
             1       syntax.


             2       Stage Upload into /staging/<package>.next through CircuitPython Web Workflow.



                                                                                                           SUPER SDL v0.7.0 | 20
                                                                        SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC




            3         Read-back verify Read every staged file and verify exact bytes. Write READY last.


                      Activate Preserve the previous active package under /rollback, then move the
            4         staged directory into /capabilities.

                      Reload and semantic check Request SYS.RELOAD and require CAP.LIST to contain
            5         every promised command.

                      Rollback on failure Restore the previous package automatically unless --no-auto-
            6         rollback was explicitly requested.


Deployment CLI
 py deploy.py install extensions\newton_cooling ^
  --host <PICO-IP-or-hostname> ^
  --web-password <password> ^
  --sdl-token super-demo

If CircuitPython reports the filesystem not writable through Web Workflow, eject/unmount the CIRCUITPY
mass-storage volume while leaving USB power connected, then retry.


21. Gateway programmer model
The Gateway owns the multi-node registry and transport adapters. It validates SDL protocol 1.0.0 when
probing a node. One node can be default, but every tool can target a node explicitly.

Base MCP tools
Tool                                                        Meaning

node_list                                                   List configured nodes, transport, online state, runtime,
                                                            extensibility

node_info                                                   Read one node identity

node_ping                                                   Verify one node

sdl_ping / sdl_info                                         Backward-compatible default-node aliases

device_list                                                 List devices on a node

device_read                                                 Read logical device

device_write                                                Write logical device

capability_list                                             List commands/packages

capability_call                                             Invoke a capability on any node




                                                                                                       SUPER SDL v0.7.0 | 21
                                                                SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC



Named dynamic tools
For the default high-end node, the Gateway extension catalog can publish named MCP tools from an active
dynamic package, such as cooling_start. Other nodes remain reachable through capability_call(node=...,
name=...).

Adding a new transport
Implement the byte-transport interface used by gateway/transports: open, close, sendall, recv, and
descriptive source/destination labels. Then add construction logic in transports/factory.py. The SDL client
above it should not change.


22. How Codex learns the laboratory
Codex does not “know” the bench from a giant prompt. The MCP server gives it a discoverable tool catalog,
while AGENTS.md teaches operating policy and the intended discovery sequence.

 1. node_list(refresh=true)
 2. node_info(node=...)
 3. device_list(node=...)
 4. capability_list(node=...)
 5. choose the smallest appropriate operation



Why this is important
The model can discover that one node is fixed Arduino over HM-10, another is Arduino-NimBLE over NUS,
and another is a dynamic CircuitPython Pico. It can use all three without their runtimes being
standardized.

 Codex-facing abstraction
 MCP standardizes AI tool discovery. SDL standardizes small-machine laboratory meaning. The Gateway is
 the adapter between them.




23. Traffic Cop programmer boundary
Gateway traffic_reporter.py sends fail-open copies to Traffic Cop. Exceptions in the monitor path must
never break control. Traffic Cop 1.3.0 can display multi-node sessions and also retains a diagnostic proxy
mode for forensic byte-accuracy work.

Design invariant
 kill Traffic Cop -> device_read still succeeds

The architecture test explicitly verifies that invariant.




                                                                                         SUPER SDL v0.7.0 | 22
                                                                          SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC




24. LIGHTENING debugWIRE — service/recovery
plane
LIGHTENING belongs beneath ordinary SDL use. SDL asks a healthy instrument to perform laboratory
work. debugWIRE can halt the CPU, inspect registers or memory, step code, repair, or reflash: a
fundamentally higher privilege level.

 NORMAL LABORATORY PLANE
 Codex -> MCP -> SDL Gateway -> BLE/HM-10 -> UNO/MFS

 DEVELOPMENT / RECOVERY PLANE
 Codex or operator -> LIGHTENING bridge -> debugWIRE -> ATmega328P



Potential future namespace — disabled by default
• debug.halt

• debug.resume

• debug.step

• debug.read_memory

• debug.read_registers

• debug.set_breakpoint

• debug.flash_firmware

 v0.7 status
 LIGHTENING is integrated architecturally, but an MCP debug bridge is not claimed implemented in this
 release. State-changing debug operations should require explicit operator approval and safe fuse handling.




25. Design rules worth freezing
Rule                                                        Why it matters


Transport is interchangeable                                Do not let TCP, NUS, or HM-10 leak into experiment meaning.


Names describe roles                                        Use temp1, distance1, led1; keep pin numbers and chip models
                                                            underneath.


Fast loops stay local                                       Communications configure and report; they do not become the control
                                                            clock.


No silent physical retry                                    If bytes may have reached the node and the response was lost, do not
                                                            automatically repeat the action.


Traffic Cop is never required                               Observability is not control.


Dynamic deployment is administrative                        Do not let an ordinary experiment call silently rewrite live code.


Preserve provenance                                         Measured, simulated, replayed, derived, and estimated values are not




                                                                                                             SUPER SDL v0.7.0 | 23
                                                                       SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC


Rule                                                      Why it matters


                                                          interchangeable.


Use the simplest extensibility tier                       Fixed is often better; interpreted and dynamic are available when the
                                                          experiment truly needs them.


APPENDICES


Operate, Diagnose, Accept
Use these pages at the bench when something fails or when a
new node is ready for acceptance.




A. Troubleshooting
Symptom                                                   Likely cause / next move


Gateway says BLE device not found                         Confirm node power and advertised name; set exact address if
                                                          useful; for HM-10 clones verify service/characteristic UUIDs.

HM-10 connects but no valid SDL lines                     Check 9600 UART, TX/RX crossing, grounds, voltage levels, and CR/LF
                                                          framing. Do not simultaneously drive UNO D0/D1 from USB and
                                                          HM-10.

UNO temp1 reports fault                                   Verify DS18B20 three-wire power, DATA pin, pull-up resistor, library
                                                          install, and probe wiring.

micro:bit distance/battery says unbound                   Expected until appDistanceMm/appBatteryMv are bound to real
                                                          robot drivers.

micro:bit drive does nothing                              Reference appDrive/appStop hooks still need robot-specific
                                                          implementation; do not treat as accepted motion control yet.

TCP node host:auto fails                                  Use a manual host/IP temporarily and verify the Pico is on the same
                                                          network.

TEST_MCP fails but Gateway is running                     Read Gateway console for OFFLINE/required node errors; reduce
                                                          config to one known-good node.

Codex cannot see super-sdl                                Run INSTALL_CODEX_MCP.bat then VERIFY_CODEX_MCP.bat; ensure
                                                          Gateway health responds at 127.0.0.1:8000/health.

Traffic Cop is blank                                      Gateway may have monitor disabled, or no SDL traffic has occurred
                                                          yet. Control should still work.

Pico capability deployment says filesystem not writable   Eject/unmount CIRCUITPY while leaving USB power connected, then
                                                          retry Web Workflow deployment.




                                                                                                         SUPER SDL v0.7.0 | 24
                                                                 SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC




B. Bench acceptance checklist
The current desktop/software validation is strong, but each new physical combination still needs an
explicit bench acceptance run. Mark these as evidence, not assumptions.

• ☐ Gateway version/component audit passes.

• ☐ One node is configured required:true; all unrelated nodes disabled or optional.

• ☐ Node responds to PING and INFO with protocol=1.0.0.

• ☐ DEV.LIST matches the hardware actually present.

• ☐ Read-only sensor values are plausible and units/provenance are correct.

• ☐ BLE node remains correct when SDL lines are fragmented across notifications.

• ☐ Traffic Cop sees TX/RX copies but can be killed without affecting control.

• ☐ Writable outputs are tested locally and then through SDL.

• ☐ No command is silently retried after uncertain physical execution.

• ☐ UNO/HM-10 voltage levels and exact shield pin map are verified on the actual hardware.

• ☐ micro:bit robot motor/sonar/IMU bindings compile and are locally tested before Codex movement.

• ☐ Pico Web Workflow deployment, reload, semantic activation, and rollback are verified on the actual
  board.

• ☐ Raw experimental observations are retained before analysis/fitting.


C. Command cheat sheet
Goal                                                   Command / action

Install Gateway dependencies                          gateway\INSTALL_GATEWAY.bat

Start passive Traffic Cop                             traffic_cop\RUN_TRAFFIC_COP.bat

Start Gateway                                         gateway\RUN_GATEWAY.bat

Test local MCP                                        gateway\TEST_MCP.bat

Register Codex MCP                                    gateway\INSTALL_CODEX_MCP.bat

Verify Codex + Gateway                                gateway\VERIFY_CODEX_MCP.bat

Codex discovery prompt                                Discover the available SUPER SDL nodes, devices, and
                                                      capabilities.

Install Pico capability                               py deploy.py install <package_dir> --host <pico-host> --web-
                                                      password <pw> --sdl-token super-demo

Rollback Pico capability                              py deploy.py rollback <package_dir> --host <pico-host> --web-
                                                      password <pw> --sdl-token super-demo




                                                                                                SUPER SDL v0.7.0 | 25
                                                 SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC



Useful raw SDL lines
CMD 1 PING
CMD 2 INFO
CMD 3 DEV.LIST
CMD 4 DEV.READ ID=temp1
CMD 5 DEV.WRITE ID=led1 VALUE=true
CMD 6 CAP.LIST
CMD 7 CAP.CALL NAME=snapshot




D. Glossary
Term                                 Meaning in SUPER SDL v0.7

SDL                                  Human-readable small-machine laboratory protocol and
                                     semantic vocabulary.

MCP                                  AI/client-facing tool discovery and call interface terminating on
                                     the PC Gateway.

Node                                 One laboratory endpoint with identity, devices, capabilities,
                                     transport, runtime, and extensibility metadata.

Device role                          Stable logical resource such as temp1 or distance1 independent
                                     of pin/chip details.

Capability                           Higher-level operation invoked through CAP.CALL or, on the
                                     default dynamic Pico, sometimes published as a named MCP
                                     tool.

Fixed                                Compiled vocabulary; common for Arduino and px-fwlib.

Interpreted                          Resident interpreter can gain new words/procedures; AVR
                                     eForth tier.

Dynamic-package                      Transactional installable capability packages; high-end Pico W
                                     tier.

NUS                                  Nordic UART Service BLE profile used by the micro:bit v2
                                     reference node.

HM-10                                Transparent BLE UART module used to place the UNO/MFS
                                     UART onto BLE.

Traffic Cop                          Passive fail-open monitor receiving byte copies and activity.

Service plane                        Privileged diagnosis/recovery path such as
                                     LIGHTENING/debugWIRE, separate from normal experiment
                                     control.

Provenance                           Metadata describing whether a value is measured, simulated,
                                     replayed, derived, etc.




                                                                                SUPER SDL v0.7.0 | 26
                                                                         SUPER SDL / AI-ADDRESSABLE LABORATORY FABRIC




E. Release map and source of truth
 SUPER_SDL_COMPLETE_v0.7.0\
  gateway\           PC MCP/Gateway, transports, Codex integration
  traffic_cop\       passive monitor / diagnostic proxy
  pico\           high-end CircuitPython/TCP node
  nodes\
   uno_mfs_hm10\         Arduino, px-fwlib seam, AVR eForth seam
   microbit_v2_nus\      Arduino + NimBLE NUS robot profile
   pico_w_ble_micropython\optional BLE Pico profile
  service_plane\lightening\debugWIRE architectural seam
  docs\            protocol, architecture, transport, deployment notes
  tests\          release/version validation

For behavior specific to this release, the v0.7.0 code and manifests are the source of truth. This guide was
prepared against the packaged implementation and reran the supplied version audit, fragmentation test,
and multi-node end-to-end architecture test before publication.

 What is not yet claimed
 No physical acceptance is claimed here for your exact HM-10 clones, MFS shield revision, waterproof
 DS18B20 wiring, micro:bit board/library versions, 2WD robot bindings, Windows BLE behavior, or physical
 Pico W network/Web Workflow behavior. Those are the explicit next bench steps.




One sentence to keep

 SUPER SDL v0.7.0
 The AI-facing laboratory should remain stable even when the processor, programming language, transport,
 and amount of local extensibility change underneath it.




                                                                                                 SUPER SDL v0.7.0 | 27
