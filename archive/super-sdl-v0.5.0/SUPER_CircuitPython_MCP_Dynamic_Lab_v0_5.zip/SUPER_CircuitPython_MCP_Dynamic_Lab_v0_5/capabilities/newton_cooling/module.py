"""Newton cooling -- first dynamically deposited experimental personality.

This module is intentionally both useful and philosophical.

Before this package exists, SUPER knows about temperature, outputs, networks
and MCP.  It does *not* know what a Newton-cooling experiment is.

After this package is deposited and the runtime reloads, tools/list gains four
new verbs.  The permanent runtime has not been reflashed.  The physical board
has acquired an experimental idea late in its life.

That is the seed we care about.
"""

import math
import time


_state = {
    "running": False,
    "mode": None,
    "started": 0.0,
    "initial_c": None,
    "ambient_c": None,
    "tau_s": None,
    "samples": [],
}


def _schema(properties=None, required=None):
    return {
        "type": "object",
        "properties": properties or {},
        "required": required or [],
        "additionalProperties": False,
    }


def register(registry, lab):
    """Teach the resident laboratory four new experimental verbs."""

    # Importing the MCP result helper is acceptable because it belongs to the
    # stable SUPER capability API.  The package still knows nothing about HTTP,
    # sockets, Wi-Fi credentials, or how MCP requests arrive.
    from super.mcp import tool_ok

    def cooling_start(args):
        mode = str(args.get("mode", "model"))
        if mode not in ("model", "sensor"):
            raise ValueError("mode must be model or sensor")

        ambient = float(args.get("ambient_c", 22.0))
        tau = float(args.get("tau_s", 180.0))
        if tau <= 0:
            raise ValueError("tau_s must be > 0")

        if mode == "sensor":
            reading = lab.read_sensor("temp1")
            if reading.get("status") != "ok":
                raise ValueError("temp1 is unavailable")
            initial = float(reading["temperatureC"])
        else:
            initial = float(args.get("initial_c", 80.0))

        _state["running"] = True
        _state["mode"] = mode
        _state["started"] = time.monotonic()
        _state["initial_c"] = initial
        _state["ambient_c"] = ambient
        _state["tau_s"] = tau
        _state["samples"] = []

        return tool_ok("Newton cooling run started", {
            "mode": mode,
            "initialC": initial,
            "ambientC": ambient,
            "tauS": tau,
        })

    registry.register({
        "name": "cooling_start",
        "title": "Start Newton Cooling Experiment",
        "description": (
            "Start a Newton-cooling run. model mode is a causal virtual experiment; "
            "sensor mode uses the stable temp1 laboratory sensor and therefore crosses "
            "to real hardware without changing this experiment's MCP vocabulary."
        ),
        "inputSchema": _schema({
            "mode": {"type": "string", "enum": ["model", "sensor"]},
            "initial_c": {"type": "number"},
            "ambient_c": {"type": "number"},
            "tau_s": {"type": "number", "exclusiveMinimum": 0},
        }),
        "annotations": {"readOnlyHint": False},
    }, cooling_start)

    def cooling_sample(_args):
        if not _state["running"]:
            raise ValueError("no cooling run is active")

        elapsed = time.monotonic() - _state["started"]
        if _state["mode"] == "sensor":
            reading = lab.read_sensor("temp1")
            if reading.get("status") != "ok":
                raise ValueError("temp1 became unavailable")
            temp = float(reading["temperatureC"])
            backend = reading.get("backend", "unknown")
        else:
            # This is a *causal* virtual experiment, not a decorative wandering
            # sensor.  Time and model parameters determine the observation.
            temp = _state["ambient_c"] + (
                _state["initial_c"] - _state["ambient_c"]
            ) * math.exp(-elapsed / _state["tau_s"])
            backend = "causal-model"

        sample = {
            "elapsedS": round(elapsed, 3),
            "temperatureC": round(temp, 3),
            "ambientC": _state["ambient_c"],
            "backend": backend,
        }
        _state["samples"].append(sample)
        return tool_ok("cooling sample", sample)

    registry.register({
        "name": "cooling_sample",
        "title": "Sample Cooling Experiment",
        "description": "Take one timestamped observation from the active cooling run.",
        "inputSchema": _schema(),
        "annotations": {"readOnlyHint": False},
    }, cooling_sample)

    def cooling_status(_args):
        return tool_ok("cooling status", {
            "running": _state["running"],
            "mode": _state["mode"],
            "sampleCount": len(_state["samples"]),
            "initialC": _state["initial_c"],
            "ambientC": _state["ambient_c"],
            "tauS": _state["tau_s"],
        })

    registry.register({
        "name": "cooling_status",
        "title": "Cooling Experiment Status",
        "description": "Describe the currently active Newton-cooling run.",
        "inputSchema": _schema(),
        "annotations": {"readOnlyHint": True, "idempotentHint": True},
    }, cooling_status)

    def cooling_stop(_args):
        _state["running"] = False
        return tool_ok("Newton cooling run stopped", {
            "sampleCount": len(_state["samples"]),
            "samples": list(_state["samples"]),
        })

    registry.register({
        "name": "cooling_stop",
        "title": "Stop Newton Cooling Experiment",
        "description": "Stop the run and return samples collected by this capability.",
        "inputSchema": _schema(),
        "annotations": {"readOnlyHint": False, "idempotentHint": True},
    }, cooling_stop)
