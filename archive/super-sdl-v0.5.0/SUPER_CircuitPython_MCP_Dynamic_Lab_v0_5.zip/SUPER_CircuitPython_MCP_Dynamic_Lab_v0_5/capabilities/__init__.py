"""Active capability namespace.

Only folders in this namespace are imported by the SUPER core.
Desktop deployment happens through /staging first; /staging is intentionally
not a Python package and is never scanned by CapabilityManager.
"""
