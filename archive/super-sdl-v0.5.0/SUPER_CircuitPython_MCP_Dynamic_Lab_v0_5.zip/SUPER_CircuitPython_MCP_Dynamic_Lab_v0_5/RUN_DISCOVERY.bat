@echo off
setlocal
cd /d "%~dp0"
py desktop_discover.py %*
