"""Physically plausible desktop sensor models for the SUPER simulation host.

The purpose is not cinematic fake data.  It is *experimental plausibility*:
values remain in sensible ranges, related quantities influence each other, and
outputs can cause later observations.  That distinction lets software and AI
practice causal reasoning instead of merely consuming random numbers.
"""

import json
import math
import os
import time


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


class LcgNoise:
    def __init__(self, seed=0x51A7E):
        self.state = int(seed) & 0xFFFFFFFF

    def unit(self):
        self.state = (1664525 * self.state + 1013904223) & 0xFFFFFFFF
        return ((self.state >> 8) & 0xFFFFFF) / 16777215.0

    def symmetric(self, span=1.0):
        return (self.unit() * 2.0 - 1.0) * span


SCENARIOS = {
    "nominal": {
        "room_c": 22.5, "humidity_pct": 44.0, "pressure_hpa": 1013.2,
        "light_lux": 380.0, "noise_scale": 1.0, "fault_sensor": None,
    },
    "warm_room": {
        "room_c": 28.0, "humidity_pct": 52.0, "pressure_hpa": 1010.5,
        "light_lux": 420.0, "noise_scale": 1.0, "fault_sensor": None,
    },
    "bright_sun": {
        "room_c": 24.5, "humidity_pct": 40.0, "pressure_hpa": 1014.0,
        "light_lux": 8500.0, "noise_scale": 1.2, "fault_sensor": None,
    },
    "noisy_bench": {
        "room_c": 22.5, "humidity_pct": 44.0, "pressure_hpa": 1013.2,
        "light_lux": 380.0, "noise_scale": 6.0, "fault_sensor": None,
    },
    "sensor_fault": {
        "room_c": 22.5, "humidity_pct": 44.0, "pressure_hpa": 1013.2,
        "light_lux": 380.0, "noise_scale": 1.0, "fault_sensor": "light1",
    },
}


class TraceRecorder:
    """Append-only JSONL recorder suitable for later deterministic replay."""

    def __init__(self, path=None):
        self.path = path
        self.fp = open(path, "a", encoding="utf-8") if path else None

    def write(self, event, payload):
        if not self.fp:
            return
        row = {"wallTime": time.time(), "event": event, "payload": payload}
        self.fp.write(json.dumps(row, separators=(",", ":")) + "\n")
        self.fp.flush()

    def close(self):
        if self.fp:
            self.fp.close()
            self.fp = None


class ReplayWorld:
    """Replay recorded sensor.read results in order.

    Replay is intentionally conservative in v0.5: it reproduces sensor reads,
    while output events are accepted and logged but do not rewrite history.
    This is already useful for regression testing AI/client behavior against a
    previously captured laboratory session.
    """

    def __init__(self, path):
        self.rows = []
        self.waveforms = []
        with open(path, "r", encoding="utf-8") as f:
            for line in f:
                try:
                    row = json.loads(line)
                except Exception:
                    continue
                if row.get("event") == "sensor.read":
                    self.rows.append(row.get("payload", {}))
                elif row.get("event") == "waveform.capture":
                    self.waveforms.append(row.get("payload", {}))
        if not self.rows:
            raise ValueError("replay file contains no sensor.read events")
        self.pos = 0
        self.wave_pos = 0
        self.outputs = {}
        self.scenario = "replay"

    def read_sensor(self, sid):
        for _ in range(len(self.rows)):
            row = self.rows[self.pos % len(self.rows)]
            self.pos += 1
            if row.get("id") == sid:
                out = dict(row)
                out["backend"] = "win32-replay"
                return out
        raise KeyError("no replay data for sensor " + sid)

    def read_all(self):
        ids = sorted({r.get("id") for r in self.rows if r.get("id")})
        return {sid: self.read_sensor(sid) for sid in ids}

    def set_output(self, name, value):
        self.outputs[name] = value

    def set_scenario(self, name):
        raise ValueError("scenario cannot be changed during replay")

    def status(self):
        return {
            "mode": "replay", "scenario": "replay", "rows": len(self.rows),
            "waveformCaptures": len(self.waveforms),
        }

    def waveform(self, samples=64, sample_rate_hz=1000.0):
        if not self.waveforms:
            raise ValueError("replay file contains no waveform.capture events")
        row = dict(self.waveforms[self.wave_pos % len(self.waveforms)])
        self.wave_pos += 1
        row["backend"] = "win32-replay"
        return row


class SimulationWorld:
    """One causal virtual laboratory behind one Pico/SUPER node."""

    SENSOR_DESCRIPTORS = [
        {"id": "temp1", "model": "DS18B20", "interface": "1-Wire", "unit": "degC"},
        {"id": "light1", "model": "BH1750", "interface": "I2C", "unit": "lux"},
        {"id": "env1", "model": "BME280", "interface": "I2C", "unit": "mixed"},
        {"id": "adc1", "model": "SUPER-ADC", "interface": "ADC", "unit": "V"},
        {"id": "pot1", "model": "10k-POT", "interface": "ADC", "unit": "percent"},
        {"id": "accel1", "model": "MPU6050", "interface": "I2C", "unit": "g"},
    ]

    def __init__(self, scenario="nominal", seed=0x51A7E, recorder=None):
        self.noise = LcgNoise(seed)
        self.started = time.monotonic()
        self.last_update = self.started
        self.temperature_c = 22.5
        self.outputs = {
            "led": False, "gpio0": False,
            "pwm_frequency_hz": 1000.0, "pwm_duty_pct": 0.0,
        }
        self.recorder = recorder or TraceRecorder(None)
        self.scenario = None
        self.params = None
        self.set_scenario(scenario)
        self.temperature_c = float(self.params["room_c"])

    def elapsed(self):
        return time.monotonic() - self.started

    def set_scenario(self, name):
        if name not in SCENARIOS:
            raise ValueError("unknown scenario %r; choose %s" % (name, ", ".join(sorted(SCENARIOS))))
        self.scenario = name
        self.params = dict(SCENARIOS[name])
        self.recorder.write("scenario.set", {"scenario": name})
        return self.status()

    def _update_thermal(self):
        now = time.monotonic()
        dt = max(0.0, min(2.0, now - self.last_update))
        self.last_update = now
        # PWM is deliberately treated as an abstract heater stimulus in the
        # simulator.  This gives an immediate causal experiment without claiming
        # that a physical Pico PWM pin itself creates 8 C of heat.
        heater = clamp(float(self.outputs.get("pwm_duty_pct", 0.0)), 0.0, 100.0) / 100.0
        target = float(self.params["room_c"]) + 8.0 * heater
        tau_s = 45.0
        if dt > 0:
            alpha = 1.0 - math.exp(-dt / tau_s)
            self.temperature_c += (target - self.temperature_c) * alpha

    def _fault(self, sid):
        return self.params.get("fault_sensor") == sid

    def _stamp(self, result):
        out = dict(result)
        out.setdefault("status", "ok")
        out["backend"] = "win32-sim"
        out["scenario"] = self.scenario
        out["hostElapsedS"] = round(self.elapsed(), 3)
        self.recorder.write("sensor.read", out)
        return out

    def read_sensor(self, sid):
        self._update_thermal()
        t = self.elapsed()
        n = float(self.params["noise_scale"])
        if self._fault(sid):
            return self._stamp({"id": sid, "status": "fault", "value": None, "fault": "simulated sensor disconnect"})

        if sid == "temp1":
            v = self.temperature_c + 0.04 * math.sin(t / 7.0) + self.noise.symmetric(0.015 * n)
            return self._stamp({"id": sid, "model": "DS18B20", "temperatureC": round(v, 3)})

        if sid == "env1":
            ambient = float(self.params["room_c"]) + 0.18 * math.sin(t / 40.0)
            humidity = float(self.params["humidity_pct"]) - 1.4 * (ambient - float(self.params["room_c"])) + 1.2 * math.sin(t / 31.0 + 0.6)
            pressure = float(self.params["pressure_hpa"]) + 0.7 * math.sin(t / 120.0) + self.noise.symmetric(0.035 * n)
            return self._stamp({
                "id": sid, "model": "BME280",
                "temperatureC": round(ambient + self.noise.symmetric(0.025 * n), 3),
                "humidityPct": round(clamp(humidity + self.noise.symmetric(0.08 * n), 0, 100), 2),
                "pressureHpa": round(pressure, 2),
            })

        if sid == "light1":
            # A moderately slow daylight/HVAC-lab variation plus a small,
            # observable contribution from the Pico's logical LED output.
            base = float(self.params["light_lux"])
            v = base * (0.92 + 0.08 * math.sin(t / 18.0))
            if self.outputs.get("led"):
                v += 28.0
            v += self.noise.symmetric(max(0.5, base * 0.003) * n)
            return self._stamp({"id": sid, "model": "BH1750", "lux": round(max(0.0, v), 2)})

        if sid == "adc1":
            # An instrumentation-like source: 0.5 Hz signal around mid-supply.
            v = 1.65 + 0.70 * math.sin(2.0 * math.pi * 0.5 * t) + self.noise.symmetric(0.003 * n)
            v = clamp(v, 0.0, 3.3)
            return self._stamp({"id": sid, "model": "SUPER-ADC", "volts": round(v, 5), "rawU16": int(v / 3.3 * 65535)})

        if sid == "pot1":
            phase = (t % 60.0) / 60.0
            p = 100.0 * (phase * 2.0 if phase < 0.5 else 2.0 - phase * 2.0)
            p = clamp(p + self.noise.symmetric(0.12 * n), 0.0, 100.0)
            return self._stamp({"id": sid, "model": "10k-POT", "positionPct": round(p, 2), "rawU16": int(p / 100.0 * 65535)})

        if sid == "accel1":
            x = 0.008 * math.sin(t * 3.1) + self.noise.symmetric(0.0025 * n)
            y = 0.006 * math.sin(t * 2.4 + 0.9) + self.noise.symmetric(0.0025 * n)
            z = 1.0 + 0.004 * math.sin(t * 4.7) + self.noise.symmetric(0.0025 * n)
            return self._stamp({
                "id": sid, "model": "MPU6050",
                "xG": round(x, 5), "yG": round(y, 5), "zG": round(z, 5),
                "magnitudeG": round(math.sqrt(x*x + y*y + z*z), 5),
            })

        raise KeyError("unknown sensor " + str(sid))

    def read_all(self):
        return {d["id"]: self.read_sensor(d["id"]) for d in self.SENSOR_DESCRIPTORS}

    def set_output(self, name, value):
        self.outputs[name] = value
        self.recorder.write("output.event", {"output": name, "value": value})

    def waveform(self, samples=64, sample_rate_hz=1000.0):
        samples = max(1, min(int(samples), 2048))
        rate = max(1.0, float(sample_rate_hz))
        t0 = self.elapsed()
        vals = []
        for i in range(samples):
            tt = t0 + i / rate
            v = 1.65 + 0.70 * math.sin(2.0 * math.pi * 0.5 * tt) + self.noise.symmetric(0.002 * self.params["noise_scale"])
            vals.append(round(clamp(v, 0.0, 3.3), 5))
        out = {
            "channel": "adc1", "samples": vals, "sampleRateHz": rate,
            "unit": "V", "backend": "win32-sim", "scenario": self.scenario,
        }
        self.recorder.write("waveform.capture", out)
        return out

    def status(self):
        return {
            "mode": "live-simulation",
            "scenario": self.scenario,
            "availableScenarios": sorted(SCENARIOS),
            "sensorCount": len(self.SENSOR_DESCRIPTORS),
            "outputs": dict(self.outputs),
            "elapsedS": round(self.elapsed(), 3),
        }
