#!/usr/bin/env python3
"""SUPER v0.5 Windows simulation host.

The workstation has three jobs and only three jobs:

1. discover a SUPER Pico automatically on the dedicated USB CDC data port;
2. provide realistic/causal simulated physical state to that Pico; and
3. expose a *localhost transport bridge* to the Pico's resident MCP dispatcher.

The third point is important.  The Windows process does NOT mirror the Pico's
MCP tool registry.  It forwards JSON-RPC to the Pico over USB and returns the
Pico's response.  Consequently a USB-only Pico remains the one authoritative
laboratory identity and can be used with no Wi-Fi at all.

Run on Windows:

    py -m pip install -r requirements-desktop.txt
    py -m sim_host.server

No COM port or Pico IP address is configured.
"""

import argparse
import json
import os
import socket
import threading
import time
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from .models import ReplayWorld, SimulationWorld, TraceRecorder

PROTOCOL = "SUPER-SIM/1"
MCP_PROTOCOL = "2026-07-28"
BAUD = 115200  # CDC ignores baud electrically; pyserial still requires a value.
DEFAULT_CONTROL_PORT = int(os.getenv("SUPER_SIM_CONTROL_PORT", "8765"))
MAX_MCP_BODY = 128 * 1024
PICO_CIRCUITPYTHON_VID = 0x2E8A
PICO_CIRCUITPYTHON_PID = 0x000B

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    serial = None
    list_ports = None

try:
    from zeroconf import IPVersion, ServiceInfo, Zeroconf
except ImportError:
    IPVersion = ServiceInfo = Zeroconf = None



def _safe_node_name(value):
    text = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in str(value or "node"))
    return text or "node"


def _node_trace_path(base, node):
    if not base:
        return None
    safe = _safe_node_name(node)
    if "{node}" in base:
        return base.replace("{node}", safe)
    root, ext = os.path.splitext(base)
    return "%s-%s%s" % (root, safe, ext or ".jsonl")


def _looks_like_circuitpython_port(p, probe_all=False):
    """Conservatively select Pico CircuitPython serial candidates.

    Both console and data CDC interfaces share the same USB identity, so this
    filter narrows the device family while the passive SUPER hello identifies
    the dedicated data port.
    """
    if probe_all:
        return True
    if getattr(p, "vid", None) == PICO_CIRCUITPYTHON_VID and getattr(p, "pid", None) == PICO_CIRCUITPYTHON_PID:
        return True
    text = " ".join(str(x or "") for x in (
        getattr(p, "product", None), getattr(p, "description", None), getattr(p, "manufacturer", None)
    )).lower()
    return "circuitpython" in text


def frame(obj):
    x = dict(obj)
    x.setdefault("protocol", PROTOCOL)
    return (json.dumps(x, separators=(",", ":")) + "\n").encode("utf-8")


class MdnsPublisher:
    """Optional network advertisement fallback supplied by the workstation."""

    def __init__(self, enabled=True):
        self.enabled = bool(enabled and Zeroconf is not None)
        self.zc = Zeroconf(ip_version=IPVersion.V4Only) if self.enabled else None
        self.services = {}

    def publish(self, hello):
        # Prefer the Pico's own user-code mDNS advertisement when available.
        # Host-side publication is a fallback, not a duplicate identity.
        if not self.zc or hello.get("mdnsActive"):
            return
        ip = hello.get("ip")
        port = int(hello.get("mcpPort", 8000))
        node = str(hello.get("node", "super-node"))
        if not ip or ip == "None":
            return
        try:
            addr = socket.inet_aton(ip)
        except OSError:
            return
        key = node
        if key in self.services:
            return
        info = ServiceInfo(
            "_super-mcp._tcp.local.",
            "%s._super-mcp._tcp.local." % node.replace(" ", "-"),
            addresses=[addr], port=port,
            properties={
                b"node": node.encode(),
                b"version": str(hello.get("serverVersion", "?")).encode(),
                b"path": b"/mcp",
                b"simulation": b"win32-usb-host",
            },
            server=(str(hello.get("hostname") or node).replace(" ", "-") + ".local."),
        )
        try:
            self.zc.register_service(info)
            self.services[key] = info
            print("  mDNS: %s -> %s:%d" % (node, ip, port))
        except Exception as exc:
            print("  mDNS publish warning:", exc)

    def close(self):
        if self.zc:
            for info in list(self.services.values()):
                try:
                    self.zc.unregister_service(info)
                except Exception:
                    pass
            self.zc.close()


class LocalMcpBridge:
    """Loopback HTTP MCP endpoint which forwards to one Pico over USB CDC.

    It deliberately validates the same high-value request invariants as the
    Pico's network HTTP transport.  The bridge is a transport adapter, not a
    second MCP implementation.
    """

    def __init__(self, worker, token):
        self.worker = worker
        self.token = token or ""
        outer = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "SUPER-USB-MCP/0.5"

            def log_message(self, fmt, *args):
                return

            def _send(self, status, obj):
                raw = json.dumps(obj, separators=(",", ":")).encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(raw)

            def do_GET(self):
                if self.path not in ("/", "/status"):
                    self._send(404, {"error": "not found"})
                    return
                self._send(200, {
                    "service": "SUPER USB MCP bridge",
                    "node": outer.worker.node,
                    "serialPort": outer.worker.ser.port,
                    "mcp": "/mcp",
                    "authoritativeEndpoint": "resident-pico",
                })

            def do_POST(self):
                if self.path != "/mcp":
                    self._send(404, {"error": "not found"})
                    return
                if outer.token and self.headers.get("Authorization", "") != "Bearer " + outer.token:
                    self._send(401, {"error": "unauthorized"})
                    return
                if self.headers.get("MCP-Protocol-Version") != MCP_PROTOCOL:
                    self._send(400, {"error": "MCP-Protocol-Version required"})
                    return
                try:
                    n = int(self.headers.get("Content-Length", "0"))
                    if n <= 0 or n > MAX_MCP_BODY:
                        raise ValueError("invalid MCP body length")
                    request = json.loads(self.rfile.read(n).decode("utf-8"))
                    body_method = request.get("method")
                    if self.headers.get("Mcp-Method") != body_method:
                        raise ValueError("Mcp-Method header/body mismatch")
                    if body_method == "tools/call":
                        body_name = (request.get("params") or {}).get("name")
                        if self.headers.get("Mcp-Name") != body_name:
                            raise ValueError("Mcp-Name header/body mismatch")
                    response = outer.worker.forward_mcp(request, timeout_s=12.0)
                    self._send(200, response)
                except TimeoutError as exc:
                    self._send(504, {"error": str(exc)})
                except Exception as exc:
                    self._send(400, {"error": str(exc)})

        self.httpd = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
        self.port = int(self.httpd.server_address[1])
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    def start(self):
        self.thread.start()

    def close(self):
        try:
            self.httpd.shutdown()
            self.httpd.server_close()
        except Exception:
            pass


class NodeWorker(threading.Thread):
    def __init__(self, ser, hello, args, mdns, on_close):
        super().__init__(daemon=True)
        self.ser = ser
        self.hello = hello
        self.args = args
        self.mdns = mdns
        self.on_close = on_close
        self.stop_event = threading.Event()
        self.write_lock = threading.Lock()
        self.pending_lock = threading.Lock()
        self.mcp_pending = {}
        self.mcp_seq = 0
        self.bridge = None

        record_path = _node_trace_path(args.record, hello.get("node")) if args.record else None
        recorder = TraceRecorder(record_path) if record_path else TraceRecorder(None)
        if args.replay:
            replay_path = _node_trace_path(args.replay, hello.get("node")) if "{node}" in args.replay else args.replay
            self.world = ReplayWorld(replay_path)
            self.recorder = recorder
        else:
            seed = zlib.crc32(str(hello.get("node", "node")).encode("utf-8")) & 0xFFFFFFFF
            self.world = SimulationWorld(args.scenario, seed=seed, recorder=recorder)
            self.recorder = recorder

    @property
    def node(self):
        return str(self.hello.get("node", self.ser.port))

    def send(self, obj):
        raw = frame(obj)
        with self.write_lock:
            self.ser.write(raw)
            self.ser.flush()

    def respond(self, rid, ok=True, result=None, error=None):
        obj = {"op": "response", "id": rid, "ok": bool(ok)}
        if ok:
            obj["result"] = result
        else:
            obj["error"] = str(error)
        self.send(obj)

    def handle_request(self, msg):
        rid = msg.get("id")
        method = msg.get("method")
        params = msg.get("params") or {}
        try:
            if method == "sensor.read":
                result = self.world.read_sensor(str(params.get("id", "")))
            elif method == "sensor.read_all":
                result = {"readings": self.world.read_all()}
            elif method == "simulation.status":
                result = self.world.status()
            elif method == "scenario.list":
                st = self.world.status()
                result = {"current": st.get("scenario"), "scenarios": st.get("availableScenarios", ["replay"])}
            elif method == "scenario.set":
                result = self.world.set_scenario(str(params.get("name", "")))
            elif method == "waveform.capture":
                result = self.world.waveform(params.get("samples", 64), params.get("sampleRateHz", 1000.0))
            else:
                raise KeyError("unknown simulator method " + str(method))
            self.respond(rid, True, result=result)
        except Exception as exc:
            self.respond(rid, False, error=exc)

    def handle_event(self, msg):
        method = msg.get("method")
        params = msg.get("params") or {}
        if method == "output.event":
            self.world.set_output(str(params.get("output", "")), params.get("value"))

    def handle_mcp_response(self, msg):
        rid = msg.get("id")
        with self.pending_lock:
            item = self.mcp_pending.get(rid)
            if item:
                item["response"] = msg.get("response")
                item["event"].set()

    def forward_mcp(self, request, timeout_s=12.0):
        """Forward exactly one MCP request to the resident Pico dispatcher."""
        with self.pending_lock:
            self.mcp_seq = (self.mcp_seq + 1) & 0x7FFFFFFF
            rid = self.mcp_seq
            item = {"event": threading.Event(), "response": None}
            self.mcp_pending[rid] = item
        try:
            self.send({"op": "mcp_request", "id": rid, "request": request})
            if not item["event"].wait(timeout_s):
                raise TimeoutError("resident Pico did not answer MCP request over USB")
            response = item.get("response")
            if not isinstance(response, dict):
                raise RuntimeError("invalid MCP response from resident Pico")
            return response
        finally:
            with self.pending_lock:
                self.mcp_pending.pop(rid, None)

    def discovery_record(self):
        return {
            "source": "usb-bridge",
            "node": self.node,
            "host": "127.0.0.1",
            "port": self.bridge.port if self.bridge else None,
            "serialPort": self.ser.port,
            "physicalIp": self.hello.get("ip"),
            "physicalMcpPort": self.hello.get("mcpPort", 8000),
            "serverVersion": self.hello.get("serverVersion"),
            "simulation": "win32-usb-host",
        }

    def run(self):
        self.bridge = LocalMcpBridge(self, self.args.token)
        self.bridge.start()
        print("CONNECTED %-18s %s  USB-MCP=http://127.0.0.1:%d/mcp  WiFi=%s:%s" % (
            self.node, self.ser.port, self.bridge.port,
            self.hello.get("ip", "none"), self.hello.get("mcpPort", 8000)))
        self.mdns.publish(self.hello)
        last_ping = 0.0
        try:
            while not self.stop_event.is_set():
                now = time.monotonic()
                if now - last_ping > 1.0:
                    self.send({"op": "ping"})
                    last_ping = now
                raw = self.ser.readline()
                if not raw:
                    continue
                try:
                    msg = json.loads(raw.decode("utf-8", errors="strict"))
                except Exception:
                    continue
                if msg.get("protocol") != PROTOCOL:
                    continue
                op = msg.get("op")
                if op == "hello":
                    self.hello.update(msg)
                    self.mdns.publish(self.hello)
                elif op == "request":
                    self.handle_request(msg)
                elif op == "event":
                    self.handle_event(msg)
                elif op == "mcp_response":
                    self.handle_mcp_response(msg)
        except Exception as exc:
            print("DISCONNECTED %s: %s" % (self.node, exc))
        finally:
            if self.bridge:
                self.bridge.close()
            try:
                self.recorder.close()
            except Exception:
                pass
            try:
                self.ser.close()
            except Exception:
                pass
            self.on_close(self.ser.port)


class ControlServer:
    """Well-known localhost registry used for automatic USB bridge discovery."""

    def __init__(self, host, port):
        outer = self

        class Handler(BaseHTTPRequestHandler):
            server_version = "SUPER-SIM-DISCOVERY/0.5"

            def log_message(self, fmt, *args):
                return

            def do_GET(self):
                if self.path not in ("/nodes", "/status"):
                    self.send_error(404)
                    return
                if self.path == "/nodes":
                    obj = {"service": "SUPER Simulation Host", "version": "0.5.0", "nodes": outer.host.node_records()}
                else:
                    obj = {"service": "SUPER Simulation Host", "version": "0.5.0", "nodeCount": len(outer.host.node_records())}
                raw = json.dumps(obj, separators=(",", ":")).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(raw)))
                self.send_header("Cache-Control", "no-store")
                self.end_headers()
                self.wfile.write(raw)

        self.host = host
        self.httpd = ThreadingHTTPServer(("127.0.0.1", int(port)), Handler)
        self.port = int(self.httpd.server_address[1])
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)

    def start(self):
        self.thread.start()

    def close(self):
        try:
            self.httpd.shutdown()
            self.httpd.server_close()
        except Exception:
            pass


class SimulationHost:
    def __init__(self, args):
        if serial is None:
            raise RuntimeError("pyserial is required: py -m pip install -r requirements-desktop.txt")
        self.args = args
        self.workers = {}
        self.lock = threading.Lock()
        self.mdns = MdnsPublisher(not args.no_mdns)
        self.control = ControlServer(self, args.control_port)

    def node_records(self):
        with self.lock:
            workers = list(self.workers.values())
        return [w.discovery_record() for w in workers if w.bridge is not None]

    def _closed(self, port):
        with self.lock:
            self.workers.pop(port, None)

    def _probe(self, port):
        """Passively identify usb_cdc.data from its unsolicited SUPER hello.

        We deliberately do not send probe text.  CircuitPython exposes both a
        console CDC and a data CDC; writing JSON into the wrong one would dirty
        the student's REPL.  Only the SUPER data endpoint emits hello frames.
        """
        try:
            ser = serial.Serial(port, BAUD, timeout=0.12, write_timeout=0.5)
        except Exception:
            return None
        try:
            # Preserve any hello already buffered.  On a console CDC candidate
            # this also avoids discarding the student's diagnostic output.
            deadline = time.monotonic() + self.args.probe_timeout
            while time.monotonic() < deadline:
                raw = ser.readline()
                if not raw:
                    continue
                try:
                    msg = json.loads(raw.decode("utf-8"))
                except Exception:
                    continue
                if msg.get("protocol") == PROTOCOL and msg.get("op") == "hello":
                    return ser, msg
        except Exception:
            pass
        try:
            ser.close()
        except Exception:
            pass
        return None

    def scan_once(self):
        for p in list_ports.comports():
            if not _looks_like_circuitpython_port(p, self.args.probe_all):
                continue
            port = p.device
            with self.lock:
                if port in self.workers:
                    continue
            found = self._probe(port)
            if not found:
                continue
            ser, hello = found
            worker = NodeWorker(ser, hello, self.args, self.mdns, self._closed)
            with self.lock:
                self.workers[port] = worker
            worker.start()

    def run(self):
        self.control.start()
        print("SUPER v0.5 Win32 Simulation Host")
        print("USB discovery : passive + Pico CircuitPython filtered; no COM configuration")
        print("MCP discovery : http://127.0.0.1:%d/nodes" % self.control.port)
        print("Scenario      :", self.args.scenario if not self.args.replay else "REPLAY " + self.args.replay)
        try:
            while True:
                self.scan_once()
                time.sleep(self.args.scan_interval)
        except KeyboardInterrupt:
            print("\nStopping simulation host...")
        finally:
            with self.lock:
                workers = list(self.workers.values())
            for w in workers:
                w.stop_event.set()
            self.control.close()
            self.mdns.close()


def parse_args(argv=None):
    p = argparse.ArgumentParser(description="Auto-discover Pico W SUPER nodes and provide realistic sensor simulation over USB CDC.")
    p.add_argument("--scenario", default="nominal", choices=["nominal", "warm_room", "bright_sun", "noisy_bench", "sensor_fault"])
    p.add_argument("--record", help="record JSONL; node name is appended, or use {node} in filename")
    p.add_argument("--replay", help="replay sensor.read events from JSONL; {node} is supported")
    p.add_argument("--token", default=os.getenv("SUPER_MCP_TOKEN", "super-demo"), help="bearer token required by localhost MCP bridges")
    p.add_argument("--no-mdns", action="store_true", help="do not republish discovered network MCP nodes over mDNS")
    p.add_argument("--control-port", type=int, default=DEFAULT_CONTROL_PORT, help="localhost discovery registry port; desktop tools use SUPER_SIM_CONTROL_PORT")
    p.add_argument("--probe-all", action="store_true", help="diagnostic only: consider all serial ports instead of CircuitPython candidates")
    p.add_argument("--scan-interval", type=float, default=1.0)
    p.add_argument("--probe-timeout", type=float, default=0.90)
    return p.parse_args(argv)


def main(argv=None):
    args = parse_args(argv)
    SimulationHost(args).run()


if __name__ == "__main__":
    main()
