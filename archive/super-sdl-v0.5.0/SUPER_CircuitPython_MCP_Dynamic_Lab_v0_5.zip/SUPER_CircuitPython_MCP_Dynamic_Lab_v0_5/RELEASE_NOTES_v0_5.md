# SUPER v0.5 Release Notes — Full Simulation Host

v0.5 promotes simulation from an on-device demonstration to a first-class
laboratory backend while preserving the Pico W as the authoritative SUPER node.

## Headline capability

A Raspberry Pi Pico W connected by one USB cable can be discovered automatically
by a Windows Python process, supplied with a causal multi-sensor simulation, and
made reachable to ordinary MCP clients through an automatically allocated
localhost HTTP bridge. Wi-Fi is optional for this path.

## Added

- second CircuitPython CDC data channel (`boot.py`);
- passive USB data-port discovery; no configured COM number;
- Pico CircuitPython VID/PID filtering with diagnostic `--probe-all` override;
- `SUPER-SIM/1` JSONL host/Pico protocol;
- Win32 causal simulation world for DS18B20, BME280, BH1750, ADC, pot and IMU;
- output-to-observation causality (PWM->thermal state, LED->illumination);
- named scenarios and sensor fault injection;
- JSONL record/replay;
- one simulation world per attached SUPER node;
- USB transport of MCP requests to the resident Pico dispatcher;
- per-node localhost HTTP MCP bridge;
- localhost simulation-host node registry for automatic client discovery;
- optional mDNS/network MCP in parallel;
- resident local-simulation fallback when the host disappears;
- new MCP tools for simulation status, scenario control, and waveform capture;
- tests for backend substitution, USB MCP dispatch, localhost proxy auth,
  conservative serial filtering, and causal simulation.

## Corrected from v0.4

- capability package IDs now must be valid Python identifiers; hyphenated IDs
  can no longer pass validation and then fail at import time.

## Still intentionally outside v0.5

- untrusted-code sandboxing;
- high-bandwidth binary acquisition transport;
- production network security/TLS;
- fully causal replay of output actions;
- Web Workflow deployment without Wi-Fi;
- physical DS18B20/BME280/BH1750 backends.

The next high-value proof is to bind `temp1` to a real DS18B20 while leaving the
Newton Cooling capability, MCP tool names, discovery, and client unchanged.
