#!/usr/bin/env python3
"""End-to-end acceptance test for SUPER v0.5 Full Simulation Host.

Normal use requires *no IP address*.  The test discovers the Pico via mDNS or
USB, then verifies that its active backend is the Win32 simulator, that all
simulated sensors are plausible, that a fault scenario propagates through MCP,
and that a real Pico LED output has a causal effect on the simulated BH1750.
"""

import argparse
import json
import time
import urllib.request

from desktop_discover import discover_super

PORT = 8000
TOKEN = "super-demo"
PROTO = "2026-07-28"
_counter = 0
URL = None


def meta():
    return {
        "io.modelcontextprotocol/protocolVersion": PROTO,
        "io.modelcontextprotocol/clientInfo": {"name": "super-v05-acceptance", "version": "0.5.0"},
        "io.modelcontextprotocol/clientCapabilities": {},
    }


def rpc(method, params=None, mcp_name=None):
    global _counter
    _counter += 1
    p = dict(params or {})
    p["_meta"] = meta()
    body = {"jsonrpc": "2.0", "id": _counter, "method": method, "params": p}
    headers = {
        "Content-Type": "application/json", "Accept": "application/json",
        "Authorization": "Bearer " + TOKEN, "MCP-Protocol-Version": PROTO,
        "Mcp-Method": method,
    }
    if mcp_name:
        headers["Mcp-Name"] = mcp_name
    req = urllib.request.Request(URL, data=json.dumps(body).encode(), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=10) as response:
        obj = json.loads(response.read().decode())
    assert obj.get("id") == _counter
    assert "error" not in obj, obj
    return obj["result"]


def tool(name, args=None):
    result = rpc("tools/call", {"name": name, "arguments": args or {}}, name)
    assert result.get("isError") is False, result
    return result.get("structuredContent")


def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--host", help="diagnostic override; normal operation auto-discovers")
    p.add_argument("--allow-local", action="store_true", help="allow resident fallback instead of requiring Win32 host")
    return p.parse_args()


def main():
    global URL
    args = parse_args()
    host = args.host
    port = PORT
    if not host:
        nodes = discover_super(token=TOKEN)
        assert nodes, "no SUPER node auto-discovered"
        node = nodes[0]
        host, port = node["host"], int(node.get("port", PORT))
        print("Auto-discovered %s at %s:%d via %s" % (node.get("node", "SUPER"), host, port, node.get("source")))
    URL = "http://%s:%d/mcp" % (host, port)
    print("Testing", URL)

    discovered = rpc("server/discover")
    assert PROTO in discovered["supportedVersions"]

    listed = rpc("tools/list")
    names = {t["name"] for t in listed["tools"]}
    required = {
        "super_info", "sensor_list", "sensor_read", "sensor_read_all",
        "simulation_status", "simulation_scenario_list", "simulation_scenario_set",
        "waveform_capture", "capability_list",
        "cooling_start", "cooling_sample", "cooling_status", "cooling_stop",
    }
    assert not (required - names), "missing tools: %r" % (required - names)

    sim = tool("simulation_status")
    if not args.allow_local:
        assert sim["activeBackend"] == "win32-sim" and sim["connected"] is True, sim

    sensors = tool("sensor_list")
    ids = {s["id"] for s in sensors["sensors"]}
    assert {"temp1", "light1", "env1", "adc1", "pot1", "accel1"}.issubset(ids)

    if sim["activeBackend"] == "win32-sim":
        scenarios = tool("simulation_scenario_list")
        assert "nominal" in scenarios["scenarios"] and "sensor_fault" in scenarios["scenarios"]
        tool("simulation_scenario_set", {"name": "nominal"})

        snapshot = tool("sensor_read_all")["readings"]
        assert all(v.get("backend") == "win32-sim" for v in snapshot.values()), snapshot
        assert -20 < snapshot["temp1"]["temperatureC"] < 80
        assert 0 <= snapshot["env1"]["humidityPct"] <= 100
        assert 850 < snapshot["env1"]["pressureHpa"] < 1100
        assert 0 <= snapshot["adc1"]["volts"] <= 3.3
        assert 0 <= snapshot["pot1"]["positionPct"] <= 100

        # Causal cross-boundary proof: the *real* Pico LED command is mirrored
        # to the workstation model, which changes the virtual BH1750 value.
        tool("output_set", {"output": "led", "value": False})
        time.sleep(0.08)
        dark = tool("sensor_read", {"id": "light1"})["lux"]
        tool("output_set", {"output": "led", "value": True})
        time.sleep(0.08)
        lit = tool("sensor_read", {"id": "light1"})["lux"]
        assert lit > dark + 10.0, (dark, lit)

        tool("simulation_scenario_set", {"name": "sensor_fault"})
        fault = tool("sensor_read", {"id": "light1"})
        assert fault["status"] == "fault" and fault["value"] is None, fault
        tool("simulation_scenario_set", {"name": "nominal"})
    else:
        # Standalone regression path when explicitly allowed.
        tool("simulator_set", {"channel": "temperature_c", "enabled": False})
        assert tool("sensor_read", {"id": "temp1"})["status"] == "disabled"
        tool("simulator_set", {"channel": "temperature_c", "enabled": True})

    wave = tool("waveform_capture", {"samples": 64, "sampleRateHz": 1000})
    assert len(wave["samples"]) == 64

    caps = tool("capability_list")
    assert any(p.get("package") == "newton_cooling" and p.get("status") == "active" for p in caps["packages"]), caps
    tool("cooling_start", {"mode": "sensor"})
    sample = tool("cooling_sample")
    assert "temperatureC" in sample
    tool("cooling_stop")

    print("PASS: SUPER v0.5 Full Simulation Host acceptance test")


if __name__ == "__main__":
    main()
