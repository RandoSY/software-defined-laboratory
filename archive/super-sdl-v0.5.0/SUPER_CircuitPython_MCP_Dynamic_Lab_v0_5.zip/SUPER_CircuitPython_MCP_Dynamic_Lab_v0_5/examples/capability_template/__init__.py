"""Package marker for the minimal SUPER capability template."""
