"""Minimal SUPER capability template.

Copy this directory, rename it, change manifest.json, then replace this one
handler with experimental meaning of your own.

A capability should think in two directions:

    lab      -> stable access to the physical/virtual bench
    registry -> stable access to AI-visible experimental vocabulary

It should *not* know about Wi-Fi sockets, HTTP parsing, Web Workflow, bearer
tokens, or the Pico's IP address.  Those belong to the resident substrate.
"""


def register(registry, lab):
    from super.mcp import tool_ok

    def hello(_args):
        # Access to `lab` is available here when your experiment needs sensors,
        # outputs, or other stable bench services.  This minimal tool simply
        # proves dynamic registration.
        return tool_ok("hello from a deposited capability", {
            "idea": "the resident core did not know this tool at manufacture time"
        })

    registry.register({
        "name": "template_hello",
        "title": "Hello From Deposited Capability",
        "description": "Smallest possible demonstration of late-bound laboratory vocabulary.",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "additionalProperties": False
        },
        "annotations": {
            "readOnlyHint": True,
            "idempotentHint": True
        }
    }, hello)
