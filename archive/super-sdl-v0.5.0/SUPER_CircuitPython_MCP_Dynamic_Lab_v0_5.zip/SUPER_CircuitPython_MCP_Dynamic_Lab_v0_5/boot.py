"""USB personality for SUPER v0.5.

SUPER uses two CDC serial interfaces:

* ``usb_cdc.console`` remains the normal CircuitPython REPL.
* ``usb_cdc.data`` is a dedicated, machine-readable SUPER-SIM/1 link to the
  workstation simulation host and USB MCP bridge.

The distinction matters pedagogically and operationally: diagnostics printed
by a student at the REPL can never be mistaken for simulation protocol frames.

CircuitPython requires USB interfaces to be selected from boot.py, before USB
enumeration.  HID and MIDI are unnecessary for this reference laboratory and
are disabled to leave endpoint budget for the second CDC interface.  Mass
storage remains enabled, so CIRCUITPY is still visible in the familiar way.
"""

import usb_cdc

try:
    import usb_hid
    usb_hid.disable()
except Exception:
    pass

try:
    import usb_midi
    usb_midi.disable()
except Exception:
    pass

# Preserve the ordinary REPL and add an independent binary/data serial port.
usb_cdc.enable(console=True, data=True)
