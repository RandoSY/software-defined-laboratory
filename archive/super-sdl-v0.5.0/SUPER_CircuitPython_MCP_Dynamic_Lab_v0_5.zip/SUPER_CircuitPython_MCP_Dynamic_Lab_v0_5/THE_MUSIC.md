# THE MUSIC — What SUPER/MCP Is Actually Trying to Change

The code in this seed is small. The idea is larger than the code.

If this project is read merely as "a Pico W serving MCP tools," most of its
significance disappears. Plenty of microcontrollers can answer network
requests. Plenty can load Python files. Plenty can read a temperature sensor.
None of those facts, alone, is the point.

The point is **when the purpose of the machine becomes fixed**.

## 1. Conventional embedded design fixes purpose early

The normal sequence is:

```text
need -> design -> firmware -> flash -> appliance
```

That is often exactly correct. A thermostat should not wake up one morning and
decide that it is now an oscilloscope.

But a *laboratory* is different. Its purpose is not one function. Its purpose
is to support questions we may not yet know we will ask.

When we build a laboratory microcontroller as a fixed appliance, we force the
future experiment to fit yesterday's firmware.

SUPER tries to reverse that relationship.

## 2. The laboratory need not know tomorrow's experiment today

Install only a durable substrate:

```text
CircuitPython
+ network presence
+ MCP
+ physical I/O abstraction
+ capability loader
+ safety/diagnostics
```

Then allow experimental meaning to arrive later:

```text
Newton cooling
Beer-Lambert colorimetry
pendulum timing
load-cell calibration
RC characterization
motor characterization
```

The board remains the same board. The resident core remains the same core.
What changes is the set of experimental ideas the node can express.

This is **late binding of laboratory function**.

## 3. CRCL is the ancestor

CRCL had already crossed an important conceptual boundary:

```text
resident runtime + replaceable application
```

The target did not have to be permanently married to the application present
when the device was first prepared. Human-readable Python behavior could be
deposited later.

SUPER/MCP generalizes that inheritance:

```text
CRCL
replaceable behavior
    -> SUPER
stable laboratory substrate
    -> capability packages
replaceable/additive experimental meaning
    -> MCP
machine-readable discovery of that meaning
    -> AI
selection, composition, and use of capability at the moment of need
```

A concise way to say it is:

> **CRCL made behavior replaceable. SUPER/MCP makes laboratory capability composable.**

## 4. Why MCP makes dynamic loading much more interesting

Dynamic imports are old. Plug-ins are old. Downloading code is old.

MCP closes a loop that those mechanisms do not close by themselves:

```text
new code arrives
    -> code registers experimental meaning
    -> tools/list changes
    -> AI discovers the changed vocabulary
    -> AI can immediately use the new laboratory ability
```

The laboratory is therefore not merely reprogrammable. It is **self-describing
after reprogramming**.

That is the reason `register(registry, lab)` is the central seam in this seed.

`lab` means:

> Here is stable access to physical reality.

`registry` means:

> Here is stable access to the vocabulary visible to intelligent clients.

A capability joins those two worlds.

## 5. Drivers and capabilities are not the same thing

A driver answers:

> How do I read this DS18B20?

A capability answers:

> How can this laboratory conduct a Newton-cooling experiment using whatever
> temperature source fulfills the role `temp1`?

The distinction is crucial.

The experiment should depend on **meaning**, not wiring trivia.

Today:

```text
temp1 -> simulator
```

Tomorrow:

```text
temp1 -> real DS18B20
```

The Newton-cooling package should not care.

That is how simulation becomes a legitimate precursor to reality rather than a
throwaway demonstration.

## 6. Dynamic must not mean casual

If capabilities can arrive late, failure handling becomes part of the idea.

SUPER v0.5 repeats one pattern at several layers:

```text
prepare -> validate -> commit
```

On the filesystem:

```text
/staging
    -> upload
    -> byte-for-byte read-back
    -> READY
    -> MOVE
/capabilities
```

In memory:

```text
private tool transaction
    -> register all proposed tools
    -> compare against manifest
    -> dependency checks
    -> commit
public MCP vocabulary
```

This is not enterprise fault tolerance. It is something more important for a
seed project: a coherent reliability model that can grow.

## 7. Why CircuitPython is unusually well matched

CircuitPython contributes three educationally important properties:

1. **A persistent interpreter and hardware environment.** We do not rebuild a
   complete firmware image whenever experimental behavior changes.
2. **Visible, readable source.** The learner can inspect what the AI deposited.
3. **A standard Web Workflow.** Network file transfer, directory operations,
   mDNS identity, and filesystem state already exist; SUPER does not need to
   waste its conceptual budget reinventing them.

CircuitPython is therefore not literally an online bootloader. A better phrase
is:

> **a persistent, remotely reconfigurable execution substrate for a
> software-defined laboratory.**

## 8. Why an AI collaborator changes the economics

Without AI, a dynamically extensible laboratory can still be useful, but a
human must already know what software is needed and where to find it.

With an AI collaborator, the sequence can become:

```text
scientific question
    -> inspect available physical resources
    -> identify missing experimental capability
    -> select/create a small capability package
    -> deposit it
    -> laboratory advertises new tools
    -> perform experiment
    -> analyze result
    -> revise experiment
```

The machine is no longer waiting for a prewritten lab exercise. The laboratory
can be *composed around the question*.

That is the novel educational possibility.

## 9. The student's role should increase, not disappear

The wrong version of this project would make the AI a magician:

> "Trust me. I changed the board. Here are the answers."

The desirable version makes previously hidden engineering visible:

- What capability does the question require?
- What physical quantities must be measured?
- What assumptions does the model make?
- What code was deposited?
- Which tools became available?
- Which readings are simulated and which are physical?
- What is calibration?
- What failed, and why?

The AI should reduce clerical friction while exposing more of the reasoning.

## 10. What the Newton seed demonstrates

Before `newton_cooling` is installed, the permanent node knows general
laboratory verbs:

```text
sensor_read
sensor_list
i2c_scan
output_set
capability_list
```

After deposition and reload, it also knows:

```text
cooling_start
cooling_sample
cooling_status
cooling_stop
```

The core was not reflashed.

The experimental vocabulary changed because an experimental idea arrived.

That is the seed.

## 11. Where the idea should go next

The next proof should not be another large software feature. It should be one
small crossing of the reality boundary:

```text
same Newton capability
same cooling_start / sample / stop vocabulary
same MCP client

BUT

temp1: simulated -> real DS18B20
```

Nothing above the laboratory abstraction should change.

If that demonstration works cleanly, one of the project's most important
claims becomes physical rather than rhetorical:

> **Simulation and reality are interchangeable beneath a stable experimental
> interface.**

Then add a second independently deposited capability. At that point SUPER is
not a Newton-cooling demo. It has become a genuine extensible laboratory node.

## 12. Full simulation is rehearsal, not a counterfeit laboratory

v0.5 adds a Windows simulation host, but the architecture deliberately refuses
to let the workstation become a second laboratory identity.

That would be the easy implementation:

```text
Windows simulator -> Windows MCP server -> simulated experiment
```

It would also throw away the continuity we need.

Instead:

```text
AI/client
   -> Pico's resident MCP vocabulary
   -> Pico's stable Lab abstraction
   -> Win32 simulation backend today
   -> physical sensor backend tomorrow
```

Even in USB-only mode, the Windows HTTP bridge forwards MCP to the resident
Pico dispatcher. It does not mirror the registry. This means a newly deposited
capability immediately appears through both USB and network transports because
there is only one authoritative vocabulary.

That is the deeper reason for keeping a real Pico W attached during simulation:

> **We are rehearsing the future physical laboratory on the same computational
> identity, not writing a disposable desktop imitation of it.**

The simulation host can therefore be lavish where the Pico should remain
simple: many virtual sensors, causal models, scenario libraries, recorded
sessions, fault injection, and eventually sophisticated numerical models. The
Pico remains the durable endpoint that knows what the laboratory *means*.

## 13. Automatic discovery is part of the idea

A laboratory intended for continuous intelligent assistance should not require a
human to remember COM numbers or hunt DHCP leases before every experiment.
Those are infrastructure details, not scientific intent.

v0.5 therefore treats discovery as a design invariant:

```text
plug in Pico
    -> dedicated data CDC appears
    -> host recognizes SUPER automatically
    -> localhost MCP bridge appears
    -> client discovers bridge automatically
    -> tools/list tells the client what this laboratory can do now
```

The chain is worth noticing: discovery proceeds from *physical presence* to
*network/transport presence* to *semantic capability*. That is the complete
path from "a board is connected" to "an intelligent collaborator knows what
this bench can do."

## 14. v0.5 adds a rehearsal room for reality

The workstation simulator changes something practical and philosophical.

Before physical hardware is complete, we can now rehearse the *entire behavior
of the laboratory system* with a real Pico W still occupying its eventual role.
The AI discovers the same node, sees the same sensor identities, calls the same
MCP tools, and executes the same deposited capabilities.  Only the source of
physical state is provisional.

That means simulation is no longer a disposable mockup living beside the real
project.  It is one legitimate backend beneath the permanent laboratory
abstraction.

```text
question
   -> experiment capability
      -> stable laboratory role
         -> simulation today
         -> hardware tomorrow
```

This is why the Pico remains on the USB cable.  We are not merely simulating
numbers; we are preserving the identity of the machine that will eventually
face the world.

## 15. One cable should be enough to begin

A development system that requires the student to discover COM numbers, hunt
for DHCP addresses, and copy transport trivia into configuration files has
already allowed infrastructure to obscure the experiment.

v0.5 therefore treats automatic discovery as part of the educational design.
The normal one-cable sequence is intended to be:

```text
plug in Pico W
start simulation host
SUPER appears
ask a scientific question
```

Wi-Fi can add range and deployment convenience, but it is no longer the hidden
condition for using MCP.  The USB cable can carry both the simulated physical
world and, through a localhost bridge, the AI-facing MCP conversation.

The consequence is subtle but important: **transport becomes background while
experimental meaning remains foreground.**

## 16. The simulator should eventually disappear without being mourned

The best proof that the architecture is correct will be boring.

We will replace `temp1` with a real DS18B20 and the Newton Cooling capability
will continue to work.  Then perhaps `light1` becomes a real BH1750.  Then the
ADC becomes physical.  The simulator shrinks channel by channel until the bench
is real.

Nothing above the backend seam should need to celebrate those substitutions.
The AI should simply observe provenance changing from `win32-sim` to
`hardware` while the experimental vocabulary remains stable.

That is the musical resolution of the design:

> **A simulation was useful not because it looked real, but because reality
> could replace it without forcing the laboratory to become a different thing.**
