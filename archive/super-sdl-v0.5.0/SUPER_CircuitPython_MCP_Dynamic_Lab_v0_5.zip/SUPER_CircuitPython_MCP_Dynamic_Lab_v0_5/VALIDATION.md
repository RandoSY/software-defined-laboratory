# Validation status — SUPER v0.5.0

Validated in this release workspace:

- all Python sources compile under desktop CPython syntax checking;
- `desktop_selftest.py` passes the semantic regression suite;
- `desktop_usb_integration_test.py` passes the complete software round trip:
  localhost HTTP MCP -> Win32 NodeWorker -> in-memory serial link -> real
  Pico-side HostSimLink/MCP dispatcher -> Win32 simulation backend -> response;
- automatic localhost discovery is exercised in the integration test;
- record/replay of sensor reads and waveform captures is exercised;
- dynamic capability registration and Newton Cooling semantic behavior pass.

Not yet validated here:

- physical Windows enumeration of the two Pico W CircuitPython CDC interfaces;
- physical Pico W timing/memory behavior under CircuitPython;
- Wi-Fi and mDNS behavior on the user's actual network;
- physical sensor backends (not part of v0.5);
- Web Workflow deployment on the user's actual Pico W.

The next acceptance step is therefore a physical one-cable Pico W run using
`desktop_mcp_test.py`, followed by replacement of `temp1` with a real DS18B20.
