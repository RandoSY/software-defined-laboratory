@echo off
setlocal
cd /d "%~dp0"
py desktop_mcp_test.py %*
