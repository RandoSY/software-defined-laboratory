# SUPER v0.5 Full Simulation Host — Design and Protocol Notes

## Purpose

The Windows host is a **replaceable physics backend** for a real SUPER node. It
is not the laboratory identity and it is not a second copy of the MCP server.
Its job is to provide physical state that does not yet need to come from
silicon, while preserving the exact experimental interface that later hardware
will use.

This distinction prevents a common simulator failure: building one application
for simulation and a different application for reality.

## Responsibilities

The host performs four services:

1. discover the Pico's dedicated CircuitPython data CDC automatically;
2. provide causal sensor/experiment simulation over `SUPER-SIM/1`;
3. expose the Pico's resident MCP dispatcher through a localhost HTTP bridge;
4. provide a fixed localhost node registry so desktop clients discover the
   dynamically allocated per-node MCP bridge without manual ports.

The Pico performs the semantic work:

- owns stable sensor/output identities;
- owns the MCP `ToolRegistry`;
- owns deposited capabilities;
- validates output requests;
- decides whether a sensor read comes from Win32 simulation or fallback;
- remains usable if the host disappears.

## USB layout

`boot.py` enables:

```text
usb_cdc.console    human REPL / diagnostics
usb_cdc.data       SUPER-SIM/1 protocol only
```

The host does not assume that COM numbers are consecutive or stable.

Normal discovery first filters for Raspberry Pi Pico CircuitPython USB identity
or clearly labeled CircuitPython serial devices.  Since the console and data
CDC can share that identity, the host opens candidates **read-only in spirit**:
it waits for an unsolicited SUPER hello.  It sends no discovery probe string.
Only the data CDC produces those hello frames.

## SUPER-SIM/1 framing

One UTF-8 JSON object per line:

```text
{...}\n
```

Every protocol frame includes:

```json
{"protocol":"SUPER-SIM/1"}
```

The format is deliberately inspectable and low ceremony. It is not intended
for megasample waveform streaming.

## Pico hello

The Pico periodically sends a hello while a host has the data CDC open:

```json
{
  "protocol": "SUPER-SIM/1",
  "op": "hello",
  "node": "super-bench-01",
  "serverVersion": "0.5.0",
  "ip": "192.168.1.72",
  "mcpPort": 8000,
  "hostname": "super-bench-01",
  "mdnsActive": true
}
```

`ip` may be null in USB-only mode.

## Heartbeat

The host sends:

```json
{"protocol":"SUPER-SIM/1","op":"ping"}
```

The Pico answers with hello. Receipt of valid host frames updates the Pico's
host-liveness window. If that window expires, `Lab` returns to `local-sim`.

## Pico -> host simulation request

```json
{
  "protocol":"SUPER-SIM/1",
  "op":"request",
  "id":12,
  "method":"sensor.read",
  "params":{"id":"temp1"}
}
```

Response:

```json
{
  "protocol":"SUPER-SIM/1",
  "op":"response",
  "id":12,
  "ok":true,
  "result":{
    "id":"temp1",
    "model":"DS18B20",
    "temperatureC":22.53,
    "status":"ok",
    "backend":"win32-sim"
  }
}
```

Current methods:

```text
sensor.read
sensor.read_all
simulation.status
scenario.list
scenario.set
waveform.capture
```

## Pico -> host event

Outputs that can affect the simulated world are sent without requiring a reply:

```json
{
  "protocol":"SUPER-SIM/1",
  "op":"event",
  "method":"output.event",
  "params":{"output":"led","value":true}
}
```

The current BH1750 model intentionally reacts to the logical LED. This provides
an easily observed causal path crossing the real/simulated boundary.

## Host -> Pico MCP request

The localhost bridge does not interpret the laboratory vocabulary. It packages
the client's MCP JSON-RPC request:

```json
{
  "protocol":"SUPER-SIM/1",
  "op":"mcp_request",
  "id":27,
  "request":{
    "jsonrpc":"2.0",
    "id":4,
    "method":"tools/list",
    "params":{"_meta":{...}}
  }
}
```

The Pico calls the same resident `dispatch()` used by network HTTP and returns:

```json
{
  "protocol":"SUPER-SIM/1",
  "op":"mcp_response",
  "id":27,
  "response":{
    "jsonrpc":"2.0",
    "id":4,
    "result":{...}
  }
}
```

Therefore there is one MCP implementation and one tool registry.

## Localhost discovery registry

The simulation host listens on:

```text
http://127.0.0.1:8765/nodes
```

Each attached Pico receives its own ephemeral localhost MCP bridge port. The
registry returns those ports to `desktop_discover.py`.

The fixed control port can be changed with `SUPER_SIM_CONTROL_PORT`; clients
and host must use the same value.

## Simulation worlds

Each attached Pico gets an independent `SimulationWorld` with its own noise
seed, outputs, thermal state, scenario, and recorder.

The world currently models:

- DS18B20-like temperature;
- BME280-like environmental context;
- BH1750-like illumination;
- ADC waveform;
- moving potentiometer position;
- mostly stationary MPU6050-like acceleration.

### Causality

The model contains intentionally visible dependencies:

```text
pwm_duty_pct -> thermal target -> first-order temp1 response
led state    -> added illuminance -> light1 response
scenario     -> room/light/noise/fault parameters -> many sensor results
```

The point is not perfect physics. The point is to provide enough causal
structure that experiment software and AI can make and test meaningful claims.

## Provenance

Every reading identifies its source:

```text
win32-sim
win32-replay
local-sim
```

Future physical drivers should use similarly explicit provenance, for example:

```text
hardware
```

Clients should never have to guess whether a number was measured or generated.

## Failure behavior

### Host process not running

Pico uses `local-sim`.

### USB cable removed

Heartbeat expires; Pico uses `local-sim`.

### Win32 model raises an error

Pico request times out/fails and the current Lab method falls back where that
operation has a resident equivalent.

### Wi-Fi unavailable

The Pico still services USB. The simulation host exposes a localhost MCP bridge.

### mDNS unavailable

The simulation-host localhost registry still discovers USB-attached nodes.

### simulation host owns the CDC port

Desktop clients discover through the localhost registry instead of competing
for the serial handle.

## Security boundary

The localhost MCP bridge binds only to `127.0.0.1` and checks the SUPER bearer
token. This protects normal workstation operation from accidental clients, but
it is not a sandbox or an OS security boundary.

Deposited CircuitPython capability packages remain trusted Python code.

## Scaling

The present JSONL USB protocol is ideal for sensors, control state, experiment
metadata, and moderate waveform captures. It is deliberately not the eventual
transport for high-bandwidth oscilloscopes or cameras. Those should use a
separate bulk/binary acquisition path while retaining MCP as the semantic
control plane.

That separation is an advantage, not a defect:

> MCP says what the laboratory can do; the acquisition transport moves large
> data efficiently.
