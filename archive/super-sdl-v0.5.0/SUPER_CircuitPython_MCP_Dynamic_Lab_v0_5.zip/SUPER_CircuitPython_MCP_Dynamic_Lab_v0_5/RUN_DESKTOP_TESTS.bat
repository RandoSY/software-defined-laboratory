@echo off
setlocal
cd /d "%~dp0"
py desktop_selftest.py || exit /b 1
py desktop_usb_integration_test.py || exit /b 1
