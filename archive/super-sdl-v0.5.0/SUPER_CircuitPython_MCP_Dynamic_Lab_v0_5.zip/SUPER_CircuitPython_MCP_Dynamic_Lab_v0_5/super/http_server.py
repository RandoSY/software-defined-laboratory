"""Minimal HTTP transport for the SUPER MCP endpoint.

CircuitPython's built-in Web Workflow stays on its own port (normally 80) and
is responsible for file deposition.  This server stays on 8000 and is
responsible for laboratory semantics.  Keeping those jobs separate is useful:

    Web Workflow: move bytes reliably.
    SUPER MCP:     explain and operate the laboratory.

That separation lets us use a mature CircuitPython transport without making
its private filesystem protocol part of the SUPER conceptual model.
"""

import json
import time
import socketpool
import wifi

from .config import (
    ALLOWED_ORIGIN,
    MAX_BODY_BYTES,
    MAX_HEADER_BYTES,
    MCP_PATH,
    MCP_PORT,
    MCP_PROTOCOL,
    MCP_TOKEN,
    SOCKET_TIMEOUT_S,
    ACCEPT_POLL_S,
)
from .mcp import dispatch


STATUS = {
    200: "OK", 202: "Accepted", 204: "No Content", 400: "Bad Request",
    401: "Unauthorized", 403: "Forbidden", 404: "Not Found",
    405: "Method Not Allowed", 413: "Payload Too Large",
    415: "Unsupported Media Type", 500: "Internal Server Error",
}


def _send(conn, status, body=b"", content_type="text/plain; charset=utf-8", extra_headers=None):
    if isinstance(body, str):
        body = body.encode("utf-8")
    headers = [
        "HTTP/1.1 %d %s" % (status, STATUS.get(status, "OK")),
        "Content-Type: " + content_type,
        "Content-Length: %d" % len(body),
        "Connection: close",
        "Cache-Control: no-store",
    ]
    if extra_headers:
        for k, v in extra_headers.items():
            headers.append("%s: %s" % (k, v))
    wire = ("\r\n".join(headers) + "\r\n\r\n").encode("utf-8")
    conn.sendall(wire)
    if body:
        conn.sendall(body)


def _send_json(conn, status, obj, extra_headers=None):
    _send(conn, status, json.dumps(obj), "application/json", extra_headers)


def _recv_some(conn, scratch):
    n = conn.recv_into(scratch, len(scratch))
    if not n:
        return b""
    return bytes(memoryview(scratch)[:n])


def _recv_http(conn):
    conn.settimeout(SOCKET_TIMEOUT_S)
    scratch = bytearray(512)
    data = b""
    while b"\r\n\r\n" not in data:
        chunk = _recv_some(conn, scratch)
        if not chunk:
            break
        data += chunk
        if len(data) > MAX_HEADER_BYTES:
            raise OverflowError("headers too large")

    if b"\r\n\r\n" not in data:
        raise ValueError("incomplete HTTP request")

    head, body = data.split(b"\r\n\r\n", 1)
    lines = head.decode("utf-8").split("\r\n")
    first = lines[0].split()
    if len(first) != 3:
        raise ValueError("bad request line")

    headers = {}
    for line in lines[1:]:
        if ":" in line:
            k, v = line.split(":", 1)
            headers[k.strip().lower()] = v.strip()

    length = int(headers.get("content-length", "0") or "0")
    if length > MAX_BODY_BYTES:
        raise OverflowError("body too large")

    while len(body) < length:
        chunk = _recv_some(conn, scratch)
        if not chunk:
            break
        body += chunk
        if len(body) > MAX_BODY_BYTES:
            raise OverflowError("body too large")

    if len(body) < length:
        raise ValueError("incomplete HTTP body")

    return first[0], first[1], headers, body[:length]


def _cors_headers(origin):
    if not ALLOWED_ORIGIN or origin != ALLOWED_ORIGIN:
        return {}
    return {
        "Access-Control-Allow-Origin": origin,
        "Access-Control-Allow-Methods": "POST, OPTIONS",
        "Access-Control-Allow-Headers": "Authorization, Content-Type, MCP-Protocol-Version, Mcp-Method, Mcp-Name",
    }


def _authorized(headers):
    if not MCP_TOKEN:
        return True
    return headers.get("authorization", "") == "Bearer " + MCP_TOKEN


def _status_page(registry):
    names = [d["name"] for d in registry.definitions()]
    return """<!doctype html><html><head><meta charset='utf-8'><title>SUPER</title></head>
<body><h1>SUPER Dynamic Laboratory</h1>
<p>The resident core is alive. MCP tools currently registered:</p>
<pre>%s</pre>
<p>MCP endpoint: <code>%s</code></p>
<p>The interesting fact is that this list can change after a capability package is deposited.</p>
</body></html>""" % ("\n".join(names), MCP_PATH)


def _service_usb_only(lab):
    """Keep the resident runtime alive when Wi-Fi is absent.

    The Win32 simulation host can still discover usb_cdc.data and expose a
    localhost HTTP/MCP bridge.  A network outage therefore removes one
    transport, not the laboratory itself.
    """
    print("SUPER MCP : USB bridge mode (network HTTP unavailable)")
    while True:
        lab.service()
        if lab.reload_requested:
            import supervisor
            print("SUPER: clean reload requested")
            supervisor.reload()
        time.sleep(ACCEPT_POLL_S)


def serve(registry, lab):
    if wifi.radio.ipv4_address is None:
        _service_usb_only(lab)
        return

    pool = socketpool.SocketPool(wifi.radio)
    server = pool.socket(socketpool.AF_INET, socketpool.SOCK_STREAM)
    try:
        server.setsockopt(socketpool.SOL_SOCKET, socketpool.SO_REUSEADDR, 1)
    except Exception:
        pass
    server.bind(("0.0.0.0", MCP_PORT))
    server.listen(2)
    # Poll rather than blocking forever so the resident core can continuously
    # service the USB simulator link for a host started after boot.
    try:
        server.settimeout(ACCEPT_POLL_S)
    except Exception:
        pass

    ip = str(wifi.radio.ipv4_address)
    print("SUPER MCP : http://%s:%d%s" % (ip, MCP_PORT, MCP_PATH))
    print("SUPER page: http://%s:%d/" % (ip, MCP_PORT))

    while True:
        conn = None
        # USB simulator discovery and heartbeats are serviced even when nobody
        # is making MCP calls.  This is what makes late host attachment work.
        lab.service()
        try:
            try:
                conn, _addr = server.accept()
            except OSError:
                # Normal accept timeout: no HTTP client during this poll slice.
                continue
            method, path, headers, body = _recv_http(conn)
            origin = headers.get("origin", "")
            cors = _cors_headers(origin)

            if method == "OPTIONS":
                _send(conn, 204, b"", extra_headers=cors)
                continue

            if method == "GET" and path == "/":
                _send(conn, 200, _status_page(registry), "text/html; charset=utf-8")
                continue

            if path != MCP_PATH:
                _send(conn, 404, "not found")
                continue
            if method != "POST":
                _send(conn, 405, "POST required", extra_headers=cors)
                continue
            # A browser Origin is not merely a CORS decoration.  If an Origin
            # is present, require the one explicitly configured for this bench.
            # This reduces accidental cross-origin access to a laboratory node.
            if origin and (not ALLOWED_ORIGIN or origin != ALLOWED_ORIGIN):
                _send(conn, 403, "origin not allowed")
                continue
            if not _authorized(headers):
                _send(conn, 401, "unauthorized", extra_headers=cors)
                continue
            if headers.get("mcp-protocol-version") != MCP_PROTOCOL:
                _send(conn, 400, "MCP-Protocol-Version required", extra_headers=cors)
                continue

            try:
                req = json.loads(body.decode("utf-8"))

                # MCP 2026-07-28 puts method/tool identity in HTTP headers so a
                # gateway can route or authorize without parsing the body.  A
                # small embedded server should still reject disagreement between
                # those two representations; otherwise the header is not a
                # trustworthy description of the request.
                body_method = req.get("method")
                header_method = headers.get("mcp-method")
                if header_method != body_method:
                    raise ValueError("Mcp-Method header/body mismatch")
                if body_method == "tools/call":
                    body_name = (req.get("params") or {}).get("name")
                    if headers.get("mcp-name") != body_name:
                        raise ValueError("Mcp-Name header/body mismatch")

                response = dispatch(req, registry)
                _send_json(conn, 200, response, cors)
            except Exception as exc:
                _send_json(conn, 400, {"error": str(exc)}, cors)

        except OverflowError as exc:
            if conn is not None:
                _send(conn, 413, str(exc))
        except Exception as exc:
            print("SUPER HTTP error:", exc)
            if conn is not None:
                try:
                    _send(conn, 500, str(exc))
                except Exception:
                    pass
        finally:
            if conn is not None:
                try:
                    conn.close()
                except Exception:
                    pass

        # Reload only AFTER the answer is safely off the wire.  The next VM run
        # reconstructs the registry from the newly active capability folders.
        if lab.reload_requested:
            import supervisor
            print("SUPER: clean reload requested")
            supervisor.reload()
