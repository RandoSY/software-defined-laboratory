"""Capability discovery, dependency checking, and guarded registration.

A capability package is *additive laboratory behavior*.  The loader's job is
not to make hostile Python safe -- CircuitPython is not a sandbox.  Its job is
to make trusted laboratory extension predictable and inspectable.

The complete v0.5 acceptance path is deliberately conservative:

  1. Only /capabilities is active; /staging is inert.
  2. A package must contain READY, manifest.json and module.py.
  3. The manifest identity and capability-API version are validated.
  4. Declared sensor/output dependencies are checked before import.
  5. register() writes into a private ToolRegistry transaction.
  6. The manifest's `provides` list must exactly match staged tool names.
  7. Only then is the whole tool set committed to public MCP discovery.
  8. One broken experiment therefore need not erase the permanent laboratory.

This turns a useful phrase -- "plug-in experiment" -- into an actual contract.
The board does not merely import arbitrary files.  It asks each package:

    Who are you?
    What do you require from this bench?
    What new vocabulary do you promise to provide?
    Can you register all of it successfully?

Only after all four answers are satisfactory does the AI see the capability.
"""

import json
import os

from .config import CAPABILITY_API_VERSION, CAPABILITY_ROOT


def _exists(path):
    try:
        os.stat(path)
        return True
    except OSError:
        return False


def _read_json(path):
    with open(path, "r") as f:
        return json.load(f)


def _safe_identifier(value):
    """Require a package id that is also a valid portable Python identifier.

    v0.4 allowed hyphens even though the loader imports
    ``capabilities.<id>.module``.  That mismatch is fixed here rather than
    merely documented: first character must be ASCII letter/underscore; the
    rest may additionally contain digits.
    """
    if not isinstance(value, str) or not value:
        return False
    first = value[0]
    if not (first == "_" or "A" <= first <= "Z" or "a" <= first <= "z"):
        return False
    for ch in value[1:]:
        if not (ch == "_" or "A" <= ch <= "Z" or "a" <= ch <= "z" or "0" <= ch <= "9"):
            return False
    return True


class CapabilityManager:
    def __init__(self, registry, lab):
        self.registry = registry
        self.lab = lab
        self.report = []

    def _record(self, package, status, message="", manifest=None, tools=None):
        item = {"package": package, "status": status, "message": message}
        if manifest:
            item["version"] = manifest.get("version")
            item["description"] = manifest.get("description", "")
            item["requires"] = manifest.get("requires", {})
        if tools is not None:
            item["tools"] = list(tools)
        self.report.append(item)
        return item

    def load_all(self):
        self.report = []
        if not _exists(CAPABILITY_ROOT):
            print("SUPER: no /capabilities directory; core only")
            self.lab.capability_report = self.report
            return self.report

        try:
            names = sorted(os.listdir(CAPABILITY_ROOT))
        except Exception as exc:
            self._record("*", "error", "cannot list capability root: %s" % exc)
            self.lab.capability_report = self.report
            return self.report

        for package in names:
            if package.startswith("_") or package.startswith("."):
                continue
            self.load_one(package)

        # Assign a fresh list only after the scan so tools such as super_info
        # observe a coherent snapshot rather than a list changing mid-call.
        self.lab.capability_report = list(self.report)
        return self.report

    def _validate_manifest(self, package, manifest):
        if not isinstance(manifest, dict):
            raise ValueError("manifest must be a JSON object")
        if manifest.get("apiVersion") != CAPABILITY_API_VERSION:
            raise ValueError("capability apiVersion mismatch")
        if not _safe_identifier(package):
            raise ValueError("unsafe package directory name")
        if manifest.get("id") != package:
            raise ValueError("manifest id must match directory name")
        if manifest.get("entrypoint", "module") != "module":
            raise ValueError("seed loader supports entrypoint 'module' only")

        provides = manifest.get("provides", [])
        if not isinstance(provides, list) or not all(isinstance(x, str) and x for x in provides):
            raise ValueError("manifest provides must be a list of tool names")
        if len(set(provides)) != len(provides):
            raise ValueError("manifest provides contains duplicates")

        requires = manifest.get("requires", {})
        if requires is None:
            requires = {}
        if not isinstance(requires, dict):
            raise ValueError("manifest requires must be an object")
        for key in requires:
            if key not in ("sensors", "outputs"):
                raise ValueError("unsupported requirement class: " + str(key))
        for key in ("sensors", "outputs"):
            values = requires.get(key, [])
            if not isinstance(values, list) or not all(isinstance(x, str) and x for x in values):
                raise ValueError("requires.%s must be a list of names" % key)

        return provides, requires

    def _check_dependencies(self, requires):
        missing = []
        for sensor in requires.get("sensors", []):
            if not self.lab.has_sensor(sensor):
                missing.append("sensor:" + sensor)
        for output in requires.get("outputs", []):
            if not self.lab.has_output(output):
                missing.append("output:" + output)
        if missing:
            raise ValueError("missing laboratory dependencies: " + ", ".join(missing))

    def load_one(self, package):
        base = CAPABILITY_ROOT + "/" + package
        manifest_path = base + "/manifest.json"
        module_path = base + "/module.py"
        ready_path = base + "/READY"

        # READY is more than a flag.  It is the assertion that the transfer
        # protocol considers this directory complete.  The loader never tries
        # to infer completeness from a partially populated directory.
        if not _exists(ready_path):
            return self._record(package, "ignored", "READY marker missing")
        if not _exists(manifest_path) or not _exists(module_path):
            return self._record(package, "error", "manifest.json or module.py missing")

        manifest = None
        try:
            manifest = _read_json(manifest_path)
            provides, requires = self._validate_manifest(package, manifest)
            self._check_dependencies(requires)

            # Dynamic import is deliberately performed only after declarative
            # checks.  We still trust package code: CircuitPython cannot safely
            # sandbox a malicious or infinitely-blocking module.  The intended
            # security boundary is "trusted capability repository / trusted AI
            # deposition", not arbitrary public code execution.
            dotted = "capabilities.%s.module" % package
            mod = __import__(dotted, None, None, ["register"])
            register = getattr(mod, "register", None)
            if not callable(register):
                raise ValueError("module.py must define register(registry, lab)")

            # MEMORY-SIDE TWO-PHASE COMMIT.
            # register() receives a registry-shaped transaction.  It can stage
            # several tools, but none becomes visible to tools/list yet.
            tx = self.registry.begin_transaction(package)
            register(tx, self.lab)

            staged = tx.names()
            if set(staged) != set(provides) or len(staged) != len(provides):
                raise ValueError(
                    "manifest provides does not match registered tools; manifest=%r registered=%r"
                    % (provides, staged)
                )

            committed = tx.commit()
            return self._record(package, "active", "registered transactionally", manifest, committed)

        except Exception as exc:
            # Because registration was staged, an exception here leaves no
            # half-visible tool set behind.  The resident core and unrelated
            # capabilities remain usable.
            print("SUPER: capability %s failed: %s" % (package, exc))
            return self._record(package, "error", str(exc), manifest)
