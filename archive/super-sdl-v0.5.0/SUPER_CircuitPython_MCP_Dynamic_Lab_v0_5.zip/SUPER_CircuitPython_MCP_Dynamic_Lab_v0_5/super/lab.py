"""Stable physical/virtual laboratory substrate.

The important v0.5 change is that simulation becomes a *backend*, not a place
where experiment logic lives.  ``Lab.read_sensor('temp1')`` resolves through:

    Windows host over USB CDC, when automatically connected
            OR
    resident fallback simulator, when no host is present
            OR (future)
    a physical driver bound to the same logical role

MCP and experiment capabilities see the same sensor identity in all cases.
"""

import gc
import math
import time

from .hostlink import HostSimLink

try:
    import board
    import digitalio
except ImportError:
    board = None
    digitalio = None


START = time.monotonic()


def uptime_s():
    return time.monotonic() - START


def clamp(v, lo, hi):
    return lo if v < lo else hi if v > hi else v


class SimEngine:
    """Small resident fallback simulator.

    The rich simulator now lives on the workstation.  This engine remains on
    the Pico for resilience and standalone demonstrations.  A missing Windows
    process therefore degrades simulation fidelity, not laboratory identity.
    """

    DEFAULTS = {
        "temperature_c": (22.50, 0.35, 70.0, 0.025),
        "light_lux": (420.0, 260.0, 32.0, 3.0),
        "humidity_pct": (44.0, 4.0, 95.0, 0.10),
        "pressure_hpa": (1013.2, 1.25, 180.0, 0.03),
        "voltage_v": (2.500, 0.180, 26.0, 0.004),
        "pot_pct": (50.0, 45.0, 40.0, 0.15),
    }

    def __init__(self):
        self.channels = {}
        self._rng = 0x13579BDF
        self.reset()

    def _rand01(self):
        self._rng = (1664525 * self._rng + 1013904223) & 0xFFFFFFFF
        return ((self._rng >> 8) & 0xFFFFFF) / 16777215.0

    def _noise(self, span):
        return (self._rand01() * 2.0 - 1.0) * span

    def reset(self):
        self.channels = {}
        for name, spec in self.DEFAULTS.items():
            self.channels[name] = {
                "base": float(spec[0]), "amplitude": float(spec[1]),
                "period_s": float(spec[2]), "noise": float(spec[3]), "enabled": True,
            }

    def value(self, name, phase=0.0):
        c = self.channels[name]
        if not c["enabled"]:
            return None
        w = math.sin(2.0 * math.pi * uptime_s() / c["period_s"] + phase)
        return c["base"] + c["amplitude"] * w + self._noise(c["noise"])

    def configure(self, name, changes):
        if name not in self.channels:
            raise ValueError("unknown channel: " + name)
        candidate = dict(self.channels[name])
        for key in ("base", "amplitude", "period_s", "noise"):
            if key in changes:
                candidate[key] = float(changes[key])
        if "enabled" in changes:
            candidate["enabled"] = bool(changes["enabled"])
        if candidate["period_s"] <= 0:
            raise ValueError("period_s must be > 0")
        if candidate["noise"] < 0:
            raise ValueError("noise must be >= 0")
        self.channels[name] = candidate
        return dict(candidate)


class Lab:
    """Stable experiment-facing abstraction of one SUPER bench."""

    def __init__(self, node_name="super-bench-01", ip=None, mcp_port=8000, server_version="0.5.0", hostname=None):
        self.node_name = node_name
        self.ip = ip
        self.mcp_port = mcp_port
        self.server_version = server_version
        self.hostname = hostname or node_name
        self.discovery_status = {"active": False, "reason": "not attempted"}
        self.sim = SimEngine()
        self.reload_requested = False
        self.capability_report = []
        self._led = None
        self.outputs = {
            "led": False,
            "gpio0": False,
            "pwm_frequency_hz": 1000.0,
            "pwm_duty_pct": 0.0,
        }
        self.sensor_descriptors = [
            {"id": "temp1", "model": "DS18B20", "interface": "1-Wire", "unit": "degC"},
            {"id": "light1", "model": "BH1750", "interface": "I2C", "unit": "lux"},
            {"id": "env1", "model": "BME280", "interface": "I2C", "unit": "mixed"},
            {"id": "adc1", "model": "SUPER-ADC", "interface": "ADC", "unit": "V"},
            {"id": "pot1", "model": "10k-POT", "interface": "ADC", "unit": "percent"},
            {"id": "accel1", "model": "MPU6050", "interface": "I2C", "unit": "g"},
        ]
        self.i2c_devices = [
            {"address": 0x23, "addressHex": "0x23", "device": "BH1750", "role": "light"},
            {"address": 0x3C, "addressHex": "0x3C", "device": "SSD1306", "role": "oled"},
            {"address": 0x68, "addressHex": "0x68", "device": "DS3231", "role": "rtc"},
            {"address": 0x76, "addressHex": "0x76", "device": "BME280", "role": "environment"},
        ]
        self._setup_led()
        self.host = HostSimLink({
            "node": self.node_name,
            "serverVersion": self.server_version,
            "ip": self.ip,
            "mcpPort": int(self.mcp_port),
            "hostname": str(self.hostname),
        })

    def service(self):
        """Service the nonblocking USB simulator link.

        The HTTP server calls this frequently even when no MCP request exists;
        that is what lets a Windows host started *later* still discover the
        already-running Pico without a reset.
        """
        self.host.service()

    def active_backend(self):
        return "win32-sim" if self.host.connected else "local-sim"

    def simulation_status(self):
        status = self.host.status()
        status["activeBackend"] = self.active_backend()
        status["fallbackAvailable"] = True
        return status

    def sensor_inventory(self):
        backend = self.active_backend()
        out = []
        for item in self.sensor_descriptors:
            d = dict(item)
            d["backend"] = backend
            d["sources"] = ["win32-sim", "local-sim", "hardware-future"]
            out.append(d)
        return out

    def i2c_inventory(self):
        backend = self.active_backend()
        return [dict(d, backend=backend) for d in self.i2c_devices]

    def _setup_led(self):
        if board is None or digitalio is None:
            return
        try:
            pin = digitalio.DigitalInOut(board.LED)
            pin.direction = digitalio.Direction.OUTPUT
            self._led = pin
        except Exception as exc:
            print("SUPER: onboard LED unavailable:", exc)
            self._led = None

    def _disabled(self, sid, model):
        return {
            "id": sid, "model": model, "status": "disabled", "value": None,
            "backend": "local-sim", "uptimeS": round(uptime_s(), 3),
        }

    def _read_local(self, sid):
        t = uptime_s()
        if sid == "temp1":
            v = self.sim.value("temperature_c")
            if v is None:
                return self._disabled(sid, "DS18B20")
            return {"id": sid, "model": "DS18B20", "temperatureC": round(v, 3), "status": "ok", "backend": "local-sim", "uptimeS": round(t, 3)}
        if sid == "light1":
            v = self.sim.value("light_lux")
            if v is None:
                return self._disabled(sid, "BH1750")
            return {"id": sid, "model": "BH1750", "lux": round(max(0, v), 2), "status": "ok", "backend": "local-sim", "uptimeS": round(t, 3)}
        if sid == "env1":
            tv = self.sim.value("temperature_c", 0.2)
            hv = self.sim.value("humidity_pct")
            pv = self.sim.value("pressure_hpa")
            if tv is None or hv is None or pv is None:
                return self._disabled(sid, "BME280")
            return {"id": sid, "model": "BME280", "temperatureC": round(tv, 3), "humidityPct": round(clamp(hv, 0, 100), 2), "pressureHpa": round(pv, 2), "status": "ok", "backend": "local-sim", "uptimeS": round(t, 3)}
        if sid == "adc1":
            v = self.sim.value("voltage_v")
            if v is None:
                return self._disabled(sid, "SUPER-ADC")
            v = clamp(v, 0, 3.3)
            return {"id": sid, "model": "SUPER-ADC", "volts": round(v, 5), "rawU16": int(v / 3.3 * 65535), "status": "ok", "backend": "local-sim", "uptimeS": round(t, 3)}
        if sid == "pot1":
            v = self.sim.value("pot_pct")
            if v is None:
                return self._disabled(sid, "10k-POT")
            p = clamp(v, 0, 100)
            return {"id": sid, "model": "10k-POT", "positionPct": round(p, 2), "rawU16": int(p / 100 * 65535), "status": "ok", "backend": "local-sim", "uptimeS": round(t, 3)}
        if sid == "accel1":
            x = 0.006 * math.sin(t * 2.5)
            y = 0.005 * math.sin(t * 1.9 + 0.5)
            z = 1.0 + 0.003 * math.sin(t * 4.0)
            return {"id": sid, "model": "MPU6050", "xG": round(x, 5), "yG": round(y, 5), "zG": round(z, 5), "magnitudeG": round(math.sqrt(x*x+y*y+z*z), 5), "status": "ok", "backend": "local-sim", "uptimeS": round(t, 3)}
        raise ValueError("unknown sensor id: " + sid)

    def read_sensor(self, sid):
        if not self.has_sensor(sid):
            raise ValueError("unknown sensor id: " + sid)
        self.host.service()
        if self.host.connected:
            result = self.host.call("sensor.read", {"id": sid})
            if isinstance(result, dict):
                return result
        return self._read_local(sid)

    def has_sensor(self, sid):
        return any(d.get("id") == sid for d in self.sensor_descriptors)

    def has_output(self, name):
        return name in self.outputs

    def read_all(self):
        self.host.service()
        if self.host.connected:
            result = self.host.call("sensor.read_all", {})
            if isinstance(result, dict) and isinstance(result.get("readings"), dict):
                return result["readings"]
        return {d["id"]: self._read_local(d["id"]) for d in self.sensor_descriptors}

    def set_output(self, name, value):
        if name not in self.outputs:
            raise ValueError("unknown output: " + name)
        if name in ("led", "gpio0"):
            value = bool(value)
        elif name == "pwm_frequency_hz":
            value = float(value)
            if value < 1 or value > 1000000:
                raise ValueError("pwm_frequency_hz must be 1..1000000")
        elif name == "pwm_duty_pct":
            value = float(value)
            if value < 0 or value > 100:
                raise ValueError("pwm_duty_pct must be 0..100")

        self.outputs[name] = value
        if name == "led" and self._led is not None:
            self._led.value = value
        self.host.notify("output.event", {"output": name, "value": value})
        return value

    def scenario_list(self):
        result = self.host.call("scenario.list", {}) if self.host.connected else None
        if result is None:
            return {"current": "local-fallback", "scenarios": ["local-fallback"], "hostRequired": True}
        return result

    def scenario_set(self, name):
        if not self.host.connected:
            raise RuntimeError("Win32 simulation host is not connected")
        result = self.host.call("scenario.set", {"name": name})
        if result is None:
            raise RuntimeError("simulation host did not accept scenario")
        return result

    def waveform_capture(self, samples=64, sample_rate_hz=1000.0):
        if self.host.connected:
            result = self.host.call("waveform.capture", {"samples": samples, "sampleRateHz": sample_rate_hz}, timeout_s=1.0)
            if result is not None:
                return result
        samples = max(1, min(int(samples), 128))
        rate = max(1.0, float(sample_rate_hz))
        vals = []
        t0 = uptime_s()
        for i in range(samples):
            tt = t0 + i / rate
            vals.append(round(clamp(1.65 + 0.7 * math.sin(2 * math.pi * 0.5 * tt), 0, 3.3), 5))
        return {"channel": "adc1", "samples": vals, "sampleRateHz": rate, "unit": "V", "backend": "local-sim"}

    def free_heap(self):
        try:
            return gc.mem_free()
        except AttributeError:
            return None
