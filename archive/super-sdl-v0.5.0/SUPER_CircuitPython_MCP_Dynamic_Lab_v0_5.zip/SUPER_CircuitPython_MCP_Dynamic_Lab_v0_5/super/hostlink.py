"""USB link from the resident Pico W laboratory to a workstation simulator.

The link is intentionally small and human-readable.  Every frame is one JSON
object followed by ``\n``.  That gives us a transport which is:

* inspectable with an ordinary serial terminal,
* easy to emulate in desktop tests,
* self-delimiting without binary framing machinery, and
* independent of MCP.  MCP describes laboratory *meaning*; SUPER-SIM/1 moves
  simulated physical state between the workstation and the Pico.

The Pico remains the laboratory identity and MCP endpoint.  The workstation is
just another backend beneath ``Lab``.  If the host disappears, the resident
runtime can fall back to its small local simulator instead of disappearing.
"""

import json
import time

try:
    import usb_cdc
except ImportError:
    usb_cdc = None


PROTOCOL = "SUPER-SIM/1"
DEFAULT_REQUEST_TIMEOUT_S = 0.45
CONNECTED_WINDOW_S = 4.0
HELLO_INTERVAL_DISCOVERY_S = 0.5
HELLO_INTERVAL_CONNECTED_S = 2.0
MAX_LINE_BYTES = 4096


class HostSimLink:
    """Synchronous request/reply client with a tiny background service loop.

    There is deliberately at most one outstanding Pico->host request.  A Pico W
    laboratory is not improved by pretending its USB serial link is a message
    broker.  The simple invariant makes failures much easier to reason about.
    """

    def __init__(self, node_info=None):
        self.node_info = dict(node_info or {})
        self.port = None
        self.rx = bytearray()
        self.seq = 0
        self.pending = {}
        self.last_host_seen = -1e9
        self.last_hello_sent = -1e9
        self.last_error = None
        self.frames_rx = 0
        self.frames_tx = 0
        self.mcp_handler = None

        if usb_cdc is not None:
            try:
                self.port = usb_cdc.data
                if self.port is not None:
                    # Non-blocking reads let the HTTP loop service USB without
                    # ever stalling while no workstation is attached.
                    self.port.timeout = 0
                    self.port.write_timeout = 0.05
            except Exception as exc:
                self.last_error = "usb_cdc.data unavailable: %s" % exc
                self.port = None

    @property
    def available(self):
        return self.port is not None

    @property
    def connected(self):
        return self.available and (time.monotonic() - self.last_host_seen) < CONNECTED_WINDOW_S

    def set_node_info(self, **values):
        self.node_info.update(values)

    def set_mcp_handler(self, handler):
        """Install the resident MCP dispatcher used by the USB localhost bridge.

        The Windows simulation host may expose a loopback HTTP endpoint and
        forward an MCP JSON-RPC request through this same CDC data channel.
        The request is still executed *here*, against the Pico's real registry
        and deposited capabilities.  The host is a transport bridge, not a
        second implementation of the laboratory vocabulary.
        """
        self.mcp_handler = handler

    def status(self):
        return {
            "transport": "usb-cdc-jsonl",
            "protocol": PROTOCOL,
            "available": self.available,
            "connected": self.connected,
            "lastHostSeenAgoS": None if self.last_host_seen < 0 else round(time.monotonic() - self.last_host_seen, 3),
            "framesRx": self.frames_rx,
            "framesTx": self.frames_tx,
            "lastError": self.last_error,
            "node": dict(self.node_info),
        }

    def _send(self, obj):
        if not self.available:
            return False
        try:
            if not self.port.connected:
                return False
        except AttributeError:
            pass
        frame = dict(obj)
        frame.setdefault("protocol", PROTOCOL)
        raw = (json.dumps(frame) + "\n").encode("utf-8")
        try:
            written = self.port.write(raw)
            if written != len(raw):
                self.last_error = "short USB write: %s/%s" % (written, len(raw))
                return False
            self.frames_tx += 1
            return True
        except Exception as exc:
            self.last_error = "USB write failed: %s" % exc
            return False

    def _hello(self):
        payload = {"op": "hello"}
        payload.update(self.node_info)
        return self._send(payload)

    def _handle_frame(self, msg):
        if msg.get("protocol") != PROTOCOL:
            return
        self.frames_rx += 1
        self.last_host_seen = time.monotonic()
        op = msg.get("op")

        # ``probe`` is retained for protocol compatibility, although v0.5's
        # normal scanner now discovers the data CDC passively from unsolicited
        # hello frames so it never writes probe text into the console CDC.
        if op in ("probe", "ping"):
            self._hello()
            return

        if op == "response":
            rid = msg.get("id")
            self.pending[rid] = msg
            return

        if op == "mcp_request":
            # USB can therefore carry MCP when Wi-Fi is unavailable.  This is
            # deliberately a request to the *resident* dispatcher: the host
            # never invents or mirrors the Pico's tool registry.
            rid = msg.get("id")
            req = msg.get("request")
            if self.mcp_handler is None:
                response = {
                    "jsonrpc": "2.0", "id": (req or {}).get("id"),
                    "error": {"code": -32603, "message": "resident MCP dispatcher unavailable"},
                }
            else:
                try:
                    response = self.mcp_handler(req)
                except Exception as exc:
                    response = {
                        "jsonrpc": "2.0", "id": (req or {}).get("id"),
                        "error": {"code": -32603, "message": "USB MCP dispatch failed", "data": str(exc)},
                    }
            self._send({"op": "mcp_response", "id": rid, "response": response})
            return

        # Host-originated informational frames are intentionally tiny in v0.5.
        # They keep the channel extensible without allowing arbitrary host code
        # execution on the Pico.
        if op == "notice":
            self.last_error = msg.get("message")

    def service(self):
        """Consume any complete host frames without blocking."""
        if not self.available:
            return
        try:
            chunk = self.port.read(256)
        except Exception as exc:
            self.last_error = "USB read failed: %s" % exc
            return
        if chunk:
            self.rx.extend(chunk)
            if len(self.rx) > MAX_LINE_BYTES * 2:
                self.rx = bytearray()
                self.last_error = "SUPER-SIM receive buffer overflow"
                return

        while True:
            try:
                idx = self.rx.index(10)  # '\n'
            except ValueError:
                break
            raw = bytes(self.rx[:idx])
            del self.rx[:idx + 1]
            if not raw:
                continue
            if len(raw) > MAX_LINE_BYTES:
                self.last_error = "SUPER-SIM frame too large"
                continue
            try:
                self._handle_frame(json.loads(raw.decode("utf-8")))
            except Exception as exc:
                self.last_error = "bad SUPER-SIM frame: %s" % exc

        # Unsolicited hello makes discovery passive and harmless: the workstation
        # may open both CircuitPython CDC ports, but only usb_cdc.data emits this
        # frame.  Nothing is written into the student's REPL during discovery.
        now = time.monotonic()
        interval = HELLO_INTERVAL_CONNECTED_S if self.connected else HELLO_INTERVAL_DISCOVERY_S
        if now - self.last_hello_sent > interval:
            if self._hello():
                self.last_hello_sent = now

    def call(self, method, params=None, timeout_s=DEFAULT_REQUEST_TIMEOUT_S):
        """Call one simulator-host method; return result or ``None`` on timeout."""
        if not self.available:
            return None
        self.service()
        if not self.connected:
            return None

        self.seq = (self.seq + 1) & 0x7FFFFFFF
        rid = self.seq
        self.pending.pop(rid, None)
        if not self._send({"op": "request", "id": rid, "method": method, "params": params or {}}):
            return None

        deadline = time.monotonic() + timeout_s
        while time.monotonic() < deadline:
            self.service()
            msg = self.pending.pop(rid, None)
            if msg is not None:
                if msg.get("ok"):
                    return msg.get("result")
                self.last_error = str(msg.get("error", "host request failed"))
                return None
            time.sleep(0.005)
        self.last_error = "host request timeout: " + str(method)
        return None

    def notify(self, method, params=None):
        """Best-effort event.  No response is required."""
        if not self.connected:
            return False
        return self._send({"op": "event", "method": method, "params": params or {}})
