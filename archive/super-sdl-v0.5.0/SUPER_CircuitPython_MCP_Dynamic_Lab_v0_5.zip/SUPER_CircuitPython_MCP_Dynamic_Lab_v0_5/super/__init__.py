"""SUPER resident laboratory runtime.

Everything in this package is intended to be comparatively permanent.
Capabilities outside this package are intended to be replaceable.
"""
