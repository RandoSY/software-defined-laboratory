"""The vocabulary of the laboratory.

A ToolRegistry is the seam between "code exists" and "the AI knows the
laboratory can do this."  A Python function does not become an AI-visible
capability merely because it is present on flash.  It becomes a capability
when it is deliberately registered with a name, description and schema.

That small distinction is the music of the architecture:

    deposited Python + registration -> new laboratory vocabulary

v0.5 retains an equally important reliability rule introduced in v0.4:

    registration is transactional

A capability is allowed to *prepare* several tools in a private staging
registry.  Only after its register() function returns successfully, dependency
checks pass, and its manifest agrees with the tools it claims to provide are
all of those tools committed to the public registry together.

Without that rule, an experiment could register tool A, register tool B, fail
while creating tool C, and leave the AI seeing half an experiment.  That is the
software equivalent of wiring only half an instrument and labeling it ready.
SUPER should never advertise a capability it has not completely accepted.
"""


class ToolRegistry:
    def __init__(self):
        self._definitions = []
        self._handlers = {}
        self._owners = {}

    def _validate_registration(self, definition, handler, staged_names=None):
        name = definition.get("name") if isinstance(definition, dict) else None
        if not name:
            raise ValueError("tool definition requires a name")
        if name in self._handlers:
            raise ValueError("duplicate tool name: " + name)
        if staged_names is not None and name in staged_names:
            raise ValueError("duplicate staged tool name: " + name)
        if not callable(handler):
            raise ValueError("handler for %s is not callable" % name)
        schema = definition.get("inputSchema")
        if not isinstance(schema, dict) or schema.get("type") != "object":
            raise ValueError("tool %s requires an object inputSchema" % name)
        return name

    def register(self, definition, handler, owner="core"):
        """Register one callable laboratory capability immediately.

        The permanent core uses this method directly because its own tools are
        constructed as part of one trusted boot sequence.  Deposited
        capabilities should instead use begin_transaction(), which returns a
        registry-shaped staging object.
        """
        name = self._validate_registration(definition, handler)
        self._definitions.append(definition)
        self._handlers[name] = handler
        self._owners[name] = owner

    def begin_transaction(self, owner):
        """Create a private registry used while one capability is prepared.

        The returned object deliberately exposes the same register() method a
        normal capability expects.  Capability authors therefore do not need
        to know whether they are writing into the live registry or a staging
        registry.  The manager decides when the transaction becomes visible.
        """
        return _RegistryTransaction(self, owner)

    def definitions(self):
        # Return a shallow copy so callers do not accidentally append directly
        # to the registry and bypass duplicate-name checks.
        return list(self._definitions)

    def call(self, name, arguments):
        handler = self._handlers.get(name)
        if handler is None:
            raise KeyError("unknown tool: " + str(name))
        return handler(arguments or {})

    def owner_of(self, name):
        return self._owners.get(name)

    def inventory(self):
        return [
            {"name": d["name"], "owner": self._owners.get(d["name"], "?")}
            for d in self._definitions
        ]


class _RegistryTransaction:
    """Private, all-or-nothing tool-registration transaction.

    A capability receives this object as though it were the real registry.
    register() performs the same validation as the live registry but stores
    nothing publicly.  commit() is the sole visibility boundary.

    This mirrors the deployment transaction on the filesystem:

        /staging -> verify -> MOVE -> /capabilities

    and gives us the same pattern in memory:

        staged tool definitions -> verify -> commit -> tools/list

    Repeating one simple pattern at multiple layers is intentional.  Systems
    become easier to reason about when "ready" means the same thing everywhere.
    """

    def __init__(self, parent, owner):
        self._parent = parent
        self._owner = owner
        self._items = []
        self._names = set()
        self._committed = False

    def register(self, definition, handler, owner=None):
        if self._committed:
            raise RuntimeError("registration transaction already committed")
        # A deposited capability cannot pretend to be another owner.  The
        # directory/manifest identity is authoritative for diagnostics.
        if owner is not None and owner != self._owner:
            raise ValueError("capability may not override transaction owner")
        name = self._parent._validate_registration(definition, handler, self._names)
        self._items.append((definition, handler))
        self._names.add(name)

    def names(self):
        return [definition["name"] for definition, _handler in self._items]

    def commit(self):
        if self._committed:
            raise RuntimeError("registration transaction already committed")

        # Re-check all names immediately before mutation.  Another core
        # registration is unlikely during boot, but the invariant costs almost
        # nothing and makes the transaction semantically complete.
        for definition, handler in self._items:
            self._parent._validate_registration(definition, handler)

        # Only after every staged item has passed validation do we mutate the
        # public registry.  There is no user-code execution inside this loop,
        # so a partial commit is not expected under normal operation.
        for definition, handler in self._items:
            name = definition["name"]
            self._parent._definitions.append(definition)
            self._parent._handlers[name] = handler
            self._parent._owners[name] = self._owner

        self._committed = True
        return self.names()
