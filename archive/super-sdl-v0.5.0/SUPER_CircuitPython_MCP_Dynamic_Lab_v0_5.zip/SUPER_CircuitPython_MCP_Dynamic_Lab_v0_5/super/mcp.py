"""Small MCP 2026-07-28 dispatcher for SUPER v0.5.

MCP remains stateless and remains *above* the simulation transport.  Whether a
sensor value was produced by Win32, the resident fallback model, record/replay,
or future silicon is provenance in the result—not a different tool name.
"""

import time

from .config import MCP_PROTOCOL, SERVER_NAME, SERVER_VERSION


def server_meta():
    return {"io.modelcontextprotocol/serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION}}


def complete(**kw):
    result = {"resultType": "complete", "_meta": server_meta()}
    result.update(kw)
    return result


def cacheable(ttl_ms, scope, **kw):
    result = complete(ttlMs=int(ttl_ms), cacheScope=scope)
    result.update(kw)
    return result


def tool_ok(text, data=None):
    result = complete(content=[{"type": "text", "text": text}], isError=False)
    if data is not None:
        result["structuredContent"] = data
    return result


def tool_fail(text, data=None):
    result = complete(content=[{"type": "text", "text": str(text)}], isError=True)
    if data is not None:
        result["structuredContent"] = data
    return result


def rpc_ok(req_id, result):
    return {"jsonrpc": "2.0", "id": req_id, "result": result}


def rpc_error(req_id, code, message, data=None):
    err = {"code": code, "message": str(message)}
    if data is not None:
        err["data"] = data
    return {"jsonrpc": "2.0", "id": req_id, "error": err}


def _empty_schema():
    return {"type": "object", "properties": {}, "additionalProperties": False}


def register_core_tools(registry, lab):
    """Permanent vocabulary shared by simulated, hybrid and physical labs."""

    def super_info(_args):
        data = {
            "name": "SUPER Dynamic Laboratory",
            "node": lab.node_name,
            "mcpProtocol": MCP_PROTOCOL,
            "serverVersion": SERVER_VERSION,
            "ip": str(lab.ip),
            "freeHeapBytes": lab.free_heap(),
            "sensorCount": len(lab.sensor_descriptors),
            "capabilities": lab.capability_report,
            "simulation": lab.simulation_status(),
            "discovery": lab.discovery_status,
            "uptimeS": round(time.monotonic(), 3),
        }
        return tool_ok("SUPER laboratory online", data)

    registry.register({
        "name": "super_info", "title": "SUPER Information",
        "description": "Describe the resident SUPER runtime, discovery state, simulation backend and loaded capabilities.",
        "inputSchema": _empty_schema(),
        "annotations": {"readOnlyHint": True, "idempotentHint": True},
    }, super_info)

    def sensor_list(_args):
        sensors = lab.sensor_inventory()
        return tool_ok("sensor inventory", {"sensors": sensors, "count": len(sensors)})

    registry.register({
        "name": "sensor_list", "title": "List Laboratory Sensors",
        "description": "List stable sensor identities and current provenance. Backend may change without changing sensor IDs.",
        "inputSchema": _empty_schema(),
        "annotations": {"readOnlyHint": True, "idempotentHint": True},
    }, sensor_list)

    def sensor_read(args):
        return tool_ok("sensor read", lab.read_sensor(str(args.get("id", ""))))

    registry.register({
        "name": "sensor_read", "title": "Read One Laboratory Sensor",
        "description": "Read one stable SUPER sensor role from the active simulation or hardware backend.",
        "inputSchema": {
            "type": "object",
            "properties": {"id": {"type": "string", "enum": [d["id"] for d in lab.sensor_descriptors]}},
            "required": ["id"], "additionalProperties": False,
        },
        "annotations": {"readOnlyHint": True},
    }, sensor_read)

    def sensor_read_all(_args):
        return tool_ok("sensor snapshot", {"readings": lab.read_all(), "backend": lab.active_backend()})

    registry.register({
        "name": "sensor_read_all", "title": "Read All Laboratory Sensors",
        "description": "Take one context snapshot of the laboratory through the active backend.",
        "inputSchema": _empty_schema(),
        "annotations": {"readOnlyHint": True},
    }, sensor_read_all)

    def bus_scan(_args):
        return tool_ok("I2C scan", {"devices": lab.i2c_inventory(), "backend": lab.active_backend()})

    registry.register({
        "name": "i2c_scan", "title": "Scan I2C Bus",
        "description": "Return known I2C devices. The interface remains stable across simulation and hardware.",
        "inputSchema": _empty_schema(),
        "annotations": {"readOnlyHint": True, "idempotentHint": True},
    }, bus_scan)

    def simulator_set(args):
        name = str(args.get("channel", ""))
        return tool_ok("local fallback simulation channel updated", {"channel": name, "settings": lab.sim.configure(name, args)})

    registry.register({
        "name": "simulator_set", "title": "Configure Local Fallback Simulator",
        "description": "Tune one resident fallback channel. Rich Win32 simulation is controlled by simulation_scenario_set.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "channel": {"type": "string", "enum": list(lab.sim.DEFAULTS.keys())},
                "base": {"type": "number"}, "amplitude": {"type": "number"},
                "period_s": {"type": "number", "exclusiveMinimum": 0},
                "noise": {"type": "number", "minimum": 0}, "enabled": {"type": "boolean"},
            },
            "required": ["channel"], "additionalProperties": False,
        },
    }, simulator_set)

    def simulation_status(_args):
        return tool_ok("simulation backend status", lab.simulation_status())

    registry.register({
        "name": "simulation_status", "title": "Simulation Backend Status",
        "description": "Show whether the automatic USB-connected Win32 simulation host is active or the Pico is using local fallback simulation.",
        "inputSchema": _empty_schema(),
        "annotations": {"readOnlyHint": True, "idempotentHint": True},
    }, simulation_status)

    def scenario_list(_args):
        return tool_ok("simulation scenarios", lab.scenario_list())

    registry.register({
        "name": "simulation_scenario_list", "title": "List Simulation Scenarios",
        "description": "List scenarios supplied by the connected workstation simulation host.",
        "inputSchema": _empty_schema(),
        "annotations": {"readOnlyHint": True, "idempotentHint": True},
    }, scenario_list)

    def scenario_set(args):
        name = str(args.get("name", ""))
        return tool_ok("simulation scenario changed", lab.scenario_set(name))

    registry.register({
        "name": "simulation_scenario_set", "title": "Set Simulation Scenario",
        "description": "Select a causal Win32-hosted scenario for repeatable experiments or fault injection.",
        "inputSchema": {
            "type": "object", "properties": {"name": {"type": "string"}},
            "required": ["name"], "additionalProperties": False,
        },
        "annotations": {"readOnlyHint": False, "idempotentHint": True},
    }, scenario_set)

    def waveform_capture(args):
        data = lab.waveform_capture(args.get("samples", 64), args.get("sampleRateHz", 1000.0))
        return tool_ok("waveform captured", data)

    registry.register({
        "name": "waveform_capture", "title": "Capture Simulated Waveform",
        "description": "Capture an ADC waveform from the active backend. The workstation host supports larger captures than local fallback.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "samples": {"type": "integer", "minimum": 1, "maximum": 2048},
                "sampleRateHz": {"type": "number", "minimum": 1},
            },
            "additionalProperties": False,
        },
        "annotations": {"readOnlyHint": True},
    }, waveform_capture)

    def output_set(args):
        name = str(args.get("output", ""))
        value = lab.set_output(name, args.get("value"))
        return tool_ok("output updated", {"output": name, "value": value, "allOutputs": lab.outputs})

    registry.register({
        "name": "output_set", "title": "Set Laboratory Output",
        "description": "Set a validated SUPER output. Physical LED changes are mirrored into the Win32 causal simulation when connected.",
        "inputSchema": {
            "type": "object",
            "properties": {"output": {"type": "string", "enum": list(lab.outputs.keys())}, "value": {}},
            "required": ["output", "value"], "additionalProperties": False,
        },
        "annotations": {"readOnlyHint": False, "idempotentHint": True},
    }, output_set)

    def capability_list(_args):
        return tool_ok("capability inventory", {"packages": lab.capability_report, "tools": registry.inventory()})

    registry.register({
        "name": "capability_list", "title": "List Installed Capabilities",
        "description": "Show which experiment packages registered successfully and which tools each package contributed.",
        "inputSchema": _empty_schema(),
        "annotations": {"readOnlyHint": True, "idempotentHint": True},
    }, capability_list)

    def system_reload(_args):
        lab.reload_requested = True
        return tool_ok("reload scheduled after this MCP response", {"reloadScheduled": True})

    registry.register({
        "name": "system_reload", "title": "Reload SUPER Runtime",
        "description": "Schedule a clean CircuitPython reload after the current response. Used after capability deployment.",
        "inputSchema": _empty_schema(),
        "annotations": {"readOnlyHint": False, "idempotentHint": True},
    }, system_reload)


def _validate_meta(req):
    params = req.get("params")
    if not isinstance(params, dict):
        raise ValueError("params object required")
    meta = params.get("_meta")
    if not isinstance(meta, dict):
        raise ValueError("params._meta required")
    if meta.get("io.modelcontextprotocol/protocolVersion") != MCP_PROTOCOL:
        raise ValueError("unsupported MCP protocol version")


def dispatch(req, registry):
    rid = req.get("id")
    if req.get("jsonrpc") != "2.0":
        return rpc_error(rid, -32600, "Invalid Request")
    try:
        _validate_meta(req)
    except Exception as exc:
        return rpc_error(rid, -32602, "Invalid MCP metadata", str(exc))

    method = req.get("method")
    if method == "server/discover":
        return rpc_ok(rid, cacheable(
            3600000, "public", supportedVersions=[MCP_PROTOCOL], capabilities={"tools": {}},
            instructions=(
                "SUPER is a dynamically extensible laboratory endpoint. The same sensor/tool identities may be backed by "
                "a USB-connected workstation simulator, resident fallback simulation, or physical hardware. Use tools/list "
                "and simulation_status to discover the laboratory as it exists now."
            ),
        ))

    if method == "tools/list":
        return rpc_ok(rid, cacheable(5000, "public", tools=registry.definitions()))

    if method == "tools/call":
        params = req.get("params", {})
        name = params.get("name")
        args = params.get("arguments") or {}
        try:
            result = registry.call(name, args)
        except KeyError:
            return rpc_error(rid, -32602, "Unknown tool", name)
        except Exception as exc:
            result = tool_fail("%s failed: %s" % (name, exc))
        return rpc_ok(rid, result)

    return rpc_error(rid, -32601, "Method not found", method)
