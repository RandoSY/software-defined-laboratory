"""Boot the resident SUPER laboratory.

v0.5 makes the separation of identities explicit:

    Pico W / SUPER core       = the laboratory endpoint
    Windows simulation host  = one replaceable source of physical state

The host may come and go.  The MCP identity and capability vocabulary remain
on the Pico.  That is why a simulated experiment can later cross into hardware
without changing the client-facing laboratory identity.
"""

import time
import wifi
import supervisor

from .capabilities import CapabilityManager
from .config import MCP_PORT, NODE_NAME, SERVER_VERSION
from .discovery import advertise
from .http_server import serve
from .lab import Lab
from .mcp import dispatch, register_core_tools
from .registry import ToolRegistry


def _wait_for_wifi(timeout_s=8):
    """Wait briefly for CircuitPython auto-connect, but never require Wi-Fi.

    v0.5 is deliberately USB-complete: a Pico W connected only by its USB
    cable must still be a useful SUPER node.  Wi-Fi therefore adds a network
    transport and mDNS advertisement; it is not a boot prerequisite.
    """
    start = time.monotonic()
    while wifi.radio.ipv4_address is None:
        if time.monotonic() - start > timeout_s:
            return False
        time.sleep(0.25)
    return True


def run():
    print("\nSUPER dynamic laboratory v0.5")
    supervisor.runtime.autoreload = False

    wifi_ready = _wait_for_wifi()
    ip = str(wifi.radio.ipv4_address) if wifi_ready else None
    print("Wi-Fi:", ip if ip else "not connected; USB-only mode available")

    lab = Lab(
        node_name=NODE_NAME,
        ip=ip,
        mcp_port=MCP_PORT,
        server_version=SERVER_VERSION,
        hostname=getattr(wifi.radio, "hostname", NODE_NAME),
    )
    lab.discovery_status = advertise(NODE_NAME) if wifi_ready else {"active": False, "reason": "Wi-Fi unavailable"}
    lab.host.set_node_info(mdnsActive=bool(lab.discovery_status.get("active")))
    print("Discovery:", lab.discovery_status)

    registry = ToolRegistry()
    register_core_tools(registry, lab)

    manager = CapabilityManager(registry, lab)
    report = manager.load_all()
    lab.capability_report = report

    # The USB bridge forwards MCP to the same dispatcher and registry used by
    # network HTTP.  There is one laboratory vocabulary, merely two transports.
    lab.host.set_mcp_handler(lambda request: dispatch(request, registry))

    print("Capabilities:", report)
    print("Tools:", registry.inventory())
    print("Simulation:", lab.simulation_status())

    serve(registry, lab)
