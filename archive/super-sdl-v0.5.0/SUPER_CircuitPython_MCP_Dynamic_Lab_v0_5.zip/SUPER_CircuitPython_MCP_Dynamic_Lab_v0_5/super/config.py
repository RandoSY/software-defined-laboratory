"""Constants for the resident SUPER core.

Infrastructure is intentionally kept separate from experiment packages.  v0.5
adds the workstation simulation transport, but an experiment such as Newton
cooling still does not know whether its temperature came from local math, a
Windows model, or future physical hardware.
"""

import os

MCP_PROTOCOL = "2026-07-28"
SERVER_NAME = "super-circuitpython-dynamic-lab"
SERVER_VERSION = "0.5.0"
NODE_NAME = os.getenv("SUPER_NODE_NAME", "super-bench-01")
MCP_PORT = 8000
MCP_PATH = "/mcp"
MAX_HEADER_BYTES = 6144
MAX_BODY_BYTES = 12288
SOCKET_TIMEOUT_S = 6
ACCEPT_POLL_S = 0.10

MCP_TOKEN = os.getenv("SUPER_MCP_TOKEN", "super-demo")
ALLOWED_ORIGIN = os.getenv("SUPER_ALLOWED_ORIGIN", "")

CAPABILITY_ROOT = "/capabilities"
CAPABILITY_API_VERSION = 1
