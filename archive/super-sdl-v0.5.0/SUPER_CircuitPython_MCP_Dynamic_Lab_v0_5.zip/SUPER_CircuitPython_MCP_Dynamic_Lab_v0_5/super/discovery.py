"""Network discovery for a SUPER MCP node.

USB discovery belongs to the Windows simulation host.  This module solves the
other half of the same usability rule: once a SUPER node is on Wi-Fi, MCP
clients should not hunt for an IP address.  The node advertises one mDNS
service, ``_super-mcp._tcp``, with enough TXT metadata to identify itself.
"""

try:
    import mdns
    import wifi
except ImportError:
    mdns = None
    wifi = None

from .config import MCP_PORT, SERVER_VERSION


_server = None


def advertise(node_name):
    global _server
    if mdns is None or wifi is None:
        return {"active": False, "reason": "mdns unavailable"}
    try:
        server = mdns.Server(wifi.radio)
        # hostname is the DNS-safe network name; instance_name is the friendly
        # service label clients display.
        safe = str(node_name).replace("_", "-").replace(" ", "-").lower()
        server.hostname = safe
        server.instance_name = str(node_name)
        server.advertise_service(
            service_type="_super-mcp",
            protocol="_tcp",
            port=MCP_PORT,
            txt_records=(
                "node=" + str(node_name),
                "version=" + SERVER_VERSION,
                "path=/mcp",
                "simulation=usb-host-or-local",
            ),
        )
        _server = server  # keep it alive for the process lifetime
        return {
            "active": True,
            "service": "_super-mcp._tcp",
            "hostname": safe + ".local",
            "port": MCP_PORT,
        }
    except Exception as exc:
        return {"active": False, "reason": str(exc)}
