#!/usr/bin/env python3
"""In-process integration proof for the SUPER v0.5 USB architecture.

This test does not require a physical Pico.  It connects the *real* Pico-side
HostSimLink class to the *real* Win32 NodeWorker through a pair of in-memory
serial endpoints, then sends MCP over the NodeWorker's real localhost HTTP
bridge.  It proves the critical protocol nesting:

    HTTP MCP client
      -> Win32 localhost bridge
      -> SUPER-SIM/1 USB frame
      -> resident Pico MCP dispatcher
      -> Lab reads Win32 sensor backend over the same USB channel
      -> result returns all the way to HTTP.

A physical run is still required to prove Windows USB enumeration and the Pico
USB stack, but this catches logic/deadlock/regression errors in the complete
software path.
"""

import json
import os
import queue
import sys
import threading
import time
import urllib.request
from types import SimpleNamespace

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from sim_host.server import ControlServer, NodeWorker
import desktop_discover
from super.hostlink import HostSimLink
from super.lab import Lab
from super.mcp import dispatch, register_core_tools
from super.registry import ToolRegistry

PROTO = "2026-07-28"
TOKEN = "super-demo"


class MemorySerial:
    """Small serial-like endpoint adequate for HostSimLink and NodeWorker."""

    def __init__(self, port):
        self.port = port
        self.timeout = 0.0
        self.write_timeout = 0.5
        self.connected = True
        self.peer = None
        self._buf = bytearray()
        self._cv = threading.Condition()
        self._closed = False

    def connect_peer(self, peer):
        self.peer = peer

    def write(self, data):
        if self._closed or self.peer is None:
            raise OSError("serial endpoint closed")
        raw = bytes(data)
        with self.peer._cv:
            self.peer._buf.extend(raw)
            self.peer._cv.notify_all()
        return len(raw)

    def flush(self):
        pass

    def reset_input_buffer(self):
        with self._cv:
            self._buf.clear()

    def read(self, size=1):
        deadline = None if self.timeout is None else time.monotonic() + float(self.timeout)
        with self._cv:
            while not self._buf and not self._closed:
                if self.timeout == 0:
                    return b""
                if deadline is None:
                    self._cv.wait(0.05)
                else:
                    remain = deadline - time.monotonic()
                    if remain <= 0:
                        return b""
                    self._cv.wait(min(0.05, remain))
            n = min(max(1, int(size)), len(self._buf))
            out = bytes(self._buf[:n])
            del self._buf[:n]
            return out

    def readline(self):
        deadline = None if self.timeout is None else time.monotonic() + float(self.timeout)
        with self._cv:
            while True:
                if 10 in self._buf:
                    i = self._buf.index(10) + 1
                    out = bytes(self._buf[:i])
                    del self._buf[:i]
                    return out
                if self._closed:
                    return b""
                if self.timeout == 0:
                    return b""
                if deadline is None:
                    self._cv.wait(0.05)
                else:
                    remain = deadline - time.monotonic()
                    if remain <= 0:
                        return b""
                    self._cv.wait(min(0.05, remain))

    def close(self):
        self._closed = True
        self.connected = False
        with self._cv:
            self._cv.notify_all()


def serial_pair():
    a = MemorySerial("PICO-DATA")
    b = MemorySerial("WIN32-DATA")
    a.connect_peer(b)
    b.connect_peer(a)
    return a, b


class NullMdns:
    def publish(self, hello):
        pass


class FakeCapabilityManagerState:
    pass


def meta():
    return {
        "io.modelcontextprotocol/protocolVersion": PROTO,
        "io.modelcontextprotocol/clientInfo": {"name": "usb-integration", "version": "0.5.0"},
        "io.modelcontextprotocol/clientCapabilities": {},
    }


def http_rpc(url, method, params=None, name=None):
    p = dict(params or {})
    p["_meta"] = meta()
    body = {"jsonrpc": "2.0", "id": int(time.time() * 1000000) & 0x7FFFFFFF, "method": method, "params": p}
    headers = {
        "Content-Type": "application/json",
        "Authorization": "Bearer " + TOKEN,
        "MCP-Protocol-Version": PROTO,
        "Mcp-Method": method,
    }
    if name:
        headers["Mcp-Name"] = name
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=5) as r:
        return json.loads(r.read().decode())


def tool(url, name, args=None):
    obj = http_rpc(url, "tools/call", {"name": name, "arguments": args or {}}, name=name)
    assert "error" not in obj, obj
    result = obj["result"]
    assert result.get("isError") is False, result
    return result.get("structuredContent")


def main():
    pico_port, win_port = serial_pair()

    # Pico-side runtime objects.  Lab normally constructs HostSimLink from
    # usb_cdc.data; for this software-only integration proof we inject our
    # in-memory endpoint while keeping the real HostSimLink implementation.
    lab = Lab(node_name="super-test-01", ip=None, mcp_port=8000, server_version="0.5.0")
    pico_link = HostSimLink({
        "node": "super-test-01", "serverVersion": "0.5.0", "ip": None,
        "mcpPort": 8000, "hostname": "super-test-01",
    })
    pico_link.port = pico_port
    lab.host = pico_link
    lab.capability_report = []

    registry = ToolRegistry()
    register_core_tools(registry, lab)
    pico_link.set_mcp_handler(lambda request: dispatch(request, registry))

    args = SimpleNamespace(
        record=None, replay=None, scenario="nominal", token=TOKEN,
        no_mdns=True, probe_timeout=0.2, scan_interval=0.1,
    )
    hello = {
        "protocol": "SUPER-SIM/1", "op": "hello", "node": "super-test-01",
        "serverVersion": "0.5.0", "ip": None, "mcpPort": 8000,
        "hostname": "super-test-01",
    }
    worker = NodeWorker(win_port, hello, args, NullMdns(), lambda port: None)
    worker.start()

    stop = threading.Event()

    def pico_service():
        while not stop.is_set():
            pico_link.service()
            time.sleep(0.001)

    pt = threading.Thread(target=pico_service, daemon=True)
    pt.start()

    deadline = time.monotonic() + 3.0
    while (worker.bridge is None or not pico_link.connected) and time.monotonic() < deadline:
        time.sleep(0.01)
    assert worker.bridge is not None, "localhost MCP bridge did not start"
    assert pico_link.connected, "SUPER-SIM/1 heartbeat did not establish host connection"

    url = "http://127.0.0.1:%d/mcp" % worker.bridge.port

    # Prove the zero-configuration desktop discovery path as well.  In the
    # production host this registry uses well-known port 8765; the test binds
    # an ephemeral port so it cannot conflict with a real local installation.
    class RegistryHost:
        def node_records(self):
            return [worker.discovery_record()]

    control = ControlServer(RegistryHost(), 0)
    control.start()
    desktop_discover.LOCAL_SIM_CONTROL = "http://127.0.0.1:%d/nodes" % control.port
    rows = desktop_discover.discover_local_sim_host(token=TOKEN, timeout=1.0)
    assert len(rows) == 1 and rows[0]["node"] == "super-test-01", rows

    discovered = http_rpc(url, "server/discover")
    assert PROTO in discovered["result"]["supportedVersions"], discovered

    status = tool(url, "simulation_status")
    assert status["activeBackend"] == "win32-sim" and status["connected"] is True, status

    temp = tool(url, "sensor_read", {"id": "temp1"})
    assert temp["backend"] == "win32-sim" and 0 < temp["temperatureC"] < 60, temp

    # Causal proof across the nested path: MCP changes the Pico's logical LED;
    # that output event crosses USB to the Win32 model and changes virtual light.
    tool(url, "output_set", {"output": "led", "value": False})
    dark = tool(url, "sensor_read", {"id": "light1"})["lux"]
    tool(url, "output_set", {"output": "led", "value": True})
    lit = tool(url, "sensor_read", {"id": "light1"})["lux"]
    assert lit > dark + 10.0, (dark, lit)

    tool(url, "simulation_scenario_set", {"name": "sensor_fault"})
    fault = tool(url, "sensor_read", {"id": "light1"})
    assert fault["status"] == "fault" and fault["value"] is None, fault
    tool(url, "simulation_scenario_set", {"name": "nominal"})

    wave = tool(url, "waveform_capture", {"samples": 96, "sampleRateHz": 2000})
    assert len(wave["samples"]) == 96 and wave["backend"] == "win32-sim", wave

    stop.set()
    worker.stop_event.set()
    worker.join(timeout=2)
    control.close()
    print("PASS: SUPER v0.5 USB + Win32 simulation + auto-discovery + localhost MCP bridge integration")


if __name__ == "__main__":
    main()
