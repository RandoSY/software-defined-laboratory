#!/usr/bin/env python3
"""Automatic SUPER discovery for desktop tools.

Normal use has no configured IP address and no configured COM port.

Discovery order:

1. Win32 simulation-host localhost registry (USB-only path).
2. ``_super-mcp._tcp.local.`` mDNS from Wi-Fi-connected SUPER nodes.
3. CircuitPython's own ``_circuitpython._tcp.local.`` advertisement, with the
   candidate verified by probing SUPER MCP on port 8000.
4. Direct USB SUPER-SIM/1 passive hello detection, useful when the simulation
   host is not running and the Pico's hello contains a reachable Wi-Fi address.

Every candidate is verified with ``server/discover`` before it is returned.
Manual addresses remain a diagnostic override in client programs, not the
normal workflow.
"""

import json
import os
import time
import urllib.request

PROTO = "2026-07-28"
SIM_PROTO = "SUPER-SIM/1"
LOCAL_SIM_CONTROL = "http://127.0.0.1:%d/nodes" % int(os.getenv("SUPER_SIM_CONTROL_PORT", "8765"))
PICO_CIRCUITPYTHON_VID = 0x2E8A
PICO_CIRCUITPYTHON_PID = 0x000B

try:
    from zeroconf import ServiceBrowser, ServiceListener, Zeroconf
except ImportError:
    ServiceBrowser = ServiceListener = Zeroconf = None

try:
    import serial
    from serial.tools import list_ports
except ImportError:
    serial = None
    list_ports = None


class _Listener(ServiceListener if ServiceListener is not None else object):
    def __init__(self, zc):
        self.zc = zc
        self.names = []

    def add_service(self, zc, type_, name):
        if name not in self.names:
            self.names.append(name)

    def update_service(self, zc, type_, name):
        self.add_service(zc, type_, name)

    def remove_service(self, zc, type_, name):
        pass


def _decode_props(props):
    out = {}
    for k, v in (props or {}).items():
        try:
            key = k.decode() if isinstance(k, bytes) else str(k)
            val = v.decode() if isinstance(v, bytes) else str(v)
            out[key] = val
        except Exception:
            pass
    return out


def _browse(service_type, timeout_s):
    if Zeroconf is None:
        return []
    zc = Zeroconf()
    listener = _Listener(zc)
    browser = ServiceBrowser(zc, service_type, listener)
    time.sleep(timeout_s)
    rows = []
    for name in list(listener.names):
        info = zc.get_service_info(service_type, name, timeout=500)
        if not info:
            continue
        for addr in info.parsed_addresses():
            rows.append({
                "source": "mdns", "service": service_type,
                "name": name, "host": addr, "port": info.port,
                "server": info.server, "properties": _decode_props(info.properties),
            })
    try:
        browser.cancel()
    except Exception:
        pass
    zc.close()
    return rows


def _mcp_probe(host, port=8000, token="super-demo", timeout=0.8):
    meta = {
        "io.modelcontextprotocol/protocolVersion": PROTO,
        "io.modelcontextprotocol/clientInfo": {"name": "super-discovery", "version": "0.5.0"},
        "io.modelcontextprotocol/clientCapabilities": {},
    }
    body = {"jsonrpc": "2.0", "id": 1, "method": "server/discover", "params": {"_meta": meta}}
    headers = {
        "Content-Type": "application/json", "Accept": "application/json",
        "Authorization": "Bearer " + token, "MCP-Protocol-Version": PROTO,
        "Mcp-Method": "server/discover",
    }
    req = urllib.request.Request(
        "http://%s:%d/mcp" % (host, port), data=json.dumps(body).encode(),
        headers=headers, method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            obj = json.loads(r.read().decode())
        return PROTO in obj.get("result", {}).get("supportedVersions", [])
    except Exception:
        return False


def discover_local_sim_host(token="super-demo", timeout=0.45):
    """Discover attached Pico nodes through the running Win32 simulation host."""
    try:
        with urllib.request.urlopen(LOCAL_SIM_CONTROL, timeout=timeout) as r:
            obj = json.loads(r.read().decode("utf-8"))
    except Exception:
        return []
    found = []
    for row in obj.get("nodes", []):
        try:
            host = row.get("host") or "127.0.0.1"
            port = int(row.get("port"))
        except Exception:
            continue
        if _mcp_probe(host, port, token=token, timeout=timeout):
            item = dict(row)
            item["source"] = "usb-bridge"
            item["host"] = host
            item["port"] = port
            found.append(item)
    return found


def discover_mdns(timeout_s=1.2, token="super-demo"):
    found = []
    seen = set()
    for row in _browse("_super-mcp._tcp.local.", timeout_s):
        key = (row["host"], int(row["port"]))
        if key in seen:
            continue
        if _mcp_probe(*key, token=token):
            row["node"] = row["properties"].get("node") or row["name"].split(".", 1)[0]
            found.append(row)
            seen.add(key)

    if not found:
        for row in _browse("_circuitpython._tcp.local.", timeout_s):
            key = (row["host"], 8000)
            if key in seen:
                continue
            if _mcp_probe(key[0], key[1], token=token):
                row["port"] = 8000
                row["node"] = row["properties"].get("name") or row["name"].split(".", 1)[0]
                found.append(row)
                seen.add(key)
    return found


def _looks_like_circuitpython_port(p, probe_all=False):
    if probe_all:
        return True
    if getattr(p, "vid", None) == PICO_CIRCUITPYTHON_VID and getattr(p, "pid", None) == PICO_CIRCUITPYTHON_PID:
        return True
    text = " ".join(str(x or "") for x in (
        getattr(p, "product", None), getattr(p, "description", None), getattr(p, "manufacturer", None)
    )).lower()
    return "circuitpython" in text


def discover_usb(timeout_s=0.90, probe_all=False):
    """Passively identify the SUPER data CDC when sim_host is not running."""
    if serial is None:
        return []
    found = []
    for p in list_ports.comports():
        if not _looks_like_circuitpython_port(p, probe_all):
            continue
        ser = None
        try:
            ser = serial.Serial(p.device, 115200, timeout=0.10, write_timeout=0.3)
            ser.reset_input_buffer()
            # No probe is written: both Pico CDC ports share the same USB identity,
            # and writing JSON into the console would interfere with the REPL.
            deadline = time.monotonic() + timeout_s
            while time.monotonic() < deadline:
                raw = ser.readline()
                if not raw:
                    continue
                try:
                    msg = json.loads(raw.decode())
                except Exception:
                    continue
                if msg.get("protocol") == SIM_PROTO and msg.get("op") == "hello":
                    found.append({
                        "source": "usb", "portName": p.device,
                        "node": msg.get("node"), "host": msg.get("ip"),
                        "port": int(msg.get("mcpPort", 8000)), "hello": msg,
                    })
                    break
        except Exception:
            pass
        finally:
            if ser is not None:
                try:
                    ser.close()
                except Exception:
                    pass
    return found


def discover_super(timeout_s=1.2, token="super-demo", probe_all=False):
    rows = discover_local_sim_host(token=token, timeout=min(timeout_s, 0.6))
    if rows:
        return rows
    rows = discover_mdns(timeout_s, token=token)
    if rows:
        return rows
    candidates = discover_usb(timeout_s=min(max(timeout_s, 0.9), 1.2), probe_all=probe_all)
    return [
        r for r in candidates
        if r.get("host") not in (None, "None", "0.0.0.0")
        and _mcp_probe(r["host"], r["port"], token=token)
    ]


def main():
    rows = discover_super()
    if not rows:
        print("No SUPER nodes discovered.")
        return 1
    for r in rows:
        print("%-18s %-15s:%-5s via %s" % (
            r.get("node", "?"), r.get("host", "?"), r.get("port", 8000), r.get("source", "?")))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
