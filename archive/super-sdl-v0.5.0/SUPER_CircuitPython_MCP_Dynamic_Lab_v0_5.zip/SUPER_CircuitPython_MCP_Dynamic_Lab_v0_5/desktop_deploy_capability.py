#!/usr/bin/env python3
"""Transactional capability deployment using CircuitPython Web Workflow.

This script is deliberately more cautious than a simple file copier because
SUPER's interesting claim is not "Python files can be sent over Wi-Fi."  The
claim is that a laboratory can acquire a new experimental personality *late*,
and that this can be made routine enough to trust in an educational setting.

The v0.5 install path therefore has two transactions, one on each side of the
reboot boundary:

DESKTOP / FILESYSTEM TRANSACTION

    local package
        -> static preflight (manifest + Python syntax)
        -> /staging/<name>.next/       # inert namespace
        -> read every uploaded byte back
        -> write READY last
        -> preserve previous active package
        -> MOVE staging directory into /capabilities

DEVICE / SEMANTIC TRANSACTION

    clean reload
        -> resident core validates manifest/dependencies
        -> capability registers into private in-memory registry
        -> manifest `provides` must match staged vocabulary
        -> commit all tools at once
        -> tools/list exposes the complete new capability

Finally the deployer asks the rebooted node whether the capability is actually
active.  A transfer is not considered successful merely because bytes arrived.
The laboratory itself must confirm that the new experimental vocabulary was
accepted.

CircuitPython Web Workflow is transport, not the conceptual heart of SUPER.
It gives us an already-maintained HTTP file API, mDNS identity, directory MOVE,
and explicit filesystem writability.  SUPER adds the experimental meaning.

SECURITY NOTE
-------------
This is a trusted-LAN educational mechanism.  CircuitPython Web Workflow Basic
Auth normally travels over unencrypted HTTP, and CircuitPython is not a sandbox.
Do not use this design to execute arbitrary Internet-sourced code.
"""

import argparse
import base64
import json
import os
import time
import urllib.error
import urllib.request

PROTO = "2026-07-28"
CLIENT_VERSION = "0.5.0"


class CapabilityRejected(RuntimeError):
    """The rebooted SUPER core explicitly rejected the new package."""


def auth_header(password):
    return "Basic " + base64.b64encode((":" + password).encode()).decode()


class WebFS:
    """Tiny client for the documented CircuitPython Web Workflow REST API."""

    def __init__(self, host, password):
        self.base = "http://%s" % host
        self.auth = auth_header(password)

    def request(self, path, method="GET", data=None, headers=None, expect=(200, 201, 204)):
        h = {"Authorization": self.auth}
        h.update(headers or {})
        req = urllib.request.Request(self.base + path, data=data, headers=h, method=method)
        try:
            with urllib.request.urlopen(req, timeout=12) as r:
                body = r.read()
                if r.status not in expect:
                    raise RuntimeError("unexpected HTTP %s" % r.status)
                return r.status, body
        except urllib.error.HTTPError as exc:
            body = exc.read().decode(errors="replace")
            if exc.code == 409:
                raise RuntimeError(
                    "CircuitPython filesystem is not writable through Web Workflow. "
                    "A common cause is the USB CIRCUITPY drive being actively claimed "
                    "by the host. Eject/unmount it, keep USB power connected if desired, "
                    "then retry. Server said: %s" % body
                )
            raise RuntimeError("HTTP %d %s: %s" % (exc.code, path, body))

    def get_json(self, path, authenticated=True):
        headers = {"Accept": "application/json"}
        if authenticated:
            return json.loads(self.request(path, headers=headers, expect=(200,))[1].decode())
        req = urllib.request.Request(self.base + path, headers=headers, method="GET")
        with urllib.request.urlopen(req, timeout=12) as r:
            return json.loads(r.read().decode())

    def preflight(self):
        """Confirm we are talking to CircuitPython and that its disk is writable."""
        version = self.get_json("/cp/version.json", authenticated=False)
        disks = self.get_json("/cp/diskinfo.json", authenticated=False)
        root = None
        for disk in disks:
            if disk.get("root") == "/":
                root = disk
                break
        if root is None:
            raise RuntimeError("CircuitPython did not report its root filesystem")
        if not root.get("writable"):
            raise RuntimeError(
                "CircuitPython reports / as not writable by Web Workflow. "
                "Eject/unmount CIRCUITPY from the desktop host before deployment."
            )
        print(
            "Web Workflow: CircuitPython %s on %s; API v%s; filesystem writable"
            % (version.get("version", "?"), version.get("board_name", "?"), version.get("web_api_version", "?"))
        )
        return version

    def exists_dir(self, path):
        try:
            self.request("/fs" + _dir(path), headers={"Accept": "application/json"})
            return True
        except RuntimeError as exc:
            if "HTTP 404" in str(exc):
                return False
            raise

    def mkdir(self, path):
        self.request("/fs" + _dir(path), method="PUT", data=b"", expect=(201, 204))

    def put_file(self, path, data):
        self.request("/fs" + path, method="PUT", data=data, expect=(201, 204))

    def get_file(self, path):
        return self.request("/fs" + path, method="GET", expect=(200,))[1]

    def delete_dir(self, path):
        self.request("/fs" + _dir(path), method="DELETE", expect=(204,))

    def move_dir(self, src, dst):
        src = _dir(src)
        dst = _dir(dst)
        self.request(
            "/fs" + src,
            method="MOVE",
            headers={"X-Destination": "/fs" + dst},
            expect=(201,),
        )


def _dir(path):
    return path if path.endswith("/") else path + "/"


def _mcp_meta():
    return {
        "io.modelcontextprotocol/protocolVersion": PROTO,
        "io.modelcontextprotocol/clientInfo": {
            "name": "super-capability-deployer",
            "version": CLIENT_VERSION,
        },
        "io.modelcontextprotocol/clientCapabilities": {},
    }


def mcp_rpc(host, port, token, method, params=None, name=None, timeout=8):
    p = dict(params or {})
    p["_meta"] = _mcp_meta()
    body = {"jsonrpc": "2.0", "id": 1, "method": method, "params": p}
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "Authorization": "Bearer " + token,
        "MCP-Protocol-Version": PROTO,
        "Mcp-Method": method,
    }
    if name:
        headers["Mcp-Name"] = name
    url = "http://%s:%d/mcp" % (host, port)
    req = urllib.request.Request(url, data=json.dumps(body).encode(), headers=headers, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as r:
        obj = json.loads(r.read().decode())
    if "error" in obj:
        raise RuntimeError("MCP %s failed: %r" % (method, obj["error"]))
    return obj.get("result", {})


def mcp_tool(host, port, token, name, args=None, timeout=8):
    result = mcp_rpc(
        host, port, token, "tools/call",
        {"name": name, "arguments": args or {}},
        name=name, timeout=timeout,
    )
    if result.get("isError"):
        raise RuntimeError("MCP tool %s reported error: %r" % (name, result))
    return result.get("structuredContent")


def mcp_reload(host, port, token):
    data = mcp_tool(host, port, token, "system_reload")
    if not data or not data.get("reloadScheduled"):
        raise RuntimeError("reload request was not acknowledged")


def wait_for_capability(host, port, token, package, expected_tools, timeout_s=20):
    """Wait through the reload and ask the *laboratory* whether install succeeded."""
    deadline = time.time() + timeout_s
    last_error = None
    while time.time() < deadline:
        try:
            data = mcp_tool(host, port, token, "capability_list", timeout=3)
            packages = data.get("packages", []) if data else []
            item = next((p for p in packages if p.get("package") == package), None)
            tool_names = {t.get("name") for t in (data.get("tools", []) if data else [])}
            if item and item.get("status") == "active" and set(expected_tools).issubset(tool_names):
                return item
            if item and item.get("status") == "error":
                raise CapabilityRejected(
                    "device rejected capability: %s" % item.get("message", "unknown error")
                )
            last_error = RuntimeError("capability not active yet")
        except CapabilityRejected:
            # A declared semantic rejection will not heal by polling.  Fail now
            # so rollback can begin immediately.
            raise
        except Exception as exc:
            last_error = exc
        time.sleep(0.5)
    raise RuntimeError("post-reload capability health check failed: %s" % last_error)


def _validate_local_manifest(package_dir, raw_manifest):
    try:
        manifest = json.loads(raw_manifest.decode())
    except Exception as exc:
        raise RuntimeError("manifest.json is not valid JSON: %s" % exc)
    package = manifest.get("id")
    local_name = os.path.basename(os.path.abspath(package_dir))
    if not package or package != local_name:
        raise RuntimeError("manifest id must equal local directory name")
    if manifest.get("apiVersion") != 1:
        raise RuntimeError("this deployer expects capability apiVersion 1")
    provides = manifest.get("provides")
    if not isinstance(provides, list) or not provides or not all(isinstance(x, str) and x for x in provides):
        raise RuntimeError("manifest provides must be a non-empty list of tool names")
    if len(set(provides)) != len(provides):
        raise RuntimeError("manifest provides contains duplicate tool names")
    return package, manifest


def local_tree(package_dir):
    """Collect a capability recursively and perform inexpensive static checks.

    v0.3 copied only top-level files.  That was enough for one demo but not a
    truly extensible package system: real experiments will want helper modules,
    calibration data, perhaps small HTML assets, and nested data directories.
    v0.5 therefore preserves the entire package tree.
    """
    package_dir = os.path.abspath(package_dir)
    files = {}
    dirs = set()

    for root, dirnames, filenames in os.walk(package_dir):
        # Hidden folders and Python caches are desktop artifacts, not part of an
        # experiment personality.
        dirnames[:] = [d for d in dirnames if not d.startswith(".") and d != "__pycache__"]
        rel_root = os.path.relpath(root, package_dir)
        if rel_root != ".":
            dirs.add(rel_root.replace(os.sep, "/"))
        for filename in filenames:
            if filename == "READY" or filename.startswith(".") or filename.endswith(".pyc"):
                continue
            full = os.path.join(root, filename)
            rel = os.path.relpath(full, package_dir).replace(os.sep, "/")
            with open(full, "rb") as f:
                data = f.read()
            files[rel] = data
            if filename.endswith(".py"):
                try:
                    compile(data.decode("utf-8"), rel, "exec")
                except Exception as exc:
                    raise RuntimeError("Python syntax check failed for %s: %s" % (rel, exc))

    required = {"manifest.json", "module.py", "__init__.py"}
    missing = required - set(files)
    if missing:
        raise RuntimeError("package missing files: %r" % missing)

    package, manifest = _validate_local_manifest(package_dir, files["manifest.json"])
    return package, manifest, sorted(dirs), files


def ensure_remote_dirs(fs, root, relative_dirs):
    """Create nested directories in parent-first order."""
    for rel in sorted(relative_dirs, key=lambda p: (p.count("/"), p)):
        current = root.rstrip("/") + "/" + rel + "/"
        if not fs.exists_dir(current):
            fs.mkdir(current)


def _preserve_failed_active(fs, package):
    active = "/capabilities/%s/" % package
    failed = "/staging/%s.failed/" % package
    if fs.exists_dir(failed):
        fs.delete_dir(failed)
    if fs.exists_dir(active):
        fs.move_dir(active, failed)
    return failed


def _restore_backup(fs, package):
    active = "/capabilities/%s/" % package
    backup = "/rollback/%s.prev/" % package
    if fs.exists_dir(active):
        _preserve_failed_active(fs, package)
    if fs.exists_dir(backup):
        fs.move_dir(backup, active)
        return True
    return False


def install(args):
    package, manifest, dirs, files = local_tree(args.package_dir)
    expected_tools = manifest["provides"]
    print("Local preflight: %s %s; %d files; provides %s" % (
        package, manifest.get("version", "?"), len(files), ", ".join(expected_tools)
    ))

    fs = WebFS(args.host, args.web_password)
    fs.preflight()

    # Stable top-level namespaces.  Staging is intentionally not imported.
    for root in ("/staging/", "/capabilities/", "/rollback/"):
        if not fs.exists_dir(root):
            fs.mkdir(root)

    stage = "/staging/%s.next/" % package
    active = "/capabilities/%s/" % package
    backup = "/rollback/%s.prev/" % package

    if fs.exists_dir(stage):
        fs.delete_dir(stage)
    fs.mkdir(stage)
    ensure_remote_dirs(fs, stage, dirs)

    print("Uploading into inert staging namespace:", stage)
    for name in sorted(files):
        fs.put_file(stage + name, files[name])

    print("Reading every uploaded byte back before activation...")
    for name in sorted(files):
        remote = fs.get_file(stage + name)
        if remote != files[name]:
            raise RuntimeError("verification failed for " + name)

    # READY comes last.  This is intentionally redundant with /staging: even
    # an accidentally moved package is ignored until transfer declares it whole.
    fs.put_file(stage + "READY", b"ready\n")

    if fs.exists_dir(backup):
        fs.delete_dir(backup)
    had_previous = fs.exists_dir(active)
    if had_previous:
        print("Preserving previous active package as rollback copy")
        fs.move_dir(active, backup)

    print("Activating with one directory MOVE")
    try:
        fs.move_dir(stage, active)
    except Exception:
        # If the commit MOVE itself fails after we preserved the old version,
        # restore the old directory immediately.  A deployment failure should
        # not unnecessarily erase yesterday's working laboratory.
        if had_previous and fs.exists_dir(backup) and not fs.exists_dir(active):
            fs.move_dir(backup, active)
        raise

    try:
        print("Requesting clean SUPER reload")
        mcp_reload(args.host, args.mcp_port, args.mcp_token)
        print("Waiting for the laboratory to boot and accept the capability...")
        item = wait_for_capability(
            args.host, args.mcp_port, args.mcp_token,
            package, expected_tools, timeout_s=args.health_timeout,
        )
        print("ACTIVE: %s %s -- %s" % (package, item.get("version", "?"), item.get("message", "")))
        print("The install is complete because MCP now advertises the promised vocabulary.")
    except Exception as exc:
        if args.no_auto_rollback:
            raise
        print("New capability failed semantic health check:", exc)
        print("Attempting filesystem rollback...")
        restored = _restore_backup(fs, package)
        if restored:
            print("Previous package restored on disk.")
        else:
            print("No previous package existed; failed package was removed from active namespace.")
        # If the permanent core is still responsive, make the rollback live now.
        # If a trusted package hung during import, MCP may be unavailable; the
        # files are still repaired but a physical reset/power-cycle is needed.
        try:
            mcp_reload(args.host, args.mcp_port, args.mcp_token)
            print("Rollback reload requested.")
        except Exception as reload_exc:
            print("WARNING: core did not accept rollback reload: %s" % reload_exc)
            print("Filesystem is repaired; reset/power-cycle the Pico W to boot the restored state.")
        raise RuntimeError("deployment rejected and rolled back: %s" % exc)


def rollback(args):
    package = os.path.basename(os.path.abspath(args.package_dir))
    fs = WebFS(args.host, args.web_password)
    fs.preflight()
    backup = "/rollback/%s.prev/" % package

    if not fs.exists_dir(backup):
        raise RuntimeError("no rollback copy exists for " + package)
    _restore_backup(fs, package)
    try:
        mcp_reload(args.host, args.mcp_port, args.mcp_token)
    except Exception as exc:
        print("Filesystem rollback completed, but automatic reload failed: %s" % exc)
        print("Reset/power-cycle the Pico W to boot the restored package.")
        return
    print("Rolled back %s and requested reload." % package)


def main():
    p = argparse.ArgumentParser(description="Install or roll back a SUPER experiment capability")
    p.add_argument("command", choices=["install", "rollback"])
    p.add_argument("package_dir", help="local package directory; basename is package id")
    p.add_argument("--host", required=True, help="e.g. cpy-123456.local or 192.168.1.72")
    p.add_argument("--web-password", required=True)
    p.add_argument("--mcp-token", default="super-demo")
    p.add_argument("--mcp-port", type=int, default=8000)
    p.add_argument("--health-timeout", type=float, default=20.0)
    p.add_argument("--no-auto-rollback", action="store_true")
    args = p.parse_args()
    if args.command == "install":
        install(args)
    else:
        rollback(args)


if __name__ == "__main__":
    main()
