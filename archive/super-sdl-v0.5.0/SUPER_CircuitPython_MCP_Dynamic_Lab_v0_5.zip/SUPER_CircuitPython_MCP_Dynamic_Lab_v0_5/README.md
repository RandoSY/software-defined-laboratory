# SUPER CircuitPython MCP Dynamic Laboratory — v0.5 Full Simulation Host

> **A real Pico W, one USB cable, a Windows Python simulation host, automatic discovery, and the same MCP laboratory interface that will later face real hardware.**

SUPER v0.5 turns the v0.4 dynamic-capability seed into a complete *software development laboratory*.  The Raspberry Pi Pico W remains the authoritative SUPER node: it owns the MCP registry, capability packages, logical sensor identities, outputs, and experiment semantics.  A Windows Python process may attach over a dedicated USB CDC data channel and supply physically plausible simulated sensor state.

The central invariant is:

> **Simulation changes the source of physical state.  It does not change the identity of the laboratory.**

`temp1` is still `temp1` whether its value comes from the Win32 model, the small resident fallback simulator, a replay file, or a future DS18B20 driver.

---

## 1. What v0.5 adds

v0.4 established the resident SUPER core, transactional capability loading, MCP vocabulary, staged deployment, and the Newton Cooling capability.  v0.5 adds the missing full-simulation path:

- a Windows/CPython simulation host;
- automatic USB discovery with **no configured COM port**;
- a dedicated second CircuitPython CDC data interface, separate from the REPL;
- a human-readable `SUPER-SIM/1` JSON-lines protocol;
- realistic multi-sensor models for temperature, BME280 environment, BH1750 light, ADC, potentiometer, and accelerometer;
- causal coupling between outputs and observations;
- named simulation scenarios and fault injection;
- JSONL record/replay for sensor reads and waveform captures;
- one independent simulation world per attached SUPER node;
- a localhost MCP bridge for every USB-attached Pico;
- a well-known local discovery registry at `127.0.0.1:8765/nodes`;
- mDNS discovery for network-attached nodes;
- resident local-simulation fallback if the Windows host disappears;
- acceptance tests for both the semantic model and the nested USB/MCP path.

Most importantly, **Wi-Fi is optional for ordinary simulation and MCP use**.  A Pico W connected only by USB can remain a complete SUPER endpoint through the Windows localhost bridge.

Wi-Fi is still useful for direct network MCP, mDNS, and CircuitPython Web Workflow deployment.

---

## 2. The architecture

```text
                   MCP client / AI / test program
                              |
                    automatic discovery
                              |
             +----------------+----------------+
             |                                 |
        Wi-Fi / mDNS                       USB-only path
             |                                 |
      http://PICO:8000/mcp          http://127.0.0.1:<port>/mcp
             |                                 |
             |                      Windows localhost MCP bridge
             |                                 |
             +----------------+----------------+
                              |
                    Pico W resident SUPER core
                              |
                  stable Lab abstraction
                              |
              +---------------+----------------+
              |                                |
      real hardware later               SUPER-SIM/1 USB CDC
                                               |
                                      Windows Python host
                                               |
                                  causal simulation world
```

There is only **one** MCP vocabulary.  The localhost bridge does not duplicate or emulate the Pico's MCP server.  It forwards JSON-RPC over USB to the Pico's resident dispatcher.  Deposited capabilities therefore appear identically over Wi-Fi and USB.

---

## 3. Why a real Pico remains in the loop

It would be easy to simulate everything on Windows and omit the microcontroller.  SUPER deliberately does not do that.

The real Pico provides:

- the persistent laboratory identity;
- the actual CircuitPython execution environment;
- the real capability loader and tool registry;
- a real deployment target;
- the same endpoint that will later own physical sensors and actuators;
- continuity between simulated, hybrid, and physical experiments.

The Windows process is a replaceable backend, not the laboratory itself.

That is why this progression does not require a conceptual rewrite:

```text
WIN32 simulated temp1
        ->
hybrid temp1 + real output
        ->
physical DS18B20 temp1
```

The experiment still asks the same logical question: `lab.read_sensor("temp1")`.

---

## 4. USB personality

`boot.py` enables two CDC interfaces:

```text
usb_cdc.console   normal CircuitPython REPL
usb_cdc.data      dedicated SUPER-SIM/1 machine channel
```

HID and MIDI are disabled to conserve USB endpoints.  CIRCUITPY mass storage remains available.

CircuitPython documents the second `usb_cdc.data` interface specifically for host/device data transfer.  On Windows, the two CDC devices appear as separate COM ports, but SUPER does **not** assume which COM number is which.  The host probes candidate CircuitPython ports and accepts only a valid `SUPER-SIM/1` hello.

---

## 5. Automatic discovery is mandatory

The normal workflow contains no IP address and no COM port configuration.

Desktop discovery is attempted in this order:

1. **Local simulation-host registry** — `http://127.0.0.1:8765/nodes`.  This is the normal one-cable USB path because the simulation host already owns the data COM port.
2. **SUPER mDNS** — `_super-mcp._tcp.local.` for Wi-Fi nodes.
3. **CircuitPython Web Workflow mDNS** — `_circuitpython._tcp.local.`, with the candidate verified by MCP on port 8000.
4. **Direct USB probe** — useful when the simulator is not running and the Pico hello contains a reachable network address.

Every candidate is verified by a real MCP `server/discover` request before it is returned to a client.

Run:

```bat
py desktop_discover.py
```

A typical USB-only result is conceptually:

```text
super-bench-01     127.0.0.1:38185 via usb-bridge
```

The bridge port is intentionally dynamic.  The discovery registry knows it; the user does not need to.

---

## 6. Simulation is causal, not decorative

The simulator is intended to support experiments, not merely fill dashboards with random numbers.

### Sensor roles

| ID | Model personality | Meaning |
|---|---|---|
| `temp1` | DS18B20 | primary temperature |
| `env1` | BME280 | temperature, humidity, pressure |
| `light1` | BH1750 | illuminance |
| `adc1` | SUPER-ADC | analog voltage |
| `pot1` | 10 kΩ potentiometer | position |
| `accel1` | MPU6050 | 3-axis acceleration |

### Causal examples

`pwm_duty_pct` is treated as an abstract heater stimulus.  Raising duty moves the simulated temperature toward a higher equilibrium through a first-order thermal model rather than changing it instantaneously.

The logical Pico LED contributes measurable light to the virtual BH1750.  This gives the acceptance test a cross-boundary causal proof:

```text
MCP output_set(led=False)
        -> real Pico output state
        -> SUPER-SIM/1 output event
        -> Win32 optical model
        -> light1 decreases

MCP output_set(led=True)
        -> same path
        -> light1 increases
```

Environmental temperature, humidity, and pressure vary slowly and plausibly.  ADC and accelerometer streams contain controlled dynamics and noise.  The intent is not metrology-grade physical simulation; it is realistic, controllable experimental behavior suitable for software development, teaching, AI reasoning, and regression testing.

---

## 7. Scenarios and faults

Built-in scenarios:

- `nominal`
- `warm_room`
- `bright_sun`
- `noisy_bench`
- `sensor_fault`

Through MCP:

```text
simulation_scenario_list
simulation_scenario_set
simulation_status
```

The `sensor_fault` scenario deliberately disconnects `light1`, allowing clients and AI procedures to practice failure handling without physically unplugging anything.

---

## 8. Record and replay

Start the host while recording:

```bat
py -m sim_host.server --record session.jsonl
```

The trace stores sensor-read results, output events, scenario changes, and waveform captures.

Replay later:

```bat
py -m sim_host.server --replay session.jsonl
```

Replay lets a client, dashboard, test harness, or AI encounter a previously captured laboratory session repeatedly.  v0.5 replay is intentionally conservative: sensor observations and recorded waveform captures are reproduced; output commands are accepted but do not rewrite recorded history.

---

## 9. Resident fallback simulator

The Pico also retains the small simulator inherited from earlier versions.

If the Windows host is lost:

```text
activeBackend = local-sim
```

When the host reconnects automatically:

```text
activeBackend = win32-sim
```

The sensor IDs do not change.  That fallback is intentionally simpler than the Win32 world; its purpose is continuity and diagnostics, not parity with the richer workstation model.

---

## 10. Dynamic capability architecture remains intact

The simulation host does not replace the v0.4 dynamic laboratory architecture.

Experiment packages still live under:

```text
/capabilities/<package>/
    READY
    manifest.json
    module.py
```

Each package provides:

```python
def register(registry, lab):
    ...
```

`lab` points down toward stable physical/virtual roles.  `registry` points up toward AI-visible MCP vocabulary.

The Newton Cooling capability is still the reference example.  In `sensor` mode it consumes `temp1`; it does not know or care whether `temp1` is supplied by Windows simulation, resident fallback, replay, or future hardware.

Transactional registration remains all-or-nothing: a broken capability cannot expose half its promised vocabulary.

---

## 11. Project layout

```text
boot.py                         configure dedicated USB CDC data channel
code.py                         tiny permanent entry point
settings_example.toml           optional Wi-Fi/Web Workflow + MCP settings

super/                          resident Pico laboratory substrate
    core.py                     boot/runtime assembly
    config.py                   constants
    lab.py                      stable logical laboratory abstraction
    hostlink.py                 Pico side of SUPER-SIM/1 USB protocol
    discovery.py                Pico-side mDNS advertisement
    registry.py                 transactional MCP tool registry
    capabilities.py             package validation/loading
    mcp.py                      MCP semantics and core tools
    http_server.py              direct Wi-Fi MCP transport

sim_host/                       CPython / Windows side
    models.py                   causal simulation, scenarios, record/replay
    server.py                   USB discovery, workers, local MCP bridges,
                                local discovery registry

capabilities/
    newton_cooling/             reference deposited experiment capability

examples/
    capability_template/        minimal extension template

desktop_discover.py             zero-configuration node discovery
desktop_mcp_test.py             physical end-to-end acceptance test
desktop_selftest.py             semantic regression suite
desktop_usb_integration_test.py full software USB/MCP integration proof
desktop_deploy_capability.py    Web Workflow capability deployer
requirements-desktop.txt        pyserial + zeroconf
```

---

## 12. Quick start — USB-only full simulation

### A. Prepare the Pico W

Install a current CircuitPython build for Raspberry Pi Pico W.

Copy to `CIRCUITPY`:

```text
boot.py
code.py
super/
capabilities/
```

Wi-Fi credentials are **not required** for the USB-only simulation path.

Reset the board after installing `boot.py` so the USB descriptor is rebuilt with the second CDC interface.

### B. Prepare Windows

From this project directory:

```bat
py -m pip install -r requirements-desktop.txt
```

Start the simulation host:

```bat
py -m sim_host.server
```

Expected behavior:

```text
SUPER v0.5 Win32 Simulation Host
USB discovery : passive + Pico CircuitPython filtered; no COM port configuration
MCP discovery : http://127.0.0.1:8765/nodes
...
CONNECTED super-bench-01  COMx  USB-MCP=http://127.0.0.1:<dynamic>/mcp
```

### C. Prove discovery

In another terminal:

```bat
py desktop_discover.py
```

### D. Run the complete acceptance test

```bat
py desktop_mcp_test.py
```

No `--host` should be necessary.

---

## 13. Optional Wi-Fi configuration

Copy `settings_example.toml` to `CIRCUITPY/settings.toml` and fill in credentials if you want:

- direct MCP at `http://<pico>:8000/mcp`;
- `_super-mcp._tcp` mDNS advertisement;
- CircuitPython Web Workflow;
- network capability deployment with `desktop_deploy_capability.py`.

USB simulation remains available at the same time.

---

## 14. Desktop tests

Run both tests before changing the architecture:

```bat
py desktop_selftest.py
py desktop_usb_integration_test.py
```

`desktop_selftest.py` covers:

- transactional tool registration;
- no partial vocabulary on failure;
- local simulator validation;
- causal Win32 models;
- backend substitution while logical sensor identity remains stable;
- USB port filtering;
- Pico USB MCP dispatch seam;
- loopback MCP proxy semantics;
- manifest/tool mismatch rejection;
- missing dependency rejection;
- package-ID validation;
- Newton Cooling behavior.

`desktop_usb_integration_test.py` is more important architecturally.  It connects the real Pico-side link class to the real Win32 worker through an in-memory serial pair, starts a real localhost HTTP MCP bridge, verifies automatic local discovery, and drives sensor/output/scenario/waveform MCP calls through the entire nested protocol path.

It does **not** prove physical USB enumeration.  The physical Pico acceptance test is still required.

---

## 15. What “full simulation” means in v0.5

v0.5 supports a complete software development loop with a real Pico endpoint and a workstation-generated virtual physical world:

- multiple sensors;
- coherent units and ranges;
- causal dynamics;
- noise;
- named environments;
- fault injection;
- waveform generation;
- output-to-sensor coupling;
- record/replay;
- multiple attached nodes;
- automatic discovery;
- MCP access over USB even without Wi-Fi;
- fallback when the host disappears.

It does **not** claim that these simplified models are high-fidelity scientific digital twins.  “Full” here means the laboratory software stack can be exercised end-to-end without requiring the eventual physical sensor suite.

---

## 16. Deployment and simulation are separate transports

This distinction is deliberate.

### Simulation/runtime transport

```text
SUPER-SIM/1 over usb_cdc.data
```

Moves simulated physical state and, in USB-only mode, forwards MCP requests.

### Capability file deployment

The existing automated deployer uses CircuitPython **Web Workflow** over Wi-Fi because it already provides authenticated file operations and filesystem state reporting.

When working USB-only, capability files may also be copied directly to the visible CIRCUITPY drive during development.  v0.5 does not pretend that the USB simulation protocol is also a general remote filesystem protocol.

Keeping these jobs separate makes each easier to reason about.

---

## 17. Reliability model

SUPER repeatedly uses the same pattern:

```text
prepare -> validate -> commit -> verify -> rollback if needed
```

For capability bytes:

```text
/staging -> byte verification -> READY -> MOVE -> active
```

For MCP vocabulary:

```text
private transaction -> schema/name checks -> manifest agreement -> commit
```

For simulation attachment:

```text
probe candidate COM -> require SUPER hello -> heartbeat -> connected window
```

For desktop discovery:

```text
candidate -> real server/discover MCP probe -> accept
```

The philosophy is that *presence* is not the same as *validity*.

---

## 18. Security boundary

v0.5 is a trusted-bench educational/reference system.

Important limitations:

- MCP and Web Workflow are normally plain HTTP on the local network;
- the localhost USB bridge uses a bearer token but is not intended as hostile multi-user isolation;
- deposited Python capabilities are trusted code, not sandboxed plugins;
- a malicious capability can do anything ordinary CircuitPython code can do;
- do not expose this reference implementation directly to an untrusted network.

---

## 19. The larger idea

CRCL began with replaceable application behavior.

SUPER extends that into a laboratory whose experimental abilities can be supplied after the hardware is already deployed:

```text
CRCL
replaceable behavior
       |
       v
SUPER resident substrate
       |
       v
deposited experiment capability
       |
       v
MCP self-description
       |
       v
AI can discover what the laboratory has become
```

The workstation simulator makes that architecture practical to develop before every physical instrument exists.

> **The laboratory does not need to know tomorrow's experiment today.**

And now, in v0.5:

> **Tomorrow's experiment does not need tomorrow's hardware before we can build, test, and understand its software today.**
