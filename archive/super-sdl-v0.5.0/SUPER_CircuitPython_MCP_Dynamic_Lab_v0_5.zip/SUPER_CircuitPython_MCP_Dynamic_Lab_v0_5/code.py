"""SUPER / MCP dynamic laboratory seed -- CircuitPython.

This file is intentionally almost empty.

That is not an accident; it is the central architectural statement of the
project.  code.py is *not* the experiment.  It is merely the door into a
small, durable laboratory runtime.  Experiments and instrument personalities
live in /capabilities and may arrive later, after the board is already in the
student's hands.

Traditional embedded firmware tends to answer:
    "What should this board do?"

SUPER asks a different question:
    "What stable services must always exist so that the board can learn what
     to do when an experiment requires it?"

The permanent answer is therefore deliberately small: start SUPER.
"""

from super.core import run

run()
