# Architecture Notes — Reliability, Extensibility, and the Boundary Lines

## 1. What should be permanent?

As little experimental meaning as possible.

The resident SUPER core owns concerns that recur across almost every experiment:

- network presence,
- MCP protocol handling,
- local authentication appropriate to the prototype,
- stable sensor/output abstractions,
- capability discovery,
- controlled reload,
- diagnostics,
- validation boundaries.

It should *not* permanently contain the procedure for Newton cooling,
Beer-Lambert analysis, pendulum timing, or motor characterization. Those are
experimental ideas, not operating-system responsibilities.

A useful analogy is a general computer: the operating system knows how to read
a disk and draw a window, but it does not bake "write a geology report" into
the kernel.

SUPER attempts the same separation in a low-cost physical laboratory.

## 2. Driver versus capability

A driver says:

> Here is how to read a DS18B20.

A capability says:

> I can conduct a Newton-cooling run using the laboratory's temperature role.

The distinction moves us from hardware access to experimental semantics.

The experiment should depend on `temp1`, not on a particular GPIO pin or 1-Wire
implementation. That is what makes this transition possible:

```text
temp1 -> simulated backend
```

becoming:

```text
temp1 -> DS18B20 backend
```

without changing `cooling_start`, `cooling_sample`, or the AI's vocabulary.

## 3. Why MCP makes plug-ins more significant

Dynamic module loading is not new.

MCP closes a semantic loop:

```text
new package arrives
    -> package registers experimental meaning
    -> tools/list changes
    -> AI discovers the changed meaning
    -> AI immediately uses the new ability
```

The code becomes self-announcing laboratory vocabulary.

That is why `register(registry, lab)` is the defining interface.

## 4. Reliability is repeated structure

v0.5 deliberately uses the same pattern at several layers:

```text
prepare -> validate -> commit
```

### File layer

- collect and syntax-check local package,
- upload to inert `/staging`,
- verify exact bytes,
- write READY last,
- preserve previous active version,
- MOVE complete directory into `/capabilities`.

### Semantic layer

- read/validate manifest,
- check declared physical roles,
- import package,
- stage all MCP tool registrations privately,
- compare staged tools with manifest `provides`,
- commit vocabulary atomically.

### Post-boot layer

- reload,
- wait for node,
- ask `capability_list`,
- require package status `active`,
- require promised tools to be visible,
- otherwise roll back when possible.

A system is easier to understand when "ready" has one meaning at every level.

## 5. Why dependencies are expressed in roles

The manifest currently supports:

```json
"requires": {
  "sensors": ["temp1"],
  "outputs": ["led"]
}
```

These are stable laboratory roles, not low-level device classes.

Future manifests may need richer requirements:

```text
quantity: temperature
minimum sample rate: 2 Hz
accuracy: ±0.2 C
range: 0..100 C
calibration required: true
```

That would let an AI ask a more powerful question than "is temp1 present?":

> Does this bench possess any instrument capable of satisfying the experiment's
> measurement requirement?

That is a future direction, not required for the seed.

## 6. Why the registry itself must be transactional

Catching an exception around `register()` is not enough if `register()` has
already changed public state.

The v0.5 ToolRegistry transaction gives a capability a registry-shaped staging
object. It can create several tools, but `tools/list` sees none of them until
`commit()`.

This matters because the observable vocabulary of the laboratory is part of the
instrument. A half-registered experiment is analogous to an instrument panel
whose labels claim controls that are not fully wired.

## 7. Why nested capability packages matter

The v0.3 deployer only copied top-level files. That would quickly become an
artificial ceiling.

Real capability packages may contain:

```text
module.py
models.py
calibration/default.json
data/reference_curve.csv
ui/help.html
```

v0.5 recursively stages and verifies the package tree. The extension system is
therefore structurally capable of growing beyond one-file demos.

## 8. What happens when code is bad?

There are several different failure classes.

### Syntax error

Desktop preflight catches ordinary Python syntax errors before upload.

### Missing dependency

The resident loader rejects the package before registration.

### register() throws

The private registry transaction is abandoned; no partial tools appear.

### Handler throws later

The MCP dispatcher returns a tool error while the server remains alive.

### Import code hangs forever

This is different. Python is executing trusted code inside the same interpreter,
so a normal exception boundary cannot recover from code that never returns.
Filesystem rollback may still be possible through CircuitPython Web Workflow,
but a reset may be required.

Future hardening options include:

- watchdog reset,
- boot-attempt counters,
- last-known-good package sets,
- a physical safe-mode input,
- signed/curated capability repositories,
- A/B capability manifests.

The seed documents this boundary rather than pretending Python is a sandbox.

## 9. Security boundary

The included design is appropriate to a trusted bench/LAN prototype.

It is **not** a production remote-code execution service.

CircuitPython Web Workflow's password protects against casual access but is
normally HTTP Basic Auth without transport encryption. The custom MCP endpoint
uses a simple bearer token over HTTP. Capability Python executes with the same
privilege as the resident runtime.

A deployed product would need a different trust model, potentially including:

- TLS or a trusted secure tunnel,
- signed capability artifacts,
- publisher identity,
- allowlisted capability sources,
- explicit human approval for actuator-affecting packages,
- physical safety interlocks independent of AI/Python.

## 10. MCP protocol choice

The seed targets MCP `2026-07-28`, whose stateless protocol model is unusually
appropriate to a small embedded server:

- no persistent protocol session is required,
- `server/discover` is optional and small,
- each request is self-describing,
- method/tool names are carried in HTTP headers,
- list responses can be cached.

The HTTP server verifies that `Mcp-Method` and `Mcp-Name` agree with the JSON-RPC
body before dispatch. If headers are intended to be useful to gateways or
policy code, they must not be allowed to lie about the body.

## 11. Why CircuitPython Web Workflow is a strong fit

CircuitPython already supplies:

- Wi-Fi autoconnection,
- mDNS identity,
- HTTP file access,
- filesystem writability reporting,
- directory creation/deletion,
- directory MOVE/rename.

SUPER therefore does not need to confuse *transport innovation* with
*laboratory innovation*.

The Web Workflow moves bytes.

SUPER decides when those bytes become an experimental ability.

## 12. What will eventually limit Pico W?

Memory and timing, not the architectural idea.

Likely pressure points include:

- many simultaneous imported packages,
- large numerical libraries,
- high-rate waveforms,
- camera data,
- hard real-time control,
- large data retention.

The natural decomposition is:

```text
hard timing / acquisition -> PIO, DMA, compiled helper
simple bench orchestration -> CircuitPython resident core
experiment semantics       -> deposited capability
large analysis             -> desktop / AI host
large data                  -> capture/resource storage
safety                      -> independent low-level supervisor/interlock
```

The design is strongest when each layer does the work it is naturally suited to.

## 13. The educational argument

A conventional lab manual presents an apparatus whose capabilities are already
fixed. The learner rarely sees the prior design questions.

SUPER can expose them:

> What physical quantities must we observe?

> What accuracy is sufficient?

> Which available sensors satisfy that need?

> What software capability is missing?

> What code did we add?

> What vocabulary did the laboratory gain?

> Which data are simulated, measured, or calculated?

This turns software architecture into part of scientific reasoning rather than
invisible plumbing.

## 14. The next physical proof

The strongest next step is deliberately modest:

```text
newton_cooling capability unchanged
MCP tools unchanged
desktop client unchanged

only replace:

temp1 simulated backend -> real DS18B20
```

If that works, the project has physically demonstrated the principle that the
experimental interface is stable while the substrate beneath it changes.

After that, install one unrelated second capability without editing the core.
That will demonstrate that SUPER is a platform rather than a Newton-cooling
application.

## 15. v0.5 simulation-host boundary

The Windows process is intentionally below `Lab` and below MCP semantics. It
owns models, not laboratory identity.

The stable path is:

```text
MCP tool -> Pico resident dispatcher -> Lab role -> backend
```

not:

```text
MCP tool -> special simulation application
```

When the USB host is connected, `Lab` delegates supported reads and captures to
the host. If the host disappears, the same role falls back to the resident
model. A future hardware registry can bind the role to a driver without changing
the experiment-facing contract. This creates a migration path:

```text
Win32 simulation -> resident/hybrid -> physical hardware
```

with provenance reported explicitly at every stage.

## 16. Why USB-only MCP is a bridge, not a second server

The simulation host exposes an HTTP endpoint on `127.0.0.1`, because ordinary
desktop MCP clients understand HTTP more readily than a custom serial protocol.
However, the host does not maintain its own `ToolRegistry`.

It forwards the JSON-RPC body over `SUPER-SIM/1` as `mcp_request`. The Pico
executes the same `dispatch()` function used by direct Wi-Fi HTTP and sends the
result back as `mcp_response`.

Consequences:

- Wi-Fi and USB expose the same vocabulary;
- deposited capabilities require no desktop registry synchronization;
- USB-only development remains possible;
- the Pico remains the authoritative laboratory identity;
- the simulation host can be replaced without changing experimental semantics.

## 17. Why USB discovery is passive

CircuitPython exposes a console CDC interface and, in v0.5, an additional data
CDC interface. On Windows both are COM ports and their numbering is not a
contract.

A naive scanner could write a probe string to every candidate port. That would
also write into the student's REPL if the console port were opened. SUPER avoids
that.

While unattached, the dedicated data channel emits a small unsolicited
`SUPER-SIM/1` hello frequently. The Windows host opens only CircuitPython-looking
serial devices and waits briefly. The console never emits a valid SUPER hello,
while the data interface does. Discovery is therefore automatic without
polluting the REPL.

## 18. Discovery has an acceptance rule, not just a search rule

Finding a candidate endpoint is insufficient. v0.5 desktop discovery treats a
candidate as SUPER only after `server/discover` succeeds with the expected MCP
protocol version.

The same principle appears repeatedly in the design:

```text
visible candidate != valid laboratory
uploaded files    != active capability
registered names  != committed vocabulary
```

Presence is cheap. Validated meaning is the useful state.

## 19. Simulation fidelity boundary

The Win32 models are intentionally more realistic than independent random
channels but they are not claimed to be high-fidelity scientific digital twins.
They include coherent units/ranges, controlled noise, slow environmental
variation, causal output coupling, a first-order thermal response, fault states,
and record/replay.

That is enough to test laboratory software, experimental workflows, AI tool use,
and failure handling before the physical instruments exist. When an experiment
needs more fidelity, the model can itself become a capability or backend
component with explicit parameters and validation data. The architecture does
not require the simple reference models to become the final physics.
