#!/usr/bin/env python3
"""Desktop semantic regression suite for SUPER v0.5.

This cannot prove USB electrical behavior or CircuitPython Wi-Fi operation, but
it does exercise the architecture that must remain true on either side of the
wire: transactional capabilities, stable logical sensor roles, rich causal
simulation, scenarios/faults, and substitution of a remote simulation backend.
"""

import json
import os
import shutil
import sys
import tempfile
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

from super.lab import Lab
from super.registry import ToolRegistry
import super.capabilities as capabilities
from sim_host.models import ReplayWorld, SimulationWorld, TraceRecorder
from sim_host.server import (
    MCP_PROTOCOL as HOST_MCP_PROTOCOL,
    LocalMcpBridge,
    PICO_CIRCUITPYTHON_PID,
    PICO_CIRCUITPYTHON_VID,
    _looks_like_circuitpython_port,
)
from super.hostlink import HostSimLink, PROTOCOL as SIM_PROTOCOL
from desktop_discover import _mcp_probe


def test_registry_transaction():
    r = ToolRegistry()
    r.register({"name": "core", "inputSchema": {"type": "object"}}, lambda a: "core")
    tx = r.begin_transaction("demo")
    tx.register({"name": "one", "inputSchema": {"type": "object"}}, lambda a: 1)
    tx.register({"name": "two", "inputSchema": {"type": "object"}}, lambda a: 2)
    assert [d["name"] for d in r.definitions()] == ["core"]
    tx.commit()
    assert [d["name"] for d in r.definitions()] == ["core", "one", "two"]


def test_no_partial_registration_on_prepare_failure():
    r = ToolRegistry()
    tx = r.begin_transaction("broken")
    tx.register({"name": "visible_only_if_committed", "inputSchema": {"type": "object"}}, lambda a: 1)
    assert "visible_only_if_committed" not in [d["name"] for d in r.definitions()]


def test_lab_local_regressions():
    lab = Lab()
    lab.sim.configure("temperature_c", {"enabled": False})
    assert lab.read_sensor("temp1")["status"] == "disabled"
    lab.sim.configure("temperature_c", {"enabled": True})
    old = dict(lab.sim.channels["temperature_c"])
    try:
        lab.sim.configure("temperature_c", {"period_s": 0})
        raise AssertionError("bad period accepted")
    except ValueError:
        pass
    assert lab.sim.channels["temperature_c"] == old
    try:
        lab.set_output("pwm_duty_pct", 101)
        raise AssertionError("invalid duty accepted")
    except ValueError:
        pass
    assert lab.read_sensor("accel1")["backend"] == "local-sim"


def test_win32_simulation_models():
    world = SimulationWorld("nominal", seed=1234)
    snap = world.read_all()
    assert set(snap) == {"temp1", "light1", "env1", "adc1", "pot1", "accel1"}
    assert all(v["backend"] == "win32-sim" for v in snap.values())
    assert 0 <= snap["env1"]["humidityPct"] <= 100
    assert 0 <= snap["adc1"]["volts"] <= 3.3

    world.set_output("led", False)
    dark = world.read_sensor("light1")["lux"]
    world.set_output("led", True)
    lit = world.read_sensor("light1")["lux"]
    assert lit > dark + 10, (dark, lit)

    world.set_scenario("sensor_fault")
    fault = world.read_sensor("light1")
    assert fault["status"] == "fault" and fault["value"] is None

    world.set_scenario("nominal")
    wave = world.waveform(128, 2000)
    assert len(wave["samples"]) == 128 and wave["backend"] == "win32-sim"



def test_record_replay():
    fd, path = tempfile.mkstemp(prefix="super_v05_", suffix=".jsonl")
    os.close(fd)
    try:
        recorder = TraceRecorder(path)
        world = SimulationWorld("nominal", seed=99, recorder=recorder)
        original = world.read_sensor("temp1")
        wave = world.waveform(24, 1200)
        recorder.close()

        replay = ReplayWorld(path)
        got = replay.read_sensor("temp1")
        got_wave = replay.waveform()
        assert got["backend"] == "win32-replay"
        assert got["temperatureC"] == original["temperatureC"]
        assert got_wave["backend"] == "win32-replay"
        assert got_wave["samples"] == wave["samples"]
    finally:
        try:
            os.unlink(path)
        except OSError:
            pass

def test_backend_substitution_seam():
    class FakeHost:
        connected = True
        def service(self): pass
        def status(self): return {"available": True, "connected": True}
        def call(self, method, params=None, timeout_s=None):
            if method == "sensor.read":
                return {"id": params["id"], "model": "DS18B20", "temperatureC": 31.25, "status": "ok", "backend": "win32-sim"}
            if method == "sensor.read_all":
                return {"readings": {"temp1": {"id": "temp1", "temperatureC": 31.25, "status": "ok", "backend": "win32-sim"}}}
            if method == "scenario.list": return {"current": "nominal", "scenarios": ["nominal"]}
            if method == "scenario.set": return {"scenario": params["name"]}
            if method == "waveform.capture": return {"samples": [1.0, 2.0], "backend": "win32-sim"}
        def notify(self, method, params=None):
            self.notified = (method, params)
            return True

    lab = Lab()
    lab.host = FakeHost()
    got = lab.read_sensor("temp1")
    assert got["temperatureC"] == 31.25 and got["backend"] == "win32-sim"
    lab.set_output("led", True)
    assert lab.host.notified[0] == "output.event"
    # Logical identity did not change when the backend did.
    assert lab.has_sensor("temp1") and any(d["id"] == "temp1" for d in lab.sensor_descriptors)



def test_safe_usb_port_filter():
    class P:
        def __init__(self, vid=None, pid=None, product=None, description=None, manufacturer=None):
            self.vid, self.pid = vid, pid
            self.product, self.description, self.manufacturer = product, description, manufacturer

    assert _looks_like_circuitpython_port(P(PICO_CIRCUITPYTHON_VID, PICO_CIRCUITPYTHON_PID))
    assert _looks_like_circuitpython_port(P(product="CircuitPython CDC"))
    assert not _looks_like_circuitpython_port(P(0x0403, 0x6001, product="FTDI UART"))
    assert _looks_like_circuitpython_port(P(0x0403, 0x6001), probe_all=True)


def test_pico_usb_mcp_dispatch_seam():
    link = HostSimLink()
    sent = []
    link._send = lambda obj: sent.append(obj) or True
    link.set_mcp_handler(lambda req: {
        "jsonrpc": "2.0", "id": req.get("id"),
        "result": {"supportedVersions": [HOST_MCP_PROTOCOL]},
    })
    link._handle_frame({
        "protocol": SIM_PROTOCOL, "op": "mcp_request", "id": "host-1",
        "request": {"jsonrpc": "2.0", "id": 7, "method": "server/discover", "params": {}},
    })
    assert sent and sent[-1]["op"] == "mcp_response"
    assert sent[-1]["response"]["id"] == 7
    assert HOST_MCP_PROTOCOL in sent[-1]["response"]["result"]["supportedVersions"]


def test_loopback_mcp_proxy():
    class FakeSerial:
        port = "COM_TEST"

    class FakeWorker:
        node = "super-test"
        ser = FakeSerial()
        hello = {"ip": None}

        def forward_mcp(self, request, timeout_s=4.0):
            assert request["method"] == "server/discover"
            return {
                "jsonrpc": "2.0", "id": request.get("id"),
                "result": {"supportedVersions": [HOST_MCP_PROTOCOL]},
            }

    proxy = LocalMcpBridge(FakeWorker(), "super-demo")
    proxy.start()
    try:
        assert _mcp_probe("127.0.0.1", proxy.port, token="super-demo", timeout=1.0)
        assert not _mcp_probe("127.0.0.1", proxy.port, token="wrong", timeout=1.0)
    finally:
        proxy.close()

def test_newton_capability():
    capabilities.CAPABILITY_ROOT = os.path.join(HERE, "capabilities")
    lab = Lab()
    r = ToolRegistry()
    report = capabilities.CapabilityManager(r, lab).load_all()
    item = next(p for p in report if p["package"] == "newton_cooling")
    assert item["status"] == "active", item
    start = r.call("cooling_start", {"mode": "model", "initial_c": 80, "ambient_c": 22, "tau_s": 0.2})
    assert start["isError"] is False
    a = r.call("cooling_sample", {})["structuredContent"]
    time.sleep(0.03)
    b = r.call("cooling_sample", {})["structuredContent"]
    assert b["temperatureC"] < a["temperatureC"], (a, b)


def _write_bad_package(pkg, manifest, module_text):
    base = os.path.join(HERE, "capabilities", pkg)
    os.makedirs(base, exist_ok=True)
    with open(os.path.join(base, "__init__.py"), "w") as f: f.write("\n")
    with open(os.path.join(base, "READY"), "w") as f: f.write("ready\n")
    with open(os.path.join(base, "manifest.json"), "w") as f: json.dump(manifest, f)
    with open(os.path.join(base, "module.py"), "w") as f: f.write(module_text)
    return base


def _cleanup_package(pkg, base):
    for name in list(sys.modules):
        if name == "capabilities.%s" % pkg or name.startswith("capabilities.%s." % pkg):
            del sys.modules[name]
    shutil.rmtree(base, ignore_errors=True)


def test_manager_rejects_half_vocabulary():
    pkg = "selftest_bad_manifest"
    base = _write_bad_package(pkg, {
        "apiVersion": 1, "id": pkg, "version": "0", "entrypoint": "module",
        "requires": {}, "provides": ["half_one", "half_two"],
    }, "def register(registry, lab):\n    registry.register({'name':'half_one','inputSchema':{'type':'object'}}, lambda a: 1)\n")
    try:
        capabilities.CAPABILITY_ROOT = os.path.join(HERE, "capabilities")
        r = ToolRegistry(); item = capabilities.CapabilityManager(r, Lab()).load_one(pkg)
        assert item["status"] == "error" and not r.definitions()
    finally:
        _cleanup_package(pkg, base)


def test_manager_rejects_missing_role():
    pkg = "selftest_missing_role"
    base = _write_bad_package(pkg, {
        "apiVersion": 1, "id": pkg, "version": "0", "entrypoint": "module",
        "requires": {"sensors": ["neutrino_flux_1"]}, "provides": ["impossible_tool"],
    }, "def register(registry, lab):\n    registry.register({'name':'impossible_tool','inputSchema':{'type':'object'}}, lambda a: 1)\n")
    try:
        capabilities.CAPABILITY_ROOT = os.path.join(HERE, "capabilities")
        r = ToolRegistry(); item = capabilities.CapabilityManager(r, Lab()).load_one(pkg)
        assert item["status"] == "error" and "missing laboratory dependencies" in item["message"]
    finally:
        _cleanup_package(pkg, base)


def test_package_ids_are_importable_identifiers():
    assert capabilities._safe_identifier("newton_cooling")
    assert not capabilities._safe_identifier("newton-cooling")
    assert not capabilities._safe_identifier("3bad")


def main():
    tests = [
        test_registry_transaction,
        test_no_partial_registration_on_prepare_failure,
        test_lab_local_regressions,
        test_win32_simulation_models,
        test_record_replay,
        test_backend_substitution_seam,
        test_safe_usb_port_filter,
        test_pico_usb_mcp_dispatch_seam,
        test_loopback_mcp_proxy,
        test_manager_rejects_half_vocabulary,
        test_manager_rejects_missing_role,
        test_package_ids_are_importable_identifiers,
        test_newton_capability,
    ]
    for test in tests:
        test(); print("PASS", test.__name__)
    print("PASS: SUPER v0.5 desktop semantic self-test")


if __name__ == "__main__":
    main()
