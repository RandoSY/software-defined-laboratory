# LAB-12 v1.2 — portable source preservation snapshot

Curated from the full 409-entry LAB-12 v1.2 compilation ZIP (original source retained in ChatGPT recovery backup).
Contains author project source, browser instrumentation, MSP430 examples, Pico runtime, host tests and operator protocol.
Excluded CCS compiler outputs/debug artifacts, large images, vendor linker scripts and duplicate generated files.
This is an archive and source-study resource, not a physically validated instrument release.
All original included file bytes are verified in SOURCE_FIDELITY_MANIFEST.json.
